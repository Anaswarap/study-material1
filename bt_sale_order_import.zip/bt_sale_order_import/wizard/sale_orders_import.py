import tempfile
import binascii
import datetime
import xlrd
import logging

_logger = logging.getLogger(__name__)
from odoo import models, fields, _
from odoo.exceptions import UserError


class ImportSaleOrder(models.TransientModel):
    _name = 'import.sale.order'

    xls_file_name = fields.Char('Excel File Name', size=64, required=True)
    xls_file = fields.Binary('Excel File')
    default_currency_id = fields.Many2one('res.currency', 'Currency')
    default_company_id = fields.Many2one('res.company', 'Company', default=lambda self: self.env.company)

    def import_sale_order(self):
        try:
            iteration_count = 0
            unique_customer_refs = set()
            sale_order_count = 0
            file_string = tempfile.NamedTemporaryFile(suffix=".xlsx")
            file_string.write(binascii.a2b_base64(self.xls_file))
            book = xlrd.open_workbook(file_string.name)
        except:
            raise UserError(_("Please choose the .xlsx file"))
        for sheet in book.sheets():
            try:
                if sheet.name == 'Sheet1':
                    for row in range(sheet.nrows):
                        iteration_count += 1
                        _logger.info("Iteration: %s", iteration_count)

                        if row >= 28:
                            row_values = sheet.row_values(row)
                            if isinstance(row_values[19], str) and row_values[19]:
                                customer_ref = row_values[0]
                                unique_customer_refs.add(customer_ref)
                                cleaned_cust_code = row_values[7].split()[0]
                                cleaned_currency_id = row_values[7].split()[1]
                                if cleaned_currency_id == 'USD':
                                    pricelist_id = self.env['product.pricelist'].search(
                                        [('name', '=', 'Default USD pricelist')], limit=1)
                                    currency_id = self.env['res.currency'].search([('name', '=', 'USD')], limit=1)
                                else:
                                    currency_id = self.env['res.currency'].search([('name', '=', 'CAD')], limit=1)
                                    pricelist_id = self.env['product.pricelist'].search(
                                        [('name', '=', 'Public Pricelist')], limit=1)
                                customer_id = self.env['res.partner'].search(
                                    [('cust_code', '=', cleaned_cust_code),
                                     ('company_id', '=', self.default_company_id.id), ('customer_rank', '>', 0),
                                     ], limit=1)
                                if not customer_id:
                                    customer_id = self.env['res.partner'].create({
                                        'name': row_values[19],
                                        'cust_code': cleaned_cust_code,
                                        'company_id': self.default_company_id.id,
                                        'customer_rank': 1,
                                    })
                                order_date = False
                                if row_values[29] and isinstance(row_values[29], float):
                                    convert_int_order_date = int(row_values[29])
                                    order_date_value_timestamp = datetime.datetime(1899, 12, 30) + datetime.timedelta(
                                        days=convert_int_order_date)
                                    order_date = order_date_value_timestamp.strftime("%Y-%m-%d")
                                order_val = {
                                    'client_order_ref': customer_ref,
                                    'date_order': order_date,
                                    'pricelist_id': pricelist_id.id,
                                    'partner_id': customer_id.id,
                                    'currency_id': currency_id.id,
                                    'imported_so': True,
                                    'company_id': self.default_company_id.id
                                }
                                sale_order = self.env['sale.order'].create(order_val)
                                sale_order_count += 1

                                iteration_count = 0
                            if sale_order:
                                ship_date = False
                                if row_values[19] and isinstance(row_values[19], float):
                                    convert_int_ship_date = int(row_values[19])
                                    ship_date_value_timestamp = datetime.datetime(1899, 12, 30) + datetime.timedelta(
                                        days=convert_int_ship_date)
                                    ship_date = ship_date_value_timestamp.strftime("%Y-%m-%d")
                                if ship_date:
                                    sale_order.x_studio_ship_date = ship_date
                                if row_values[22] and len(row_values[0]) > 1:
                                    if isinstance(row_values[22], (float, int)):
                                        product_template_id = self.env['product.template'].search(
                                            [('default_code', '=', row_values[0])], order='create_date desc', limit=1)
                                        if not product_template_id:
                                            product_template_id = self.env['product.template'].create({
                                                'name': row_values[0],
                                                'default_code': row_values[0],
                                                'import_product': True
                                            })
                                            # continue
                                        # if isinstance(row_values[22], str):
                                        #     product_template_id = self.env['product.template'].search(
                                        #         [('name', '=', row_values[0])])
                                        if product_template_id:
                                            price_unit = float(row_values[27].replace(',', ''))
                                            product_uom_qty = float(row_values[25])
                                            order_line = {
                                                'order_id': sale_order.id,
                                                'product_template_id': product_template_id.id,
                                                'product_id': product_template_id.product_variant_id.id,
                                                'name': "[{}] {}".format(row_values[0], product_template_id.name),
                                                'product_uom_qty': product_uom_qty,
                                                'product_uom': product_template_id.uom_id.id,
                                                'tax_id': False,
                                                'price_unit': price_unit
                                            }
                                            self.env['sale.order.line'].create(order_line)


            except IndexError:
                pass

        unique_customer_count = len(unique_customer_refs)
        _logger.info("Unique Customer References Count: %s", unique_customer_count)
        _logger.info("Total sale orders generated: %s", sale_order_count)

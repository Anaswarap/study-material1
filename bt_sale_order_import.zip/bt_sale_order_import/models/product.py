# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import _, api, fields, models


class Product(models.Model):
    _inherit = 'product.template'

    import_product = fields.Boolean('Created for importing SO')


class ProductProduct(models.Model):
    _inherit = "product.product"

    import_product = fields.Boolean('Created for importing SO', related='product_tmpl_id.import_product')

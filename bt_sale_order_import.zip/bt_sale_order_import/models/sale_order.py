from odoo import models, fields


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    imported_so = fields.Boolean(string='Imported SO', default=False)

# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name': 'BT Sale Order Import ',
    'version': '16.1',
    'summary': """BT Sale Order Import """,
    'license': 'LGPL-3',
    'description': """
    BT Sale Order Import 
""",
    'author': 'Your odoo partner',
    'website': 'http://yourodoopartner.com/',
    'depends': ['base', 'account', 'sale', 'bt_circle_import'],
    'images': [],
    'data': [
        'security/group.xml',
        'security/ir.model.access.csv',
        'wizard/sale_import_order_view.xml',
        'views/sale_order_views.xml',
        'views/product_views.xml'
    ],
    'qweb': [],
    'installable': True,
    'auto_install': False,
    'application': True
}

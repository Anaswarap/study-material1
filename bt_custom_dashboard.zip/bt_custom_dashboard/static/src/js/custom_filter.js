/** @odoo-module **/

import { RELATIVE_DATE_RANGE_TYPES } from "@spreadsheet/helpers/constants";
import { _lt } from "@web/core/l10n/translation";

RELATIVE_DATE_RANGE_TYPES.push({ type: "today", description: _lt("Today") });
RELATIVE_DATE_RANGE_TYPES.push({ type: "fiscal_year", description: _lt("Fiscal Year") });

odoo.define('bt_custom_dashboard.custom_filter', function (require) {"use strict";

    const helpers = require('@spreadsheet/global_filters/helpers');
    const { Domain } = require("@web/core/domain");
    const { serializeDate, serializeDateTime } = require("@web/core/l10n/dates");
    const { DateTime } = luxon;
    const originalGetRelativeDateDomain = helpers.getRelativeDateDomain;

     helpers.getRelativeDateDomain = function (now, offset, rangeType, fieldName, fieldType) {
        let endDate = now.minus({ day: 1 }).endOf("day");
        let startDate = endDate;

        switch (rangeType) {
            case "today": {
                startDate = now;
                endDate = now;
                break;
            }
            case "fiscal_year": {
                const fiscalYearStartMonth = 1;
                const fiscalYearStart = DateTime.local(now.year, fiscalYearStartMonth, 1);
                if (now < fiscalYearStart) {
                    startDate = fiscalYearStart.minus({ year: 1 });
                } else {
                    startDate = fiscalYearStart;
                }
                endDate = startDate.plus({ year: 1 }).minus({ day: 1 });
                break;
            }
            default:
                return originalGetRelativeDateDomain(now, offset, rangeType, fieldName, fieldType);
        }

        startDate = startDate.startOf("day");

        let leftBound, rightBound;
        if (fieldType === "date") {
            leftBound = serializeDate(startDate);
            rightBound = serializeDate(endDate);
        } else {
            leftBound = serializeDateTime(startDate);
            rightBound = serializeDateTime(endDate);
        }

        return new Domain(["&", [fieldName, ">=", leftBound], [fieldName, "<=", rightBound]]);
    };
});
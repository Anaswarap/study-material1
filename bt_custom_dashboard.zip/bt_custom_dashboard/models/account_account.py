# -*- coding: utf-8 -*-

from odoo import fields, models, api


class AccountAccount(models.Model):
    _inherit = 'account.account'

    is_bank_or_cash = fields.Selection([('bank', 'Bank'),
                                        ('cash', 'Cash')],
                                       default=False, string="Bank or Cash",
                                       help="Indicate whether this account is a Bank, Cash, or Other."
                                       )

    balance_amount = fields.Monetary(compute='_compute_balance_amount', store=True)

    @api.depends("current_balance", "is_bank_or_cash")
    def _compute_balance_amount(self):
        for acc in self:
            acc.balance_amount = acc.current_balance


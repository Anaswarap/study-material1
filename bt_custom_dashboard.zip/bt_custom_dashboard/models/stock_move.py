# -*- coding: utf-8 -*-

from odoo import models, fields, api


class StockMove(models.Model):
    _inherit = 'stock.move'

    create_date_only = fields.Date(
        string="Create Date (Date Only)",
        compute="_compute_create_date_only",
        store=True
    )

    @api.depends("create_date")
    def _compute_create_date_only(self):
        for record in self:
            record.create_date_only = record.create_date.date() if record.create_date else False









import base64
import json
from datetime import date, datetime, time

from odoo import api, fields, models, _

class SpreadsheetDashboard(models.Model):
    _name = 'spreadsheet.dashboard'
    _inherit = ['spreadsheet.dashboard']

    @api.depends('data')
    def _compute_raw(self):
        for dashboard in self:
            snapshot_bytes = base64.decodebytes(dashboard.data)
            snapshot_str = snapshot_bytes.decode('utf-8')
            snapshot_data = json.loads(snapshot_str)
            sheets = snapshot_data.get('sheets', [])
            if sheets[0].get('name') == 'Custom Dashboard':
                figures = sheets[0].get('figures', [])
                current_year = datetime.today().year
                for fig in figures:
                    if fig.get('id') == 'monthly_sales_graph':
                        domain = fig.get('data', {}).get('searchParams', {}).get('domain', [])
                        year_start_filter = ['create_date_only', '>=', f'{current_year}-01-01']
                        year_end_filter = ['create_date_only', '<=', f'{current_year}-12-31']
                        domain.append(year_start_filter)
                        domain.append(year_end_filter)
                    if fig.get('id') == 'invoiced_graph':
                        current_year = datetime.today().year
                        domain = fig.get('data', {}).get('searchParams', {}).get('domain', [])
                        year_start_filter = ['create_date_only', '>=', f'{current_year}-01-01']
                        year_end_filter = ['create_date_only', '<=', f'{current_year}-12-31']
                        domain.append(year_start_filter)
                        domain.append(year_end_filter)

                lists = snapshot_data.get('lists', [])
                pivots = snapshot_data.get('pivots', [])
                current_date = datetime.now().strftime('%Y-%m-%d')

                if '13' in pivots:
                    pivot = pivots['13']
                    pivot_domain = pivot.get('domain', [])
                    date_filter = ['create_date_only', '=', current_date]
                    pivot_domain.append(date_filter)

                if '1' in pivots:
                    pivot = pivots['1']
                    next_pivot_domain = pivot.get('domain', [])
                    date_filter = ['create_date_only', '=', current_date]
                    next_pivot_domain.append(date_filter)

                if '3' in lists:
                    list_details = lists['3']
                    list_domain = list_details.get('domain', [])
                    date_filter = ['create_date_only', '=', current_date]
                    list_domain.append(date_filter)

                snapshot_json_str = json.dumps(snapshot_data)
                snapshot_bytes = snapshot_json_str.encode('utf-8')
                dashboard.raw = snapshot_bytes
            else:
                dashboard.raw = base64.decodebytes(dashboard.data)



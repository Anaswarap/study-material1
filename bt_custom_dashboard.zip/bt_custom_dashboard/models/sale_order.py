# -*- coding: utf-8 -*-

from odoo import models, fields, api


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    create_date_only = fields.Date(
        string="Create Date (Date Only)",
        compute="_compute_create_date_only",
        store=True
    )

    @api.depends("create_date")
    def _compute_create_date_only(self):
        for record in self:
            record.create_date_only = record.create_date.date() if record.create_date else False


# class SaleOrderLine(models.Model):
#     _inherit = "sale.order.line"
#
#     margin = fields.Monetary(
#         "Margin1", compute='_compute_margin',
#         digits='Product Price', store=True, groups="base.group_user", precompute=True)


{
    'name': 'BT Custom Dashboard',
    'version': '16.0.1.0.1',
    'depends': ['web', 'spreadsheet', 'spreadsheet_dashboard', 'base', 'sale', 'board', 'account_accountant'],
    'data': [
         'data/dashboard_menu.xml',
        'views/account_account_view.xml'
        ],
    'assets': {
        'web.assets_backend': [
            'bt_custom_dashboard/static/src/css/box.css',
            'bt_custom_dashboard/static/src/js/custom_filter.js',
            'bt_custom_dashboard/static/src/js/date_range.js',
        ],
    },
}

# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name': 'BT Circle Inventory Import',
    'summary': 'BT Inventory Import',
    'description': """
        XLSX Import of inventory
    """,
    'version': '16.1.5',
    'depends': ['stock',
                ],
    'data' : [
        'security/ir.model.access.csv',
        'wizard/update_stock.xml',
        'wizard/partner_import.xml',
        'wizard/sale_tax_update.xml',
        'views/product_view.xml',
        'views/partner_view.xml',
     ],
    
    'test': [
    ],
    'demo': [
    ],
    'installable': True,
    'auto_install': False,
    'application': True,

}

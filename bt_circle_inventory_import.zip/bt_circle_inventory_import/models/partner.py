# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Partner(models.Model):
    _inherit = "res.partner"
    
    
    street4 = fields.Char(string="TEXTSTRE4")
    code_TERR = fields.Char(string="CODETERR")
    code_TAXGRP = fields.Char(string="CODETAXGRP")
    id_TAXREGI5 = fields.Char(string="IDTAXREGI5")
    tax_STTS1 = fields.Char(string="TAXSTTS1")
    tax_STTS2 = fields.Char(string="TAXSTTS2")
    tax_STTS3 = fields.Char(string="TAXSTTS3")
    tax_STTS4 = fields.Char(string="TAXSTTS4")
    tax_STTS5 = fields.Char(string="TAXSTTS5")
    spc_LINST = fields.Char(string="SPCLINST")
    code_SLSP1 = fields.Char(string="CODESLSP1")
    pctsasplt1 = fields.Char(string="PCTSASPLT1")
    pric_list = fields.Char(string="PRICLIST")
    fob = fields.Char(string="FOB")
    swp_RIMSHPT = fields.Char(string="SWPRIMSHPT")
    ewarver = fields.Char(string="EWARVER")
    values = fields.Char(string="VALUES")
    location_import = fields.Char(string="LOCATION")

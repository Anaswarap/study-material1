# -*- coding: utf-8 -*-

from odoo import models, fields, api

import logging

_logger = logging.getLogger(__name__)


class ProductTemplate(models.Model):
    _inherit = "product.template"
    
    
    division = fields.Char(string="Brand")
    sub_categ1 = fields.Char(string="Sub Category 1")
    sub_categ2 = fields.Char(string="Sub Category 2")
    
    def action_update_upc(self):
        products1 = self.env['product.template'].search([('unit_upc_code', 'like', '%\_x000D_')])
        print('pppppppppppppppppppsssssssssssss',len(products1))
        for product in products1:
            print('pppppppppppppppppppppppppp',product.default_code)
            product.unit_upc_code = product.unit_upc_code.replace('_x000D_','')
        products2 = self.env['product.template'].search([('inner_upc_code', 'like', '%\_x000D_')])
        print('pppppppppppppppppppsssssssssssss',len(products2))
        for product in products2:
            print('pppppppppppppppppppppppppp',product.default_code)
            product.inner_upc_code = product.inner_upc_code.replace('_x000D_','')
        products3 = self.env['product.template'].search([('master_upc_code', 'like', '%\_x000D_')])
        print('pppppppppppppppppppsssssssssssss',len(products3))
        for product in products3:
            print('pppppppppppppppppppppppppp',product.default_code)
            product.master_upc_code = product.master_upc_code.replace('_x000D_','')
            
    
    def action_get_CANCO_negative_svl(self):
        self.env.cr.execute("select product_id, sum(quantity), sum(value) from stock_valuation_layer where company_id=1 group by product_id")
        result = self.env.cr.fetchall()
        print('rrrrrrrrrrrrrrrrrrrrrrrrrr', result)
        count=0
        for x in result:
            # print('pppppppppppppppppppsssssssssssss',x, x[0], x[1], x[2])
            if x[1]==0 and x[2] < 0:
                print('pppppppppppppppppppppppppp',x[0])
                self.env.cr.execute("select default_code from product_product where id=%s", (x[0],))
                product = self.env.cr.fetchall()
                print('ppppppppppppppoopppppppppp',product)
                _logger.info("******************product................%s", product)
        print('cccccccccccccccccccc',count)
        _logger.info("******************Count................%s", count)

    
    def action_update_svl_stj(self):
#         Circle16_26Sep2024=# update stock_valuation_layer svl set unit_cost=.86, value=svl.quantity*.86 where product_id=15578 and create_date>'2024-08-28';
# UPDATE 163
# Circle16_26Sep2024=# select count(*) from stock_valuation_layer where product_id=15578 and create_date>'2024-08-28';
#  count 
# -------
#    163

        self.env.cr.execute("SELECT id FROM stock_valuation_layer WHERE product_id=15578 and create_date>'2024-08-28'")
        result = self.env.cr.fetchall()
        print('rrrrrrrrrrrrrrrrrrrrrrrrrr', result)
        count=0
        for x in result:
            svl = self.env['stock.valuation.layer'].browse(x[0])
            print('ssssssssssssssssssssss',svl, svl.value)
            if svl.account_move_id and svl.account_move_id.line_ids:
                svl.account_move_id.button_draft()
                for line in svl.account_move_id.line_ids:
                    if line.debit>0:
                        line.debit = svl.value > 0 and svl.value or -svl.value
                    if line.credit>0:
                        line.credit = svl.value > 0 and svl.value or -svl.value
                    count += 1
                svl.account_move_id.action_post()
        print('cccccccccccccccccccc',count)
        _logger.info("******************Count................%s", count)
        

# class AccountMove(models.Model):
#     _inherit = "account.move"
#
#
#     def _get_unbalanced_moves(self, container):
#         print('@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@.............')
#         moves = container['records'].filtered(lambda move: move.line_ids)
#         if not moves:
#             return
#
#         # /!\ As this method is called in create / write, we can't make the assumption the computed stored fields
#         # are already done. Then, this query MUST NOT depend on computed stored fields.
#         # It happens as the ORM calls create() with the 'no_recompute' statement.
#         self.env['account.move.line'].flush_model(['debit', 'credit', 'balance', 'currency_id', 'move_id'])
#         self._cr.execute('''
#             SELECT line.move_id,
#                    ROUND(SUM(line.debit), currency.decimal_places) debit,
#                    ROUND(SUM(line.credit), currency.decimal_places) credit
#               FROM account_move_line line
#               JOIN account_move move ON move.id = line.move_id
#               JOIN res_company company ON company.id = move.company_id
#               JOIN res_currency currency ON currency.id = company.currency_id
#              WHERE line.move_id IN %s
#           GROUP BY line.move_id, currency.decimal_places
#             HAVING ROUND(SUM(line.balance), currency.decimal_places) != 0
#         ''', [tuple(moves.ids)])
#
#         # return self._cr.fetchall()
#         return False

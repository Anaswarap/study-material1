from odoo import api, fields, models, _
from odoo.tools import pycompat
import odoo

import logging
_logger = logging.getLogger(__name__)

class WizardUpdateStock(models.TransientModel):
    _name = 'wizard.update.stock'
    _inherit = 'data_import.wizard'
    
    csv_file_name = fields.Char('CSV File Name', size=64)
    csv_file = fields.Binary('CSV File')
    
    
    def create_move(self, product, qty, price, location, dest_location, company):
        move_vals = {
            'name': _('Product Inventory Update'),
            'product_id': product.id,
            'product_uom': product.uom_id and product.uom_id.id or False,
            'product_uom_qty': qty,
            'price_unit': price,
            'company_id': company,
            'state': 'confirmed',
            'location_id': location.id,
            'location_dest_id': dest_location.id,
            'move_line_ids': [(0, 0, {
                'product_id': product.id,
                'product_uom_id': product.uom_id and product.uom_id.id or False,
                'qty_done': qty,
                'location_id': location.id,
                'location_dest_id': dest_location.id,
                'company_id': company,
                'lot_id': False,
                'package_id': False,
                'result_package_id': False,
                'owner_id': False,
            })]
        }
        move = self.env['stock.move'].create(move_vals)
        move._action_done()
        return True
    
    def upload_product_stock(self):
        if self.csv_file: ### 2024-06 USCO Inventory.csv
            list_raw_data = self.get_data_from_attchment(self.csv_file, self.csv_file_name)
            
            if not list_raw_data:
                raise UserError(_("Cannot import blank sheet."))
            count = 0
            not_product_list = []
            not_vendor_list = []
            print('lllllllllllllllllllllll***********')
            for raw in list_raw_data:
                print (">>>>>>raw.......",raw)
                print('ccccccccccccccc',raw.get('Company',False))
                company = 2
                print('ccccccccccccccc',company)
                if raw.get('Item Number',False):
                    print('rrrrrrrrrrrrrrrrrrrrrrrrrrrrawrawraw',raw.get('Item Number',False))
                    product = raw.get('Item Number',False)
                    product_id = self.env['product.template'].search([('default_code','=',product), ('company_id','=',company)], limit=1)
                    print ("<<<<<product_id,,,,,",product_id)
                    if not product_id:
                        print ("pppppppppppppppppppppppppp.......",raw)
                        not_product_list.append(product)   
                    if product_id:
                        
                        ####### Updating other fields of the sheet
                        product_id.name = raw.get('Description',False)
                        product_id.division = raw.get('Division',False)
                        product_id.sub_categ1 = raw.get('Sub Category 1',False)
                        product_id.sub_categ2 = raw.get('Sub Category 2',False)
                        product_id.standard_price=0
                        vendor = self.env['res.partner'].sudo().search([('cust_code','=',raw.get('Supplier Number',False)),('supplier_rank','>', 0), ('company_id','=',company)])
                        if not vendor:
                            not_vendor_list.append(raw.get('Supplier Number',False))   
                        if vendor:
                            supplier_info = self.env['product.supplierinfo'].sudo().search([
                                ('product_tmpl_id', '=', product_id.id),
                                ('partner_id', '=', vendor.id)
                            ], limit=1)
                        
                            if not supplier_info:
                                vals = {
                                    'partner_id': vendor.id,
                                    'product_tmpl_id': product_id.id
                                }
                                self.env['product.supplierinfo'].create(vals)
                            
                        product_domain = [('default_code','=',product), ('product_tmpl_id', '=', product_id.id)]
                        product_variant_id = self.env['product.product'].search(product_domain, limit=1)
                        print('pppppppppppppppppp',product_variant_id)
                        
                        if product_variant_id:
                            virtual_location = product_variant_id.property_stock_inventory   
                            Weber_Ontario_DC_stock_location = self.env['stock.location'].search([('name','=', 'Stock'),('location_id.name','=', 'USA1')])
                            Weber_Chino_DC_stock_location = self.env['stock.location'].search([('name','=', 'Stock'),('location_id.name','=', 'USA2')])
                            DI_USA_stock_location = self.env['stock.location'].search([('name','=', 'Stock'),('location_id.name','=', 'USA3')])
                            Direct_to_Client_USA_stock_location = self.env['stock.location'].search([('name','=', 'Stock'),('location_id.name','=', 'USA4')])
                            
                            if Weber_Ontario_DC_stock_location and virtual_location:
                                qty = raw.get('Qty On Hand Weber Ontario DC',0) and float(raw.get('Qty On Hand Weber Ontario DC',0)) or 0
                                price = raw.get('Unit Cost Weber Ontario DC',0) and float(raw.get('Unit Cost Weber Ontario DC',0)) or 0
                                stock_location = Weber_Ontario_DC_stock_location
                                if qty > 0:
                                    move = self.create_move(product_variant_id, qty, price, virtual_location, stock_location, company)
                                if qty < 0:
                                    move = self.create_move(product_variant_id, -qty, price, stock_location, virtual_location, company)
                                count += 1
                                
                            if Weber_Chino_DC_stock_location and virtual_location:
                                qty = raw.get('Qty On Hand Weber Chino DC',0) and float(raw.get('Qty On Hand Weber Chino DC',0)) or 0
                                price = raw.get('Unit Cost Weber Chino DC',0) and float(raw.get('Unit Cost Weber Chino DC',0)) or 0
                                stock_location = Weber_Chino_DC_stock_location
                                if qty > 0:
                                    move = self.create_move(product_variant_id, qty, price, virtual_location, stock_location, company)
                                if qty < 0:
                                    move = self.create_move(product_variant_id, -qty, price, stock_location, virtual_location, company)
                                count += 1
                                
                            if DI_USA_stock_location and virtual_location:
                                qty = raw.get('Qty On Hand DI (USA)',0) and float(raw.get('Qty On Hand DI (USA)',0)) or 0
                                price = raw.get('Unit Cost DI (USA)',0) and float(raw.get('Unit Cost DI (USA)',0)) or 0
                                stock_location = DI_USA_stock_location
                                if qty > 0:
                                    move = self.create_move(product_variant_id, qty, price, virtual_location, stock_location, company)
                                if qty < 0:
                                    move = self.create_move(product_variant_id, -qty, price, stock_location, virtual_location, company)
                                count += 1
                                
                            if Direct_to_Client_USA_stock_location and virtual_location:
                                qty = raw.get('Qty On Hand Direct to Client (USA)',0) and float(raw.get('Qty On Hand Direct to Client (USA)',0)) or 0
                                price = raw.get('Unit Cost Direct to Client (USA)',0) and float(raw.get('Unit Cost Direct to Client (USA)',0)) or 0
                                stock_location = Direct_to_Client_USA_stock_location
                                if qty > 0:
                                    move = self.create_move(product_variant_id, qty, price, virtual_location, stock_location, company)
                                if qty < 0:
                                    move = self.create_move(product_variant_id, -qty, price, stock_location, virtual_location, company)
                                count += 1
                            
            _logger.info("****************** Count................%s", count)
            _logger.info("****************** not product_variant_id.............%s", not_product_list)
            _logger.info("****************** not_vendor_list.............%s", not_vendor_list)

        
    def upload_product_stock_CAN(self):
        if self.csv_file: ### 2024-06 CANCO Inventory.csv
            list_raw_data = self.get_data_from_attchment(self.csv_file, self.csv_file_name)
            
            if not list_raw_data:
                raise UserError(_("Cannot import blank sheet."))
            count = 0
            not_product_list = []
            not_vendor_list = []
            print('lllllllllllllllllllllll***********')
            for raw in list_raw_data:
                print('ccccccccccccccc',raw.get('Company',False))
                company = 1
                if raw.get('Item Number',False):
                    print('rrrrrrrrrrrrrrrrrrrrrrrrrrrrawrawraw',raw.get('Item Number',False))
                    product = raw.get('Item Number',False)
                    product_id = self.env['product.template'].search([('default_code','=',product), ('company_id','=',company)], limit=1)
                    print ("<<<<<product_id,,,,,",product_id)
                    if not product_id:
                        not_product_list.append(product)   
                    if product_id:
                        
                        ####### Updating other fields of the sheet
                        product_id.name = raw.get('Description',False)
                        product_id.division = raw.get('Division',False)
                        product_id.sub_categ1 = raw.get('Sub Category 1',False)
                        product_id.sub_categ2 = raw.get('Sub Category 2',False)
                        product_id.standard_price=0
                        vendor = self.env['res.partner'].sudo().search([('cust_code','=',raw.get('Supplier Number',False)),('supplier_rank','>', 0), ('company_id','=',company)])
                        if not vendor:
                            not_vendor_list.append(raw.get('Supplier Number',False))   
                        if vendor:
                            supplier_info = self.env['product.supplierinfo'].sudo().search([
                                ('product_tmpl_id', '=', product_id.id),
                                ('partner_id', '=', vendor.id)
                            ], limit=1)
                        
                            if not supplier_info:
                                vals = {
                                    'partner_id': vendor.id,
                                    'product_tmpl_id': product_id.id
                                }
                                self.env['product.supplierinfo'].create(vals)
                            
                        product_domain = [('default_code','=',product), ('product_tmpl_id', '=', product_id.id)]
                        product_variant_id = self.env['product.product'].search(product_domain, limit=1)
                        
                        if product_variant_id:
                            virtual_location = product_variant_id.property_stock_inventory   
                            Wiptec_stock_location = self.env['stock.location'].search([('name','=', 'Stock'),('location_id.name','=', 'WIPT')])
                            DI_stock_location = self.env['stock.location'].search([('name','=', 'Stock'),('location_id.name','=', 'CN-DI')])
                            Direct_to_Client_stock_location = self.env['stock.location'].search([('name','=', 'Stock'),('location_id.name','=', 'BLIND')])
                            Circle_HQ_stock_location = self.env['stock.location'].search([('name','=', 'Stock'),('location_id.name','=', 'CHQ')])
                            
                            if Wiptec_stock_location and virtual_location:
                                qty = raw.get('Qty On Hand Wiptec',0) and float(raw.get('Qty On Hand Wiptec',0)) or 0
                                price = raw.get('Unit Cost Wiptec',0) and float(raw.get('Unit Cost Wiptec',0)) or 0
                                stock_location = Wiptec_stock_location
                                if qty > 0:
                                    move = self.create_move(product_variant_id, qty, price, virtual_location, stock_location, company)
                                if qty < 0:
                                    move = self.create_move(product_variant_id, -qty, price, stock_location, virtual_location, company)
                                count += 1
                                
                            if DI_stock_location and virtual_location:
                                qty = raw.get('Qty On Hand DI (Canada)',0) and float(raw.get('Qty On Hand DI (Canada)',0)) or 0
                                price = raw.get('Unit Cost DI (Canada)',0) and float(raw.get('Unit Cost DI (Canada)',0)) or 0
                                stock_location = DI_stock_location
                                if qty > 0:
                                    move = self.create_move(product_variant_id, qty, price, virtual_location, stock_location, company)
                                if qty < 0:
                                    move = self.create_move(product_variant_id, -qty, price, stock_location, virtual_location, company)
                                count += 1
                                
                            if Direct_to_Client_stock_location and virtual_location:
                                qty = raw.get('Qty On Hand Direct to Client (Canada)',0) and float(raw.get('Qty On Hand Direct to Client (Canada)',0)) or 0
                                price = raw.get('Unit Cost Direct to Client (Canada)',0) and float(raw.get('Unit Cost Direct to Client (Canada)',0)) or 0
                                stock_location = Direct_to_Client_stock_location
                                if qty > 0:
                                    move = self.create_move(product_variant_id, qty, price, virtual_location, stock_location, company)
                                if qty < 0:
                                    move = self.create_move(product_variant_id, -qty, price, stock_location, virtual_location, company)
                                count += 1
                                
                            if Circle_HQ_stock_location and virtual_location:
                                qty = raw.get('Qty On Hand Circle HQ (Canada)',0) and float(raw.get('Qty On Hand Circle HQ (Canada)',0)) or 0
                                price = raw.get('Unit Cost Circle HQ (Canada)',0) and float(raw.get('Unit Cost Circle HQ (Canada)',0)) or 0
                                stock_location = Circle_HQ_stock_location
                                if qty > 0:
                                    move = self.create_move(product_variant_id, qty, price, virtual_location, stock_location, company)
                                if qty < 0:
                                    move = self.create_move(product_variant_id, -qty, price, stock_location, virtual_location, company)
                                count += 1
                            
            _logger.info("****************** Count................%s", count)
            _logger.info("****************** not product_variant_id.............%s", not_product_list)
            _logger.info("****************** not_vendor_list.............%s", not_vendor_list)

    
    def update_supplier_info(self):
        if self.csv_file: ### 2024-06 CANCO Inventory.csv  ### 2024-06 USCO Inventory.csv
            list_raw_data = self.get_data_from_attchment(self.csv_file, self.csv_file_name)
            
            if not list_raw_data:
                raise UserError(_("Cannot import blank sheet."))
            count = 0
            not_product_list = []
            not_vendor_list = []
            print('lllllllllllllllllllllll***********')
            for raw in list_raw_data:
                print('ccccccccccccccc',raw.get('Company',False))
                company = self.env['res.company'].sudo().search([('name','=',raw.get('Company',False))], limit=1)
                if raw.get('Item Number',False):
                    print('rrrrrrrrrrrrrrrrrrrrrrrrrrrrawrawraw',raw.get('Item Number',False))
                    product = raw.get('Item Number',False)
                    product_id = self.env['product.template'].search([('default_code','=',product), ('company_id','=',company.id)], limit=1)
                    print ("<<<<<product_id,,,,,",product_id)
                    if not product_id:
                        not_product_list.append(product)   
                    vendor = self.env['res.partner'].sudo().search([('cust_code','=',raw.get('Supplier Number',False)),('supplier_rank','>', 0), ('company_id','=',company.id)], limit=1)
                    if not vendor:
                        not_vendor_list.append(raw.get('Supplier Number',False))
                        vals = {
                            'cust_code': raw.get('Supplier Number',False),
                            'name': raw.get('Supplier Name',False),
                            'supplier_rank': 1,
                            'company_type': 'company',
                            'is_company': True,
                            'company_id': company.id
                        }
                        vendor = self.env['res.partner'].create(vals)
                        count += 1
                    if product_id and vendor:
                        supplier_info = self.env['product.supplierinfo'].sudo().search([
                            ('product_tmpl_id', '=', product_id.id),
                            ('partner_id', '=', vendor.id)
                        ], limit=1)
                    
                        if not supplier_info:
                            vals = {
                                'partner_id': vendor.id,
                                'product_tmpl_id': product_id.id
                            }
                            self.env['product.supplierinfo'].create(vals)
                        
                        
            _logger.info("****************** Count................%s", count)
            _logger.info("****************** not product_variant_id.............%s", not_product_list)
            _logger.info("****************** not_vendor_list.............%s", list(set(not_vendor_list)))

    
import base64
import csv
import os
from io import StringIO
from odoo import tools as openerp_tools
import xlrd

from odoo import fields, models, _
import odoo
from odoo.exceptions import UserError
from odoo.tools import pycompat
import datetime as dt
from datetime import timedelta, datetime

import logging

_logger = logging.getLogger(__name__)


class wizard_sale_tax_update(models.TransientModel):
    _name = 'wizard.sale.tax.update'


    ##########   Script to update sale tax based on fiscal position  ###########

    def update_sale_tax(self):
        count = 0
        sale_list = []
        sale_orders = self.env['sale.order'].search([('company_id', '=', 1)]) or False
        print('ssssssssssssssss',sale_orders)
        for sale in sale_orders:
            print('ppppppppppppppppp',sale.name)
            fiscal_position_id = sale.fiscal_position_id or sale.partner_id.property_account_position_id or False
            if not sale.fiscal_position_id:
                sale.fiscal_position_id = sale.partner_id.property_account_position_id and sale.partner_id.property_account_position_id.id or False
            
            if fiscal_position_id and fiscal_position_id.tax_ids:
                for line in sale.order_line:
                    tax_list = []
                    if line.product_id and line.product_id.taxes_id:
                        for tax in line.product_id.taxes_id:
                            for fp_tax_line in fiscal_position_id.tax_ids:
                                print('ttttttttttttttttttttttttttttttttttt',tax,fp_tax_line.tax_src_id, fp_tax_line.tax_dest_id)
                                if tax == fp_tax_line.tax_src_id and fp_tax_line.tax_dest_id:
                                    tax_list.append(fp_tax_line.tax_dest_id.id)
                    if tax_list:
                        print('ttttttttttttttttt',sale.name,tax_list)
                        line.tax_id = tax_list 
                        count += 1
                        sale_list.append(sale.name)
                    

        _logger.info("******************Count................%s", count)
        _logger.info("******************Sale Count............%s....%s", len(list(set(sale_list))), list(set(sale_list)))
        return True


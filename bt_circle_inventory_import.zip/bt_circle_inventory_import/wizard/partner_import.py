import base64
import csv
import os
from io import StringIO
from odoo import tools as openerp_tools
import xlrd

from odoo import fields, models, _
import odoo
from odoo.exceptions import UserError
from odoo.tools import pycompat
import datetime as dt
from datetime import timedelta, datetime

import logging

_logger = logging.getLogger(__name__)


class wizard_customer_data(models.TransientModel):
    _name = 'wizard.customer.data.test'

    def get_data_from_attchment(self, binary_file, file_name):

        list_raw = []
        if '.csv' in file_name:
            response = (base64.b64decode(binary_file))
            res = str(response, 'utf-8')

            for raw_data in csv.DictReader(StringIO(res), delimiter=',', quotechar='"'):
                list_raw.append(raw_data)
        if '.xls' in file_name or '.xlsx' in file_name:
            path = openerp_tools.config['addons_path'].split(",")[-1]
            if '.xls' in file_name:
                fullpath = os.path.join(path, 'Customer Fields.xls')
            if '.xlsx' in file_name:
                fullpath = os.path.join(path, 'Customer Fields.xlsx')
            with open(fullpath, 'wb') as f:
                f.write(base64.decodebytes(binary_file))
            rb = xlrd.open_workbook(fullpath)
            sheet = rb.sheet_by_index(0)
            headers = []
            for rawnum in range(sheet.nraws):
                raw = sheet.raw_values(rawnum)
                if headers:
                    raw_data = {}
                    cell_count = -1
                    for cell in raw:
                        cell_count = cell_count + 1
                        raw_data.update({headers[cell_count]: cell})
                    list_raw.append(raw_data)
                if not headers:
                    headers = raw

        return list_raw

    csv_file_name = fields.Char('CSV File Name', size=64)
    csv_file = fields.Binary('Customer CSV File', required=True)

    ##########   Script to import shipping address  ###########

    def upload_customer_ship_data(self):
        if self.csv_file:
            list_raw_data = self.get_data_from_attchment(self.csv_file, self.csv_file_name)

            if not list_raw_data:
                raise UserError(_("Cannot import blank sheet."))
            count = 0
            not_customer_list = []
            vals = {}
            for raw in list_raw_data:
                if raw.get('IDCUSTSHPT', False):
                    print('iiiiiiiiiiiiiiiiiiiiiiiiiiiiddddddddddd',raw.get('IDCUSTSHPT', False),raw.get('NAMELOCN', False) )

                    company_id = False
                    if raw.get('COMPANY', False):
                        company_id = self.env['res.company'].search(
                            [('name', '=', raw.get('COMPANY', False))], limit=1) or False

                    country_id = False
                    if raw.get('CODECTRY', False):
                        country_id = self.env['res.country'].search([('name','=',raw.get('CODECTRY', False))])
                    state_id = False
                    if raw.get('CODESTTE', False) and country_id:
                        state_id = self.env['res.country.state'].search([('code','=',raw.get('CODESTTE', False)),
                                                                         ('country_id','=',country_id.id)])
                        if not state_id:
                            state_id = self.env['res.country.state'].search([('name','=',raw.get('CODESTTE', False)),
                                                                         ('country_id','=',country_id.id)])

                    parent_id = self.env['res.partner'].search([('cust_code', '=', raw.get('IDCUST', False))], limit=1) or False
                    if not parent_id:
                        not_customer_list.append(raw.get('IDCUST', False))
                    if parent_id:
                        print('ppppppppppppppppp',parent_id.name)
                        vals.update({
                            'parent_id': parent_id.id,
                            'company_id': company_id and company_id.id or False,
                            'company_type': 'person',
                            'type': 'delivery',
                            'customer_rank': 1,
                            'is_company': False,
                         
                            'cust_code': raw.get('IDCUSTSHPT', False) or '',
                            'name': raw.get('NAMELOCN', False) or '',
                            'street': raw.get('TEXTSTRE1', False) or '',
                            'street2': raw.get('TEXTSTRE2', False) or '',
                            'street3': raw.get('TEXTSTRE3', False) or '',
                            'street4': raw.get('TEXTSTRE4', False) or '',
                            'city': raw.get('NAMECITY', False) or '',
                            'state_id': state_id and state_id.id or False,
                            'country_id': country_id and country_id.id or False,
                            'zip': raw.get('CODEPSTL', False) or '',
                            'phone': raw.get('TEXTPHON1', False) or '',
                            'mobile': raw.get('TEXTPHON2', False) or '',
                            'email': raw.get('EMAIL', False),
                            
                            'shipto_custid': raw.get('IDCUST', False),
                            'custid_shipment': raw.get('IDCUSTSHPT', False),
                            'code_TERR': raw.get('CODETERR', False),
                            'code_TAXGRP': raw.get('CODETAXGRP', False),
                            'id_TAXREGI5': raw.get('IDTAXREGI5', False), ## only IDTAXREGI5 have values in the sheet
                            'shipment_code': raw.get('SHPVIACODE', False),
                            'shipment_description': raw.get('SHPVIADESC', False),
                            'ctac_fax': raw.get('CTACFAX', False),
                            'ctac_name': raw.get('NAMECTAC', False),
                            'ctac_phone': raw.get('CTACPHONE', False),
                            'email_2': raw.get('CTACEMAIL', False),
                            'circle_import_id': raw.get('circle_import_id', False),
                            
                            'tax_STTS1': raw.get('TAXSTTS1', False),
                            'tax_STTS2': raw.get('TAXSTTS2', False),
                            'tax_STTS3': raw.get('TAXSTTS3', False),
                            'tax_STTS4': raw.get('TAXSTTS4', False),
                            'tax_STTS5': raw.get('TAXSTTS5', False),
                            'spc_LINST': raw.get('SPCLINST', False),
                            'code_SLSP1': raw.get('CODESLSP1', False),
                            'pctsasplt1': raw.get('PCTSASPLT1', False),
                            'pric_list': raw.get('PRICLIST', False),
                            'fob': raw.get('FOB', False),
                            'swp_RIMSHPT': raw.get('SWPRIMSHPT', False),
                            'location_import': raw.get('LOCATION', False),
                            'ewarver': raw.get('EWARVER', False),
                            'values': raw.get('VALUES', False),
                        })
                        customer = self.env['res.partner'].create(vals)

                        count += 1
                        _logger.info("******************Count................%s", count)
                else:
                    continue
            _logger.info("******************Count................%s", count)
            _logger.info("******************not customer_list..............%s..%s", len(list(set(not_customer_list))), list(set(not_customer_list)))
            return True


{
    'name': 'BT circle Trial Balance Import',
    'version': '16.0.1.1',
    'author' : 'Your odoo partner',
    'website' : 'http://yourodoopartner.com/',
    'license': 'OPL-1',
    'category':  'Accounting',
    'summary': 'Import Trial Balance',
    'description':
        """Import Trial Balance.
        """,
    'depends': ['base','account','account_reports'],
    'data': [
            'security/ir.model.access.csv',
            'wizard/trial_balance_import_views.xml',


    ],
    'qweb': [
    ],
    'installable': True,
    'auto_install': False,
}
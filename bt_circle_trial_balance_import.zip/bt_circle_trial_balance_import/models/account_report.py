from odoo import models, _, fields


class TrialBalanceCustomHandler(models.AbstractModel):
    _inherit = 'account.trial.balance.report.handler'

    def _custom_line_postprocessor(self, report, options, lines):
        # If the hierarchy is enabled, ensure to add the o_account_coa_column_contrast class to the hierarchy lines
        if options.get('hierarchy'):
            for line in lines:
                model, dummy = report._get_model_info_from_id(line['id'])
                if model == 'account.group':
                    line_classes = line.get('class', '')
                    line['class'] = line_classes + ' o_account_coa_column_contrast_hierarchy'
        #to remove the customised line
        remove_amounts = []
        lines_to_keep = []
        for line in lines:
            if line.get('name') == '999999 Opening Balance GL' or line.get('name') == '112001 Bank Suspense Account':
                remove_amounts.append(line['columns'])
            else:
                lines_to_keep.append(line)

        if remove_amounts:
            remove_amounts = remove_amounts[0]
            for line in lines_to_keep:
                if 'total' in line.get('class', ''):
                    for i in range(len(line['columns'])):
                        line['columns'][i]['no_format'] -= remove_amounts[i]['no_format']
                        line['columns'][i]['name'] = "{:,.2f}".format(line['columns'][i]['no_format']) + "\xa0$"
                    break

        return lines_to_keep

from odoo import models, fields, api, _
from odoo.exceptions import UserError
import base64
import csv
from io import StringIO
import logging
_logger = logging.getLogger(__name__)

class JetMailUploadWizard(models.TransientModel):
    _name = 'jet.mail.upload.wizard'
    _description = 'Upload Jet Mail CSV to update products'

    csv_file_name = fields.Char('CSV File Name', size=64)
    csv_file = fields.Binary('CSV File', required=True)



    def upload_jet_mail_reference(self):

        if not self.csv_file:
            raise UserError(_("Please upload a valid CSV file."))

        try:
            iteration_count = 0
            decoded_file = base64.b64decode(self.csv_file)
            csv_data = StringIO(decoded_file.decode("utf-8"))
            reader = csv.reader(csv_data, delimiter=',')
        except Exception as e:
            raise UserError(_("Could not read CSV file: %s") % str(e))

        updated_count = 0
        not_present_products = []

        for index, row in enumerate(reader):
            iteration_count += 1
            _logger.info("Iteration: %s", iteration_count)
            if index == 0:
                continue

            if not row or not row[0].strip():
                continue

            default_code = row[0].strip()


            product = self.env['product.product'].search([
                ('default_code', '=', default_code),
                ('default_shipping_type', '=', 'jetmail')
            ], limit=1)


            if product:

                product.jet_mail_reference = default_code

                updated_count += 1
            else:
                not_present_products.append(default_code)

        _logger.info("Total products updated: %s", updated_count)
        _logger.warning("Products not found: %s", not_present_products)

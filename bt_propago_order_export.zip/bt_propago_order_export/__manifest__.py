{
    'name': 'Propago Order Export',
    'version': '15.0',
    'category': 'sale',
    'description': """
         export Sales Orders from Odoo to Propago, specifically for orders with the shipment type set to Jet Mail.
    """,
    'author': 'BroadTech IT Solutions Pvt Ltd',
    'website': 'http://www.broadtech-innovations.com',
    'depends': ['bt_jetmail_integration','fedex_shipping_integration'],
    'data': [
        'security/ir.model.access.csv',
        'wizard/jet_mail_upload_wizard_view.xml',
        'views/res_company_view.xml',
        'views/sale_view.xml',
        'views/product_product_view.xml',
        'data/ir_cron.xml',
        ],

    'license': 'AGPL-3',
    'installable': True,
    'auto_install': False,
    'web_preload': False,
}

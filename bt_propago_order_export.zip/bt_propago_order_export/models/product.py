from odoo import models, fields, api, _
from odoo.exceptions import UserError
import base64
import requests
import json
import logging
_logger = logging.getLogger(__name__)


class ProductProduct(models.Model):
    _inherit = 'product.product'



    jetmail_stock_ids = fields.One2many('jetmail.stock', 'product_id', string='Jetmail Stock')

    latest_jetmail_qty = fields.Float(string='JetMail QOH',compute = '_compute_latest_jetmail_qty')

    jetmail_qty = fields.Integer(string="Jetmail Qty",default=1)
    default_shipping_type = fields.Selection(selection_add=[('virtual', 'Virtual')])

    def _compute_latest_jetmail_qty(self):
        for product in self:

            latest_stock = product.jetmail_stock_ids.sorted(lambda x: x.last_synced, reverse=True)[:1]
            product.latest_jetmail_qty = latest_stock.qty_available if latest_stock else 0.0


    def jet_mail_reference_upload(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Upload Jet Mail CSV',
            'res_model': 'jet.mail.upload.wizard',
            'view_mode': 'form',
            'target': 'new',
        }

    def fetch_jetmail_stock(self):
        company = self.env['res.company'].search([
            ('propago_api_user_name', '!=', False),
            ('propago_api_key', '!=', False),
            ('propago_base_url', '!=', False)
        ], limit=1)

        if not company:
            raise UserError("No company found with Jetmail API credentials configured.")
        api_url = company.propago_base_url
        username = company.propago_api_user_name
        password = company.propago_api_key
        token = base64.b64encode(f"{username}:{password}".encode()).decode("utf-8")
        headers = {
            "accept": "application/json",
            "Authorization": f"Basic {token}",
            "Content-Type": "application/json"
        }
        products = self.search([('default_shipping_type', '=', 'jetmail')])
        for product in products:
            sku = product.jet_mail_reference
            get_url = f"{api_url.rstrip('/')}/v2/parts/inventory/{sku}"
            try:
                response = requests.get(get_url, headers=headers, data=json.dumps(sku))
                status = response.status_code
                response_body = response.text
                if response.status_code != 200:
                    raise UserError(_("Failed to fetch Jetmail stock for SKU %s.") % sku)
                stock_data = response.json()
                results = stock_data.get('results')
                if not isinstance(results, dict):
                    _logger.warning("Empty or invalid 'results' for SKU %s. Skipping.", sku)
                    continue

                qty_available = results.get('qtyOnHand')


                self.env['jetmail.stock'].create({
                    'product_id': product.id,
                    'qty_available': qty_available,
                    'last_synced': fields.Datetime.now(),
                })


            except Exception as e:
                _logger.exception("Error fetching Jetmail stock for SKU %s: %s", sku, str(e))

    def jet_mail_stock_fetch(self):

        for product in self:

            if product.default_shipping_type != 'jetmail':
                continue

            company = self.env['res.company'].search([
                ('propago_api_user_name', '!=', False),
                ('propago_api_key', '!=', False),
                ('propago_base_url', '!=', False)
            ], limit=1)


            if not company:
                raise UserError("No company found with Jetmail API credentials configured.")

            api_url = company.propago_base_url

            username = company.propago_api_user_name

            password = company.propago_api_key

            token = base64.b64encode(f"{username}:{password}".encode()).decode("utf-8")

            headers = {
                "accept": "application/json",
                "Authorization": f"Basic {token}",
                "Content-Type": "application/json"
            }


            sku = product.jet_mail_reference

            if not sku:
                raise UserError(_("JetMail Reference (SKU) is not set for this product."))
            get_url = f"{api_url.rstrip('/')}/v2/parts/inventory/{sku}"
            try:
                response = requests.get(get_url, headers=headers, data=json.dumps(sku))

                status = response.status_code

                response_body = response.text

                if response.status_code != 200:
                    raise UserError(_("Failed to fetch Jetmail stock for SKU %s.") % sku)
                stock_data = response.json()

                results = stock_data.get('results')

                if not isinstance(results, dict):
                    _logger.warning("Empty or invalid 'results' for SKU %s. Skipping.", sku)
                    continue

                qty_available = results.get('qtyOnHand')



                self.env['jetmail.stock'].create({
                    'product_id': product.id,
                    'qty_available': qty_available,
                    'last_synced': fields.Datetime.now(),
                })


            except Exception as e:
                _logger.exception("Error fetching Jetmail stock for SKU %s: %s", sku, str(e))
                raise UserError(_("Error fetching Jetmail stock: %s") % str(e))






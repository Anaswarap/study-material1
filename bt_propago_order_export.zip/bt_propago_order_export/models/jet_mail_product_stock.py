from odoo import models, fields


class JetMailStock(models.Model):
    _name = 'jetmail.stock'
    _description = 'JetMail Stock'

    product_id = fields.Many2one('product.product', string='Product', ondelete='cascade')
    qty_available = fields.Float(string='Qty Available')
    last_synced = fields.Datetime(string='Last Synced')


from odoo import models, fields, api, _
from odoo.exceptions import UserError
import base64
import requests
import logging
import pprint
import json
from datetime import datetime
_logger = logging.getLogger(__name__)



class SaleOrder(models.Model):
    _inherit = 'sale.order'

    def _get_disable_send_to_jetmail(self):
        return self.env.user.company_id.disable_send_to_jetmail

    jet_mail_reference = fields.Char("Jet Mail Reference",readonly=True, copy=False)
    jet_mail_request_log = fields.Text("Jet Mail Request Log",readonly=True, copy=False)
    jet_mail_response_log = fields.Text("Jet Mail Response Log",readonly=True, copy=False)
    jet_mail_sent = fields.Boolean("Jet Mail Sent", default=False,readonly=True)
    jet_mail_reference_url = fields.Char(compute="_compute_jet_mail_reference_url",store=False)
    disable_send_to_jetmail = fields.Boolean(string='Disable Jetmail',default=_get_disable_send_to_jetmail, readonly=True,index=True, states={'draft': [('readonly', False)], 'sent': [('readonly', False)]}, copy=False)
    carrier_tracking_ref = fields.Char(tracking=True)
    update_track_ref = fields.Boolean("Track Ref Update", default=False,readonly=True)
    client_order_ref = fields.Char(tracking=True)
    jet_mail_order_status = fields.Char("Jet Mail Status",readonly=True, copy=False)



    @api.depends('jet_mail_reference')
    def _compute_jet_mail_reference_url(self):
        base_url = "https://portal.jet-mail.com/ypqCL4V/Admin/Orders/Edit/"
        for order in self:
            if order.jet_mail_reference:
                order.jet_mail_reference_url = base_url + order.jet_mail_reference
            else:
                order.jet_mail_reference_url = False

    def action_open_jet_mail_url(self):
        self.ensure_one()
        if self.jet_mail_reference_url:
            return {
                'type': 'ir.actions.act_url',
                'url': self.jet_mail_reference_url,
                'target': 'new',
            }
        else:
            raise UserError("Jet Mail reference not found.")

    def action_send_to_propago(self):

        for order in self:

            jet_mail_lines = order.order_line.filtered(lambda l: l.default_shipping_type == 'jetmail')
            if not jet_mail_lines:
                continue

            shipping_phone = order.partner_shipping_id.phone
            
            if not shipping_phone:
                raise UserError(
                    "Jet Mail Error: Delivery address phone number is missing. "
                    "Please update the contact details before sending to Jet Mail."
                )
            company = order.company_id

            api_url = company.propago_base_url

            username = company.propago_api_user_name

            password = company.propago_api_key

            if not username or not password:
                raise UserError("Propago API credentials are missing in Company Settings. Please configure")
            token = base64.b64encode(f"{username}:{password}".encode()).decode("utf-8")

            headers = {
                "accept": "text/plain",
                "Authorization": f"Basic {token}",
                "Content-Type": "application/json"
            }

            base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url') or ''
            base_url = base_url.strip().lower()
            is_test_env = base_url in [
                'https://staging.btlnetusa.com',
                'https://preproduction.btlnetusa.com'
            ]
            if is_test_env:
                company.use_test_product = True
            order_not_cancelled = False
            if order.jet_mail_reference:

                get_url = f"{api_url.rstrip('/')}/v2/orders/{order.jet_mail_reference}"

                payload = {"orderNumber": order.jet_mail_reference}

                try:
                    response = requests.get(get_url, headers=headers,data=json.dumps(payload))

                    if response.status_code != 200:
                        _logger.info(f"Failed to fetch Jet Mail order status. Status: {response.status_code}\nResponse: {response.text}")

                    order_data = response.json()

                    results_data = order_data.get('results')

                    if not results_data:
                        _logger.info(f"Jet Mail response missing 'results' key: {order_data}")

                    order_status = results_data.get('status')

                    if order_status != 'Canceled':
                        order_not_cancelled = True
                        _logger.info(f"Jet Mail order '{order.jet_mail_reference}' status is '{order_status}', not 'cancel'")
                except Exception as e:
                    _logger.info(f"Failed to check existing Jet Mail order status: {str(e)}")
            
            if not order_not_cancelled:
                shipping_email = order.partner_shipping_id.email
                billing_email = order.partner_id.email
                if shipping_email:
                    valid_email = shipping_email
                elif billing_email:
                    valid_email = billing_email
                    order.message_post(body="Jet Mail: Delivery address email was missing. Used parent account email instead.")
                else:
                    raise UserError("Jet Mail Error: Both the Delivery Address and Customer account email addresses are missing .""Please update the contact details before sending to Jet Mail.")
                missing_refs = [
                    line.product_id.name
                    for line in jet_mail_lines
                    if not line.product_id.jet_mail_reference
                ]

                if missing_refs:

                    raise UserError(
                        "Jet Mail Error: The following products are missing Jetmail References:\n%s" %
                        "\n".join(missing_refs)
                    )
                post_url = api_url.rstrip("/") + "/v2/orders/create"

                payload = {
                    # "signatureRequired": False,
                    "signatureRequired": True if order.jetmail_signature_required else False,
                    "isExpedited": False,
                    "promoCode": "",
                    "invoiceEmail": "",
                    "mailInvoice": False,
                    "username": "",
                    "orderTag": "",
                    "comments": "",
                    "alternativeEmail": "",
                    "carrier": "Ground",
                    "desiredShipDate": datetime.utcnow().isoformat() + "Z",
                    "shippingAddress": {
                        "company": order.partner_id.name,
                        "contact": order.partner_id.name,
                        "address1": order.partner_shipping_id.street,
                        "address2": order.partner_shipping_id.street2,
                        "address3": "",
                        "city": order.partner_shipping_id.city,
                        "state": order.partner_id.state_id.name,
                        "country": order.partner_shipping_id.country_id.name,
                        "zip": order.partner_shipping_id.zip,
                        # "phone": order.partner_shipping_id.phone,
                        "phone": shipping_phone,
                        # "email": order.partner_shipping_id.email,
                        "email": valid_email,
                        # "isResidential": False,
                        "isResidential": order.partner_shipping_id.residential or False,
                        "isSignatureRequired": True if order.jetmail_signature_required else False
                    },
                    "accountingUnit": "",
                    "billingAddress": {
                        "company": order.partner_id.name,
                        "contact": order.partner_id.name,
                        "address1": order.partner_shipping_id.street,
                        "address2": order.partner_shipping_id.street2,
                        "city": order.partner_shipping_id.city,
                        "state": order.partner_id.state_id.name,
                        "country": order.partner_shipping_id.country_id.name,
                        "zip": order.partner_shipping_id.zip
                    },
                    "placeOrderLines": [
                        {
                            "sku": "BTL-TEST-SKU" if is_test_env and company.use_test_product else (line.product_id.jet_mail_reference),
                            "quantity": int(line.product_uom_qty * line.product_id.jetmail_qty),
                            "custom01": "",
                            "custom02": "",
                            "custom03": "",
                            "printFile": ""
                        }for line in jet_mail_lines
                    ],
                    "orderField1": "",
                    "orderField2": "",
                    "orderField3": "",
                    "orderField4": "",
                    "orderField5": "",
                    "poNumber": "",
                    "verifyPONumber": False,
                    "thirdPartyAccountNumber": "",
                    "doNotSendNotificationEmails": None,
                    # "customFields": [
                    #     {
                    #         "key": "order_name",
                    #         "value": order.name
                    #     },
                    #     {
                    #         "key": "carrier_tracking_ref",
                    #         "value": order.carrier_tracking_ref
                    #     }
                    # ]
                }

                _logger.info("data:\n%s", pprint.pformat(payload))
                # headers = {
                #     "accept": "text/plain",
                #     "Authorization": f"Basic {token}",
                #     "Content-Type": "application/json"
                # }

                try:
                    response = requests.post(post_url, headers=headers, data=json.dumps(payload))

                    status = response.status_code

                    response_body = response.text


                    order.jet_mail_request_log = pprint.pformat(payload)

                    if status == 200:
                        resp_data = response.json()

                        order_ref = resp_data.get("results", "")





                        if order_ref:
                            order.jet_mail_reference = order_ref

                            order.client_order_ref = order_ref



                            order.jet_mail_sent = True
                            order.jet_mail_response_log = (
                                f"Status: SUCCESS\n"
                                f"HTTP Status: {status}\n"
                                f"Reference: {order_ref}\n"
                                f"Response Body:\n{response_body}"
                            )
                            order.message_post(body=f"Order successfully sent to Jet Mail. Reference: {order_ref}")
                        else:
                            order.jet_mail_response_log = (
                                f"Status: FAILURE (No reference returned)\n"
                                f"HTTP Status: {status}\n"
                                f"Response Body:\n{response_body}"
                            )
                            order.message_post(body="Jet Mail response did not return a reference.")


                    else:
                        order.jet_mail_response_log = (
                            f"Status: FAILURE\n"
                            f"HTTP Status: {status}\n"
                            f"Response Body:\n{response_body}"
                        )
                        order.message_post(body=f"Jet Mail order failed. Status: {status}")


                except Exception as e:
                    error_message = str(e)
                    order.jet_mail_request_log = pprint.pformat(payload)
                    order.jet_mail_response_log = (
                        f"Status: FAILURE (Exception)\n"
                        f"Error Message:\n{error_message}"
                    )
                    _logger.exception("Jet Mail API Exception")
                    order.message_post(body=f"Jet Mail order failed due to exception: {error_message}")





    def cron_update_tracking_refs_from_jetmail(self):
        orders = self.search([
            ('jet_mail_reference', '!=', False),
            ('update_track_ref', '=', False)
        ])




        for order in orders:
            company = order.company_id

            api_url = company.propago_base_url

            username = company.propago_api_user_name

            password = company.propago_api_key

            if not username or not password:
                raise UserError("Propago API credentials are missing in Company Settings. Please configure")
            token = base64.b64encode(f"{username}:{password}".encode()).decode("utf-8")

            headers = {
                "accept": "application/json",
                "Authorization": f"Basic {token}",
                "Content-Type": "application/json"
            }


            payload = {"orderNumber": order.jet_mail_reference}


            get_url = f"{api_url.rstrip('/')}/v2/orders/{order.jet_mail_reference}"


            response = requests.get(get_url, headers=headers, data=json.dumps(payload))

            status = response.status_code


            response_body = response.text

            if response.status_code != 200:
                _logger.info(("Failed to fetch order from Jet Mail: %s") % response.text)

            order_data = response.json()

            results_data = order_data.get('results')
            if not results_data:
                _logger.info(f"Jet Mail response missing 'results' key: {order_data}")

            order_status = results_data.get('status')


            order.jet_mail_order_status = order_status



            if order_status == 'Canceled':
                continue


            get_tracking_url = f"{api_url.rstrip('/')}/v2/orders/{order.jet_mail_reference}/shipments"


            tracking_payload = {"orderNumber": order.jet_mail_reference}


            tracking_response = requests.get(get_tracking_url, headers=headers, data=json.dumps(tracking_payload))


            status = tracking_response.status_code


            response_body = tracking_response.text


            if tracking_response.status_code != 200:
                _logger.info(("Failed to fetch shipment info from Jet Mail: %s") % tracking_response.text)

            tracking_order_data = tracking_response.json()


            tracking_numbers = []
            for result in tracking_order_data.get("results", []):
                for detail in result.get("shipmentDetails", []):
                    tracking_number = detail.get("trackingNumber")
                    if tracking_number:
                        tracking_numbers.append(tracking_number)

            tracking_ref_string = ' '.join(tracking_numbers)

            if tracking_ref_string:
                if order.carrier_tracking_ref:
                    order.carrier_tracking_ref = f"{order.carrier_tracking_ref} {tracking_ref_string}"
    
                else:
                    order.carrier_tracking_ref = tracking_ref_string
    
                order.message_post(
                    body=(
                        f"Tracking number updated from jet mail: {order.carrier_tracking_ref}<br/>"
                        f"Jet Mail Order Status: {order.jet_mail_order_status}"
                    )
                )
    
                order.update_track_ref = True



    def action_confirm(self):
        res = super(SaleOrder, self).action_confirm()
        for order in self:
            if not order.disable_send_to_jetmail:
                order.action_send_to_propago()
        return res

    def generate_jet_mail_product_inventory_excel(self):
        return True

class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    default_shipping_type = fields.Selection(selection_add=[('virtual', 'Virtual')])

class stockMove(models.Model):
    _inherit = 'stock.move'

    default_shipping_type = fields.Selection(selection_add=[('virtual', 'Virtual')])


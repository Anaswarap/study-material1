

from odoo import models, fields

class ResCompany(models.Model):
    _inherit = 'res.company'

    propago_base_url = fields.Char(string="Propago API URL")
    propago_api_user_name = fields.Char(string="Propago API Username")
    propago_api_key = fields.Char(string="Propago API Key")
    disable_send_to_jetmail = fields.Boolean(string='Disable Send to Jetmail')
    use_test_product = fields.Boolean(string="Use Test SKU Product", default=False)

from odoo import api, fields, models, _
from odoo.exceptions import UserError
from odoo import api, fields, models, tools
from datetime import datetime, timedelta

    
    
class Menu(models.Model):
    _inherit = 'ir.ui.menu'

    @api.model
    @tools.ormcache('frozenset(self.env.user.groups_id.ids)', 'debug')
    def _visible_menu_ids(self, debug=False):
        menus = super(Menu,self)._visible_menu_ids(debug)
        if self.env.ref('bt_circle_access_rights.group_restrict_to_sales_crm').id in self.env.user.groups_id.ids:
            menus.discard(self.env.ref("contacts.menu_contacts").id)
            menus.discard(self.env.ref("account_accountant.menu_accounting").id)
            menus.discard(self.env.ref("mail.menu_root_discuss").id)
            menus.discard(self.env.ref("calendar.mail_menu_calendar").id)
            menus.discard(self.env.ref("spreadsheet_dashboard.spreadsheet_dashboard_menu_root").id)
            menus.discard(self.env.ref("point_of_sale.menu_point_root").id)
            menus.discard(self.env.ref("purchase.menu_purchase_root").id)
            menus.discard(self.env.ref("mrp.menu_mrp_root").id)
            menus.discard(self.env.ref("hr.menu_hr_root").id)
            menus.discard(self.env.ref("hr_expense.menu_hr_expense_root").id)
            menus.discard(self.env.ref("stock.menu_stock_root").id)
            menus.discard(self.env.ref("website.menu_website_configuration").id)
            menus.discard(self.env.ref("base.menu_management").id)
            menus.discard(self.env.ref("base.menu_administration").id)
            menus.discard(self.env.ref("account_consolidation.menu_consolidation").id)
            menus.discard(self.env.ref("utm.menu_link_tracker_root").id)
            menus.discard(self.env.ref("account.menu_finance").id)
            menus.discard(self.env.ref("stock_barcode.stock_barcode_menu").id)
        if self.env.ref('bt_circle_access_rights.group_restrict_account_sale_menus').id in self.env.user.groups_id.ids:
            # menus.discard(self.env.ref("account.menu_finance").id)
            menus.discard(self.env.ref("account_accountant.menu_accounting").id)
        if self.env.ref('bt_circle_access_rights.group_restrict_sale_menu').id in self.env.user.groups_id.ids:
            menus.discard(self.env.ref("sale.sale_menu_root").id)
        if not self.env.ref('bt_circle_access_rights.group_specific_menu_access_id').id in self.env.user.groups_id.ids:
            menus.discard(self.env.ref("website.menu_website_configuration").id)
            menus.discard(self.env.ref("s2u_shopify.menu_shopify").id)
            menus.discard(self.env.ref("hr.menu_hr_root").id)
            menus.discard(self.env.ref("hr_expense.menu_hr_expense_root").id)
            menus.discard(self.env.ref("base.menu_management").id)

        return menus
    
    
class Users(models.Model):
    _inherit = 'res.users'
    
    account_partner_ids = fields.Many2many('res.partner', 'user_account_partner_rel',
        'user_id', 'partner_id', string='Restrict to Vendors')


class SpreadsheetDashboardGroups(models.Model):
    _inherit = 'spreadsheet.dashboard.group'

    def adding_groups_sale_dashboard(self):
        dashboard = self.env['spreadsheet.dashboard'].search([
            ('id', 'in', [
                self.env.ref('spreadsheet_dashboard_sale.spreadsheet_dashboard_sales').id,
                self.env.ref('spreadsheet_dashboard_sale.spreadsheet_dashboard_product').id])])
        if dashboard:
            removed_group_id = self.env.ref('sales_team.group_sale_salesman').id
            group_id = self.env.ref('bt_circle_access_rights.group_specific_menu_access_id').id
            dashboard.write({'group_ids': [(3, removed_group_id)]})
            dashboard.write({'group_ids': [(4, group_id)]})
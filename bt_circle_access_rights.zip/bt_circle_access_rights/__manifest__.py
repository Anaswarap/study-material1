# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.


{
    'name': 'Circle User Permissions',
    'version': '16.0.0.5',
    'author' : 'Your odoo partner',
    'website' : 'http://yourodoopartner.com/',
    'license': 'OPL-1',
    'category':  'Account',
    'summary': 'Circle User Permissions',
    'description':
        """Circle User Permissions
        """,
    'depends': ['account_accountant','account_reports',
                'sale_stock','stock','contacts','purchase','hr_expense',
                'account_consolidation','stock_barcode','utm'],
    'data': [
        'security/ir.model.access.csv',
        'security/circle_user_security.xml',
        'views/user_view.xml',
    ],
    'qweb': [
    ],
    'installable': True,
    'auto_install': False,
}

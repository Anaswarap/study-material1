# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name': 'BT Circle 3PL Invoice Report ',
    'version': '16.0',
    'summary': """BT Circle 3PL Invoice Report Xlsx """,
    'license':'LGPL-3',
    'description': """
    BT Circle 3PL Invoice Report Xlsx 
""",
    'author' : 'Your odoo partner',
    'website' : 'http://yourodoopartner.com/',
    'depends': ['base','account','bt_edi_import'],
    'images': [],
    'data': [
            'security/ir.model.access.csv',
            'wizard/print_invoice_report_xlsx_view.xml',
            'views/product_template_view.xml',
            'views/account_account_view.xml'
    ],



    'qweb': [],
    'installable': True,
    'auto_install': False,
    'application': True
}

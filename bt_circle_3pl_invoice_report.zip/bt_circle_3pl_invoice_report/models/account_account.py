# -*- coding: utf-8 -*-

from odoo import api, fields, models, _



class AccountAccount(models.Model):
    _inherit = 'account.account'

    cost_of_good_sold = fields.Boolean(default=False, string='Cost Of Good Sold', help='3PL  Reconcillation Report')
# -*- coding: utf-8 -*-

from odoo import api, fields, models, _



class ProductTemplate(models.Model):
    _inherit = 'product.template'

    shipping_product = fields.Boolean(default=False, string='Shipping Product', help='3PL  Reconcillation Report')
# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import models, fields, api, _
from odoo.exceptions import UserError
import xlwt
from xlwt import easyxf, Formula
import datetime
import io
import base64


class PrintXlsxReportInvoice(models.TransientModel):
    _name = "print.xlsx.report.invoice"
    _description = "print sale order"

    file = fields.Binary('Invoice Report')
    file_name = fields.Char('File Name')
    report_printed = fields.Boolean('Report Printed')

    def action_print(self):

        workbook = xlwt.Workbook()
        sheet = workbook.add_sheet('3PL Invoice Report', cell_overwrite_ok=True)


        column_heading_style = easyxf('font:height 200;font:bold True;align:horiz left;align:vertical center;')
        report_header_style = easyxf('font:name Arial;font:height 250;font: colour black,bold True;borders: top_color olive_ega, bottom_color olive_ega, right_color olive_ega, left_color olive_ega,\
                                             left dotted, right dotted, top dotted, bottom dotted;align:vertical center;align:horizontal center;pattern: pattern solid, fore_colour white')


        sheet.write_merge(0, 0, 0, 10, 'Invoice Report', report_header_style)
        headers = ['Customer Name', 'Customer Number', 'Order Number', 'Customer PO number', 'Order Date',
                   'Invoice or Credit number', 'Invoice Date', 'Order Cogs', 'Prepaid Shipping value',
                   'Pre Tax Order Value', 'EDI count']
        for col, header in enumerate(headers):
            sheet.write(3, col, header, column_heading_style)


        col_widths = [7500, 4500, 4500, 7500, 4500, 7500, 4500, 4500, 7500, 7500, 4500]
        for col, width in enumerate(col_widths):
            sheet.col(col).width = width


        row = 4
        active_list = self._context.get('active_ids', [])
        account_moves = self.env['account.move'].browse(active_list)
        for move in account_moves:
            sheet.write(row, 0, move.partner_id.name or '')
            sheet.write(row, 1, move.partner_id.cust_code or '')
            sheet.write(row, 2, ', '.join(move.invoice_line_ids.mapped('sale_line_ids.order_id.name')) or '')
            sheet.write(row, 3, ', '.join([po or '' for po in move.invoice_line_ids.mapped('sale_line_ids.order_id.customer_po')]) or '')
            sheet.write(row, 4, ', '.join(date.strftime('%Y-%m-%d') for date in move.invoice_line_ids.mapped('sale_line_ids.order_id.date_order')if date) or '')
            sheet.write(row, 5, move.name or '')
            sheet.write(row, 6, move.date.strftime('%Y-%m-%d') if move.date else '')
            cogs_lines = move.line_ids.filtered(lambda line: line.account_id.cost_of_good_sold == True)
            cogs_debit_value = sum(line.debit for line in cogs_lines)
            sheet.write(row, 7, cogs_debit_value or 0.0)
            transport_line = move.sale_id.prepaid_freight
            sheet.write(row, 8, transport_line)
            sheet.write(row, 9, move.amount_untaxed)
            sale_orders = move.invoice_line_ids.mapped('sale_line_ids.order_id')
            edi_count = 0
            for order in sale_orders:
                if order.from_edi:
                    pickings = self.env['stock.picking'].search([('sale_id', '=', order.id)])
                    edi_count = sum(picking.edi_940_sent_count for picking in pickings)
            sheet.write(row, 10, edi_count)
            row += 1


        fp = io.BytesIO()
        workbook.save(fp)
        excel_file = base64.b64encode(fp.getvalue()).decode('utf-8')
        fp.close()


        self.file = excel_file
        self.file_name = 'Invoice Order Report.xls'
        self.report_printed = True


        return {
            'view_mode': 'form',
            'res_id': self.id,
            'res_model': 'print.xlsx.report.invoice',
            'view_type': 'form',
            'type': 'ir.actions.act_window',
            'context': self.env.context,
            'target': 'new',
        }


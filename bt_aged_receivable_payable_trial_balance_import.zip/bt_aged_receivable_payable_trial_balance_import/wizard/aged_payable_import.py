import tempfile
import binascii
import datetime
import xlrd
import logging
_logger = logging.getLogger(__name__)
from odoo import models, fields, _
from odoo.exceptions import UserError


class ImportAgedPayable(models.TransientModel):
    _name = 'import.aged.payable'

    xls_file_name = fields.Char('Excel File Name', size=64, required=True)
    xls_file = fields.Binary('Excel File')
    customer_currency_id = fields.Many2one('res.currency', 'Currency')
    journal_id = fields.Many2one('account.journal','Journal')

    def import_aged_payable_data(self):

        try:
            iteration_count = 0
            invoice_date = False
            due_date = False
            partner = False
            bill_reference = False
            file_string = tempfile.NamedTemporaryFile(suffix=".xlsx")
            file_string.write(binascii.a2b_base64(self.xls_file))
            book = xlrd.open_workbook(file_string.name)
        except:
            raise UserError(_("Please choose the .xlsx file"))
        for sheet in book.sheets():
            try:

                default_product_id = self.env['product.product'].search([('name', '=', 'Demo Product'), ('company_id.name', '=', 'Circle Sales & Import USA Inc.')])

                default_company_id = self.env['res.company'].search([('name', '=', 'Circle Sales & Import USA Inc.')])

                default_expense_account_id = self.env['account.account'].search([('code', '=', '400001'), ('company_id.name', '=', 'Circle Sales & Import USA Inc.')])

                default_journal_id = self.env['account.journal'].search([('name', '=', 'Vendor Bills'), ('company_id.name', '=', 'Circle Sales & Import USA Inc.')])

                payment_journal_id = self.env['account.journal'].search([('name', '=', 'Bank - USCO'), ('company_id.name', '=', 'Circle Sales & Import USA Inc.')])

               

                # if self.customer_currency_id.name == 'USD':
                if sheet.name == 'Sheet1':
                    for row in range(sheet.nrows):

                        iteration_count += 1
                        _logger.info("Iteration: %s", iteration_count)
                        new_invoice_lines = []
                        new_payment_lines = []
                        if row >= 22:
                            row_values = sheet.row_values(row)


                            vendor_code = row_values[7]

                            if row_values[0] and isinstance(row_values[0], (int, float)):

                                convert_int_invoice_date = int(row_values[0])

                                invoice_date_value_timestamp = datetime.datetime(1899, 12, 30) + datetime.timedelta(days=convert_int_invoice_date)

                                invoice_date = invoice_date_value_timestamp.strftime("%Y-%m-%d")

                            else:
                                convert_int_invoice_date = 0
                            if row_values[18]:

                                convert_int_due_date = int(row_values[18])

                                due_date_value_timestamp = datetime.datetime(1899, 12, 30) + datetime.timedelta(days=convert_int_due_date)

                                due_date = due_date_value_timestamp.strftime("%Y-%m-%d")

                            else:
                                convert_int_due_date = 0

                            if row_values[5]:
                                bill_reference = row_values[7]


                            if 'Vendor Total:' in row_values:
                                print("Customer Total found, skipping this row")
                                continue

                            if 'Vendor Name:' in row_values:

                                if vendor_code:

                                    partner = self.env['res.partner'].search([('cust_code', '=', vendor_code),('company_id','=', default_company_id.id),('supplier_rank','>', 0)])

                                    if not partner:


                                        partner = self.env['res.partner'].create({
                                            'is_company': True,
                                            'cust_code': vendor_code,
                                            'name': row_values[26],
                                            'company_id': default_company_id.id,

                                        })




                            else:

                                if row_values[42]:

                                    if row_values[42] < 0:

                                        refund_amount = -row_values[42]


                                        payment_creation = self.env['account.payment'].create({
                                            'partner_id': partner.id,
                                            'payment_type': 'outbound',
                                            'date': invoice_date,
                                            'amount': refund_amount,
                                            'journal_id': payment_journal_id.id,
                                            'currency_id': self.customer_currency_id.id,
                                            'partner_type': 'supplier',

                                        })


                                        payment_creation.action_post()
                                    else:

                                        invoice_line = (0, 0, {
                                            'product_id': default_product_id.id,
                                            'account_id': default_expense_account_id.id,
                                            'quantity': 1,
                                            'price_unit': row_values[42]
                                        })
                                        new_invoice_lines.append(invoice_line)


                                        new_invoice_creation = self.env['account.move'].create({
                                            'partner_id': partner.id,
                                            'invoice_date': invoice_date,
                                            'invoice_date_due': due_date,
                                            'move_type': 'in_invoice',
                                            'journal_id': default_journal_id.id,
                                            'currency_id': self.customer_currency_id.id,
                                            'invoice_line_ids': new_invoice_lines,
                                            'company_id': default_company_id.id,
                                            'ref': bill_reference
                                        })

                                        new_invoice_creation.action_post()















            except IndexError:
                pass
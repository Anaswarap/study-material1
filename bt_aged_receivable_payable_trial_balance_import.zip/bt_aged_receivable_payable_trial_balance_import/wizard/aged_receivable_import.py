import tempfile
import binascii
import datetime
import xlrd
import logging
_logger = logging.getLogger(__name__)
from odoo import models, fields, _
from odoo.exceptions import UserError


class ImportAgedReceivablePayable(models.TransientModel):
    _name = 'import.aged.receivable'

    xls_file_name = fields.Char('Excel File Name', size=64, required=True)
    xls_file = fields.Binary('Excel File')
    customer_currency_id = fields.Many2one('res.currency', 'Currency')
    journal_id = fields.Many2one('account.journal', 'Journal')

    def import_aged_receivable(self):

        try:
            iteration_count = 0
            invoice_date = False
            partner = False
            file_string = tempfile.NamedTemporaryFile(suffix=".xlsx")
            file_string.write(binascii.a2b_base64(self.xls_file))
            book = xlrd.open_workbook(file_string.name)
        except:
            raise UserError(_("Please choose the .xlsx file"))
        for sheet in book.sheets():
            try:

                default_product_id = self.env['product.product'].search([('name', '=', 'Demo Product'),('company_id.name', '=', 'Circle Sales & Import USA Inc.')])


                default_company_id = self.env['res.company'].search([('name','=', 'Circle Sales & Import USA Inc.')])


                default_income_account_id = self.env['account.account'].search([('code', '=', '40000'),('company_id.name', '=', 'Circle Sales & Import USA Inc.')])


                default_journal_id = self.env['account.journal'].search([('name','=', self.journal_id.name),('company_id.name', '=', 'Circle Sales & Import USA Inc.')])


                if self.customer_currency_id.name == 'USD':

                    if sheet.name == 'Sheet1':
                        for row in range(sheet.nrows):

                            iteration_count += 1
                            _logger.info("Iteration: %s", iteration_count)
                            new_invoice_lines = []
                            new_credit_lines = []
                            if row >= 21:

                                row_values = sheet.row_values(row)

                                customer_code = row_values[0]

                                if row_values[14]:

                                    convert_int_invoice_date = int(row_values[14])

                                    invoice_date_value_timestamp = datetime.datetime(1899, 12, 30) + datetime.timedelta(days=convert_int_invoice_date)

                                    invoice_date = invoice_date_value_timestamp.strftime("%Y-%m-%d")


                                else:
                                    convert_int_invoice_date = 0
                                if 'Customer Total:' in row_values:
                                    print("Customer Total found, skipping this row")
                                    continue

                                if customer_code:

                                    partner = self.env['res.partner'].search([('cust_code', '=', customer_code),('company_id','=', default_company_id.id),('customer_rank','>',0)])

                                    if not partner:



                                        partner = self.env['res.partner'].create({
                                            'is_company': True,
                                            'cust_code': customer_code,
                                            'name': row_values[6],
                                            'company_id' : default_company_id.id
                                        })



                                else:
                                    if row_values[37]:
                                        if row_values[37] < 0:

                                            credit_amount = -row_values[37]

                                            credit_line = (0, 0, {
                                                'product_id': default_product_id.id,
                                                'account_id': default_income_account_id.id,
                                                'quantity': 1,
                                                'price_unit': credit_amount
                                            })
                                            new_credit_lines.append(credit_line)

                                            credit_creation = self.env['account.move'].create({
                                                'partner_id': partner.id,
                                                'invoice_date': invoice_date,
                                                'invoice_date_due': row_values[15],
                                                'move_type': 'out_refund',
                                                'journal_id': default_journal_id.id,
                                                'currency_id': self.customer_currency_id.id,
                                                'invoice_line_ids': new_credit_lines,
                                                'company_id': default_company_id.id,
                                                'ref': row_values[4]
                                            })

                                            credit_creation.action_post()
                                        else:

                                            invoice_line = (0, 0, {
                                                'product_id': default_product_id.id,
                                                'account_id': default_income_account_id.id,
                                                'quantity': 1,
                                                'price_unit': row_values[37]
                                            })
                                            new_invoice_lines.append(invoice_line)


                                            new_invoice_creation = self.env['account.move'].create({
                                                'partner_id': partner.id,
                                                'invoice_date': invoice_date,
                                                'invoice_date_due': row_values[15],
                                                'move_type': 'out_invoice',
                                                'journal_id': default_journal_id.id,
                                                'currency_id': self.customer_currency_id.id,
                                                'invoice_line_ids': new_invoice_lines,
                                                'company_id': default_company_id.id,
                                                'ref': row_values[4]
                                            })

                                            new_invoice_creation.action_post()









            except IndexError:
                pass
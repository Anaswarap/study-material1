# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name': 'BT Aged Receivables Payables Trial Balance Import ',
    'version': '16.0',
    'summary': """BT Aged Receivables Payables Trial Balance Import """,
    'license':'LGPL-3',
    'description': """
    BT Aged Receivables Payables Trial Balance Import 
""",
    'author' : 'Your odoo partner',
    'website' : 'http://yourodoopartner.com/',
    'depends': ['base','account','sale'],
    'images': [],
    'data': [
          'security/ir.model.access.csv',
        'wizard/aged_receivable_import_view.xml',
        'wizard/aged_payable_import_view.xml',
        'views/account_move_view.xml'

    ],
    'qweb': [],
    'installable': True,
    'auto_install': False,
    'application': True
}
from odoo import models, fields, api



class AccountMove(models.Model):
    _inherit = 'account.move'


    check_or_recipet_no = fields.Char('Check/Recipet No')
    cad_receivable_import = fields.Boolean(string='Cad Receivable Import',default=False)

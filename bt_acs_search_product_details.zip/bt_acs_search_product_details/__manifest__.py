# -*- coding: utf-8 -*-
{
    'name': "BT Search Product Details",
    'summary': """
     BT Search Product Details
    """,
    'description': """

    """,
    'author': "Broadtech IT solutions pvt lmt",
    'website': "https://www.broadtech-innovations.com",

    'category': '',
    'version': '16.0.1.0.0',
    'depends': ['acs_search_product_details', 'mrp', 'point_of_sale'],

    'data': [
        'views/scan_product_view.xml'
    ],

}

# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _
import xlwt
import io
import base64
from xlwt import easyxf
import datetime
from datetime import time, timedelta

class PrintAgedReceivable(models.TransientModel):
    _name = "print.aged.receivable"
    
    @api.model
    def _get_default_currency(self):
        return self.env.user.company_id and self.env.user.company_id.currency_id or False

    file = fields.Binary('Aged Receivable Report')
    file_name = fields.Char('File Name')
    report_printed = fields.Boolean('Report Printed')
    currency_id = fields.Many2one('res.currency', string='Currency')
    # currency_id = fields.Many2one('res.currency', string='Currency', default=_get_default_currency)
    end_date = fields.Date('End of Date', default=fields.Date.context_today)
    partners_ids = fields.Many2many('res.partner', string='Partners')
    unfold = fields.Boolean('Unfold All', default=True)
    
    
    def action_print_aged_receivable(self):
        workbook = xlwt.Workbook()
        column_heading_style = easyxf('font:height 210;font:bold True;')
        total_column_style = easyxf('font:height 200; font:bold True; align:horiz right;')
        grand_total_column_style = easyxf('font:height 210; font:bold True; align:horiz right;')
        value_column_style_left = easyxf('align:horiz left;')
        value_column_style = easyxf('align:horiz right;')
        worksheet = workbook.add_sheet('Aged Receivable Report')
        row = 0
        for wizard in self:
            # current_date = datetime.date.today()
            current_date = wizard.end_date
            as_of_date = current_date.strftime('%m/%d/%Y')
            col = 0
            worksheet.write(row, col, _(''), column_heading_style)
            col += 1
            worksheet.write(row, col, _('Report Date'), column_heading_style)
            col += 1
            worksheet.write(row, col, _('Journal'), column_heading_style)
            col += 1
            worksheet.write(row, col, _('Account'), column_heading_style)
            col += 1
            worksheet.write(row, col, _('Exp.Date'), column_heading_style)
            
            if not wizard.currency_id:
                col += 1
                worksheet.write(row, col, _('As of: '+ str(as_of_date))+' CAD', grand_total_column_style)
                col += 1
                worksheet.write(row, col, _('As of: '+ str(as_of_date))+' USD', grand_total_column_style)
            if wizard.currency_id and wizard.currency_id.name == 'CAD':
                col += 1
                worksheet.write(row, col, _('As of: '+ str(as_of_date))+' CAD', grand_total_column_style)
            if wizard.currency_id and wizard.currency_id.name == 'USD':    
                col += 1
                worksheet.write(row, col, _('As of: '+ str(as_of_date))+' USD', grand_total_column_style)
            col += 1
            worksheet.write(row, col, _('As of: '+ str(as_of_date))+' Company Currency', grand_total_column_style)
            
            if not wizard.currency_id:
                col += 1
                worksheet.write(row, col, _('1 - 30 CAD'), grand_total_column_style)
                col += 1
                worksheet.write(row, col, _('1 - 30 USD'), grand_total_column_style)
            if wizard.currency_id and wizard.currency_id.name == 'CAD':
                col += 1
                worksheet.write(row, col, _('1 - 30 CAD'), grand_total_column_style)
            if wizard.currency_id and wizard.currency_id.name == 'USD':    
                col += 1
                worksheet.write(row, col, _('1 - 30 USD'), grand_total_column_style)
            col += 1
            worksheet.write(row, col, _('1 - 30 Company Currency'), grand_total_column_style)
            
            if not wizard.currency_id:
                col += 1
                worksheet.write(row, col, _('31 - 60 CAD'), grand_total_column_style)
                col += 1
                worksheet.write(row, col, _('31 - 60 USD'), grand_total_column_style)
            if wizard.currency_id and wizard.currency_id.name == 'CAD':
                col += 1
                worksheet.write(row, col, _('31 - 60 CAD'), grand_total_column_style)
            if wizard.currency_id and wizard.currency_id.name == 'USD':
                col += 1
                worksheet.write(row, col, _('31 - 60 USD'), grand_total_column_style)
            col += 1
            worksheet.write(row, col, _('31 - 60 Company Currency'), grand_total_column_style)
            
            if not wizard.currency_id:
                col += 1
                worksheet.write(row, col, _('61 - 90 CAD'), grand_total_column_style)
                col += 1
                worksheet.write(row, col, _('61 - 90 USD'), grand_total_column_style)
            if wizard.currency_id and wizard.currency_id.name == 'CAD':
                col += 1
                worksheet.write(row, col, _('61 - 90 CAD'), grand_total_column_style)
            if wizard.currency_id and wizard.currency_id.name == 'USD':
                col += 1
                worksheet.write(row, col, _('61 - 90 USD'), grand_total_column_style)
            col += 1
            worksheet.write(row, col, _('61 - 90 Company Currency'), grand_total_column_style)
            
            if not wizard.currency_id:
                col += 1
                worksheet.write(row, col, _('91 - 120 CAD'), grand_total_column_style)
                col += 1
                worksheet.write(row, col, _('91 - 120 USD'), grand_total_column_style)
            if wizard.currency_id and wizard.currency_id.name == 'CAD':
                col += 1
                worksheet.write(row, col, _('91 - 120 CAD'), grand_total_column_style)
            if wizard.currency_id and wizard.currency_id.name == 'USD':
                col += 1
                worksheet.write(row, col, _('91 - 120 USD'), grand_total_column_style)
            col += 1
            worksheet.write(row, col, _('91 - 120 Company Currency'), grand_total_column_style)
            
            if not wizard.currency_id:
                col += 1
                worksheet.write(row, col, _('Older CAD'), grand_total_column_style)
                col += 1
                worksheet.write(row, col, _('Older USD'), grand_total_column_style)
            if wizard.currency_id and wizard.currency_id.name == 'CAD':
                col += 1
                worksheet.write(row, col, _('Older CAD'), grand_total_column_style)
            if wizard.currency_id and wizard.currency_id.name == 'USD':
                col += 1
                worksheet.write(row, col, _('Older USD'), grand_total_column_style)
            col += 1
            worksheet.write(row, col, _('Older Company Currency'), grand_total_column_style)
            
            if not wizard.currency_id:
                col += 1
                worksheet.write(row, col, _('Total CAD'), grand_total_column_style)
                col += 1
                worksheet.write(row, col, _('Total USD'), grand_total_column_style)
            if wizard.currency_id and wizard.currency_id.name == 'CAD':
                col += 1
                worksheet.write(row, col, _('Total CAD'), grand_total_column_style)
            if wizard.currency_id and wizard.currency_id.name == 'USD':
                col += 1
                worksheet.write(row, col, _('Total USD'), grand_total_column_style)
            col += 1
            worksheet.write(row, col, _('Total Company Currency'), grand_total_column_style)
            
            worksheet.col(0).width = 10000
            worksheet.col(1).width = 3500
            worksheet.col(2).width = 3000
            worksheet.col(3).width = 7500
            worksheet.col(4).width = 3000
            worksheet.col(5).width = 6000
            worksheet.col(6).width = 6000
            worksheet.col(7).width = 7500
            worksheet.col(8).width = 5000
            worksheet.col(9).width = 5000
            worksheet.col(10).width = 6500
            worksheet.col(11).width = 5000
            worksheet.col(12).width = 5000
            worksheet.col(13).width = 6500
            worksheet.col(14).width = 5000
            worksheet.col(15).width = 5000
            worksheet.col(16).width = 6500
            worksheet.col(17).width = 5000
            worksheet.col(18).width = 5000
            worksheet.col(19).width = 6500
            worksheet.col(20).width = 5000
            worksheet.col(21).width = 5000
            worksheet.col(22).width = 6500
            worksheet.col(23).width = 5000
            worksheet.col(24).width = 5000
            worksheet.col(25).width = 6500
            row = 1
            
            receivable_account_list = []
            account_objs = self.env['account.account'].search([('account_type', '=', 'asset_receivable')])
            for account_obj in account_objs:
                    receivable_account_list.append(account_obj.id)
            currency_list = []
            if wizard.currency_id:
                currency_list = [wizard.currency_id.id]
            else:
                currencies = self.env['res.currency'].search([('name', 'in', ('CAD', 'USD'))])
                for currency in currencies:
                    currency_list.append(currency.id)
                    
            user_company = self.env.user.company_id
            aml_ids = []
            partners = []
            if receivable_account_list and currency_list: 
                if wizard.partners_ids:
                    query = '''SELECT l.id
                        FROM account_move_line AS l, account_move am
                        WHERE (l.move_id = am.id)
                            AND (am.state = 'posted')
                            AND (l.reconciled = 'f')
                            AND (l.account_id IN %s)
                            AND (l.partner_id IN %s)
                            AND (COALESCE(l.date_maturity, l.date) <= %s)
                            AND (l.currency_id IN %s)
                            AND l.company_id = %s
                        ORDER BY (COALESCE(l.date_maturity, l.date))'''
                    self.env.cr.execute(query, (tuple(receivable_account_list), tuple(wizard.partners_ids.ids), current_date, tuple(currency_list), user_company.id))
                    aml_ids = self.env.cr.fetchall()
                    aml_ids = aml_ids and [x[0] for x in aml_ids] or []
                else:
                    query = '''SELECT l.id
                        FROM account_move_line AS l, account_move am
                        WHERE (l.move_id = am.id)
                            AND (am.state = 'posted')
                            AND (l.reconciled = 'f')
                            AND (l.account_id IN %s)
                            AND (l.partner_id IS NOT NULL)
                            AND (COALESCE(l.date_maturity, l.date) <= %s)
                            AND (l.currency_id IN %s)
                            AND l.company_id = %s
                        ORDER BY (COALESCE(l.date_maturity, l.date))'''
                    self.env.cr.execute(query, (tuple(receivable_account_list), current_date, tuple(currency_list), user_company.id))
                    aml_ids = self.env.cr.fetchall()
                    aml_ids = aml_ids and [x[0] for x in aml_ids] or []
                if aml_ids: 
                    query = '''
                        SELECT DISTINCT l.partner_id, res_partner.name AS name, UPPER(res_partner.name) AS UPNAME
                        FROM account_move_line AS l
                          LEFT JOIN res_partner ON l.partner_id = res_partner.id
                        WHERE (l.id IN %s)
                        ORDER BY UPPER(res_partner.name)'''
                    self.env.cr.execute(query, (tuple(aml_ids),))
                    partners = self.env.cr.fetchall()
                # partners = self.env.cr.dictfetchall()
                
                total_sum_amount_today_CAD = 0
                total_sum_amount_today_USD = 0
                total_sum_amount_today = 0
                total_sum_amount_1_30_CAD = 0
                total_sum_amount_1_30_USD = 0
                total_sum_amount_1_30 = 0
                total_sum_amount_31_60_CAD = 0
                total_sum_amount_31_60_USD = 0
                total_sum_amount_31_60 = 0
                total_sum_amount_61_90_CAD = 0
                total_sum_amount_61_90_USD = 0
                total_sum_amount_61_90 = 0
                total_sum_amount_91_120_CAD = 0
                total_sum_amount_91_120_USD = 0
                total_sum_amount_91_120 = 0
                total_sum_amount_older_CAD = 0
                total_sum_amount_older_USD = 0
                total_sum_amount_older = 0
                grand_total_sum_amount_CAD = 0
                grand_total_sum_amount_USD = 0
                grand_total_sum_amount = 0
                
                # Name                | Start         | Stop
                # --------------------------------------------
                # As of 2019-01-09    | 2019-01-09    |
                # 1 - 30              | 2018-12-10    | 2019-01-08
                # 31 - 60             | 2018-11-10    | 2018-12-09
                # 61 - 90             | 2018-10-11    | 2018-11-09
                # 91 - 120            | 2018-09-11    | 2018-10-10
                # Older               |               | 2018-09-10

                # today = fields.Date.today()
                today = wizard.end_date       ##### Today <- End date
                stop_1_30 = today - timedelta(days=1)
                start_1_30 = today - timedelta(days=30)
                stop_31_60 = today - timedelta(days=31)
                start_31_60 = today - timedelta(days=60)
                stop_61_90 = today - timedelta(days=61)
                start_61_90 = today - timedelta(days=90)
                stop_91_120 = today - timedelta(days=91)
                start_91_120 = today - timedelta(days=120)
                stop_120_older = today - timedelta(days=121)
                
                for partner in partners:
                    sum_amount_today_CAD = 0
                    sum_amount_today_USD = 0
                    sum_amount_today = 0
                    sum_amount_1_30_CAD = 0
                    sum_amount_1_30_USD = 0
                    sum_amount_1_30 = 0
                    sum_amount_31_60_CAD = 0
                    sum_amount_31_60_USD = 0
                    sum_amount_31_60 = 0
                    sum_amount_61_90_CAD = 0
                    sum_amount_61_90_USD = 0
                    sum_amount_61_90 = 0
                    sum_amount_91_120_CAD = 0
                    sum_amount_91_120_USD = 0
                    sum_amount_91_120 = 0
                    sum_amount_older_CAD = 0
                    sum_amount_older_USD = 0
                    sum_amount_older = 0
                    total_sum_amount_CAD = 0
                    total_sum_amount_USD = 0
                    total_sum_amount = 0
                    
                    temp_row = row
                    
                    query = '''SELECT l.id
                        FROM account_move_line AS l
                        WHERE (l.id IN %s)
                            AND (l.partner_id = %s)
                            AND (COALESCE(l.date_maturity, l.date) <= %s)
                            ORDER BY COALESCE(l.date_maturity, l.date), l.id DESC'''
                    self.env.cr.execute(query, (tuple(aml_ids), partner[0], today))
                    move_lines = self.env.cr.fetchall()
                    move_lines = move_lines and [x[0] for x in move_lines] or []
                    for move_line_id in move_lines:
                        move_line = self.env['account.move.line'].browse(move_line_id)
                        inv_name = ' '+ move_line.move_id.name
                        report_date = move_line.date_maturity or move_line.date or ''
                        journal_code = move_line.journal_id and move_line.journal_id.code or ''
                        account_name = move_line.account_id and move_line.account_id.name or ''
                        exp_date = move_line.expected_pay_date and move_line.expected_pay_date.strftime('%m/%d/%Y') or ''
                        amount_today_CAD = ''
                        amount_today_USD = ''
                        amount_today = ''
                        amount_1_30_CAD = ''
                        amount_1_30_USD = ''
                        amount_1_30 = ''
                        amount_31_60_CAD = ''
                        amount_31_60_USD = ''
                        amount_31_60 = ''
                        amount_61_90_CAD = ''
                        amount_61_90_USD = ''
                        amount_61_90 = ''
                        amount_91_120_CAD = ''
                        amount_91_120_USD = ''
                        amount_91_120 = ''
                        amount_older_CAD = ''
                        amount_older_USD = ''
                        amount_older = ''
                        # amount_total_CAD = ''
                        # amount_total_USD = ''
                        # amount_total = ''
                        
                        inv_line_amount = move_line.balance
                        amount_CAD_USD = move_line.amount_currency
                        if move_line.matched_credit_ids:
                            matched_amount_sum = 0
                            matched_credit_sum = 0
                            for matched_credit_id in move_line.matched_credit_ids:
                                matched_amount_sum += matched_credit_id.amount
                                matched_credit_sum += matched_credit_id.credit_amount_currency
                            inv_line_amount = move_line.balance - matched_amount_sum
                            amount_CAD_USD = move_line.amount_currency - matched_credit_sum
                        elif move_line.matched_debit_ids:
                            matched_amount_sum = 0
                            matched_debit_sum = 0
                            for matched_debit_id in move_line.matched_debit_ids:
                                matched_amount_sum += matched_debit_id.amount
                                matched_debit_sum += matched_debit_id.debit_amount_currency
                            inv_line_amount = move_line.balance - (-matched_amount_sum)
                            amount_CAD_USD = move_line.amount_currency - (-matched_debit_sum)
                        
                        if report_date == today:
                            amount_today = inv_line_amount
                            sum_amount_today += amount_today
                            total_sum_amount_today += amount_today
                            if move_line.currency_id.name == 'CAD':
                                amount_today_CAD = amount_CAD_USD
                                sum_amount_today_CAD += amount_today_CAD
                                total_sum_amount_today_CAD += amount_today_CAD
                            else:
                                amount_today_USD = amount_CAD_USD
                                sum_amount_today_USD += amount_today_USD
                                total_sum_amount_today_USD += amount_today_USD
                        if report_date >= start_1_30 and report_date <= stop_1_30:
                            amount_1_30 = inv_line_amount
                            sum_amount_1_30 += amount_1_30
                            total_sum_amount_1_30 += amount_1_30
                            if move_line.currency_id.name == 'CAD':
                                amount_1_30_CAD = amount_CAD_USD
                                sum_amount_1_30_CAD += amount_1_30_CAD
                                total_sum_amount_1_30_CAD += amount_1_30_CAD
                            else:
                                amount_1_30_USD = amount_CAD_USD
                                sum_amount_1_30_USD += amount_1_30_USD
                                total_sum_amount_1_30_USD += amount_1_30_USD
                        if report_date >= start_31_60 and report_date <= stop_31_60:
                            amount_31_60 = inv_line_amount
                            sum_amount_31_60 += amount_31_60
                            total_sum_amount_31_60 += amount_31_60
                            if move_line.currency_id.name == 'CAD':
                                amount_31_60_CAD = amount_CAD_USD
                                sum_amount_31_60_CAD += amount_31_60_CAD
                                total_sum_amount_31_60_CAD += amount_31_60_CAD
                            else:
                                amount_31_60_USD = amount_CAD_USD
                                sum_amount_31_60_USD += amount_31_60_USD
                                total_sum_amount_31_60_USD += amount_31_60_USD
                        if report_date >= start_61_90 and report_date <= stop_61_90:
                            amount_61_90 = inv_line_amount
                            sum_amount_61_90 += amount_61_90
                            total_sum_amount_61_90 += amount_61_90
                            if move_line.currency_id.name == 'CAD':
                                amount_61_90_CAD = amount_CAD_USD
                                sum_amount_61_90_CAD += amount_61_90_CAD
                                total_sum_amount_61_90_CAD += amount_61_90_CAD
                            else:
                                amount_61_90_USD = amount_CAD_USD
                                sum_amount_61_90_USD += amount_61_90_USD
                                total_sum_amount_61_90_USD += amount_61_90_USD
                        if report_date >= start_91_120 and report_date <= stop_91_120:
                            amount_91_120 = inv_line_amount
                            sum_amount_91_120 += amount_91_120
                            total_sum_amount_91_120 += amount_91_120
                            if move_line.currency_id.name == 'CAD':
                                amount_91_120_CAD = amount_CAD_USD
                                sum_amount_91_120_CAD += amount_91_120_CAD
                                total_sum_amount_91_120_CAD += amount_91_120_CAD
                            else:
                                amount_91_120_USD = amount_CAD_USD
                                sum_amount_91_120_USD += amount_91_120_USD
                                total_sum_amount_91_120_USD += amount_91_120_USD
                        if report_date <= stop_120_older:
                            amount_older = inv_line_amount
                            sum_amount_older += amount_older
                            total_sum_amount_older += amount_older
                            if move_line.currency_id.name == 'CAD':
                                amount_older_CAD = amount_CAD_USD
                                sum_amount_older_CAD += amount_older_CAD
                                total_sum_amount_older_CAD += amount_older_CAD
                            else:
                                amount_older_USD = amount_CAD_USD
                                sum_amount_older_USD += amount_older_USD
                                total_sum_amount_older_USD += amount_older_USD
                                
                        ###  Invoices  ###
                        if wizard.unfold:
                            row += 1
                            invoice_date = report_date and report_date.strftime('%m/%d/%Y') or ''
                            worksheet.write(row, 0, inv_name, value_column_style_left)
                            worksheet.write(row, 1, invoice_date, value_column_style_left)
                            worksheet.write(row, 2, journal_code, value_column_style_left)
                            worksheet.write(row, 3, account_name, value_column_style_left)
                            worksheet.write(row, 4, exp_date, value_column_style_left)
                            col = 4
                            if not wizard.currency_id:
                                col += 1
                                worksheet.write(row, col, amount_today_CAD and str(round(amount_today_CAD, 4))+ ' CAD' or '', value_column_style)
                                col += 1
                                worksheet.write(row, col, amount_today_USD and str(round(amount_today_USD, 4))+ ' USD' or '', value_column_style)
                            if wizard.currency_id and wizard.currency_id.name == 'CAD':
                                col += 1
                                worksheet.write(row, col, amount_today_CAD and str(round(amount_today_CAD, 4))+ ' CAD' or '', value_column_style)
                            if wizard.currency_id and wizard.currency_id.name == 'USD':
                                col += 1
                                worksheet.write(row, col, amount_today_USD and str(round(amount_today_USD, 4))+ ' USD' or '', value_column_style)
                            col += 1
                            worksheet.write(row, col, amount_today and str(round(amount_today, 4))+ ' ' +user_company.currency_id.symbol or '', value_column_style)
                            
                            if not wizard.currency_id:
                                col += 1
                                worksheet.write(row, col, amount_1_30_CAD and str(round(amount_1_30_CAD, 4))+ ' CAD' or '', value_column_style)
                                col += 1
                                worksheet.write(row, col, amount_1_30_USD and str(round(amount_1_30_USD, 4))+ ' USD' or '', value_column_style)
                            if wizard.currency_id and wizard.currency_id.name == 'CAD':
                                col += 1
                                worksheet.write(row, col, amount_1_30_CAD and str(round(amount_1_30_CAD, 4))+ ' CAD' or '', value_column_style)
                            if wizard.currency_id and wizard.currency_id.name == 'USD':
                                col += 1
                                worksheet.write(row, col, amount_1_30_USD and str(round(amount_1_30_USD, 4))+ ' USD' or '', value_column_style)
                            col += 1
                            worksheet.write(row, col, amount_1_30 and str(round(amount_1_30, 4))+ ' ' +user_company.currency_id.symbol or '', value_column_style)
                            
                            if not wizard.currency_id:
                                col += 1
                                worksheet.write(row, col, amount_31_60_CAD and str(round(amount_31_60_CAD, 4))+ ' CAD' or '', value_column_style)
                                col += 1
                                worksheet.write(row, col, amount_31_60_USD and str(round(amount_31_60_USD, 4))+ ' USD' or '', value_column_style)
                            if wizard.currency_id and wizard.currency_id.name == 'CAD':
                                col += 1
                                worksheet.write(row, col, amount_31_60_CAD and str(round(amount_31_60_CAD, 4))+ ' CAD' or '', value_column_style)
                            if wizard.currency_id and wizard.currency_id.name == 'USD':
                                col += 1
                                worksheet.write(row, col, amount_31_60_USD and str(round(amount_31_60_USD, 4))+ ' USD' or '', value_column_style)
                            col += 1
                            worksheet.write(row, col, amount_31_60 and str(round(amount_31_60, 4))+ ' ' +user_company.currency_id.symbol or '', value_column_style)
                            
                            if not wizard.currency_id:
                                col += 1
                                worksheet.write(row, col, amount_61_90_CAD and str(round(amount_61_90_CAD, 4))+ ' CAD' or '', value_column_style)
                                col += 1
                                worksheet.write(row, col, amount_61_90_USD and str(round(amount_61_90_USD, 4))+ ' USD' or '', value_column_style)
                            if wizard.currency_id and wizard.currency_id.name == 'CAD':
                                col += 1
                                worksheet.write(row, col, amount_61_90_CAD and str(round(amount_61_90_CAD, 4))+ ' CAD' or '', value_column_style)
                            if wizard.currency_id and wizard.currency_id.name == 'USD':
                                col += 1
                                worksheet.write(row, col, amount_61_90_USD and str(round(amount_61_90_USD, 4))+ ' USD' or '', value_column_style)
                            col += 1
                            worksheet.write(row, col, amount_61_90 and str(round(amount_61_90, 4))+ ' ' +user_company.currency_id.symbol or '', value_column_style)
                            
                            if not wizard.currency_id:
                                col += 1
                                worksheet.write(row, col, amount_91_120_CAD and str(round(amount_91_120_CAD, 4))+ ' CAD' or '', value_column_style)
                                col += 1
                                worksheet.write(row, col, amount_91_120_USD and str(round(amount_91_120_USD, 4))+ ' USD' or '', value_column_style)
                            if wizard.currency_id and wizard.currency_id.name == 'CAD':
                                col += 1
                                worksheet.write(row, col, amount_91_120_CAD and str(round(amount_91_120_CAD, 4))+ ' CAD' or '', value_column_style)
                            if wizard.currency_id and wizard.currency_id.name == 'USD':
                                col += 1
                                worksheet.write(row, col, amount_91_120_USD and str(round(amount_91_120_USD, 4))+ ' USD' or '', value_column_style)
                            col += 1
                            worksheet.write(row, col, amount_91_120 and str(round(amount_91_120, 4))+ ' ' +user_company.currency_id.symbol or '', value_column_style)
                            
                            if not wizard.currency_id:
                                col += 1
                                worksheet.write(row, col, amount_older_CAD and str(round(amount_older_CAD, 4))+ ' CAD' or '', value_column_style)
                                col += 1
                                worksheet.write(row, col, amount_older_USD and str(round(amount_older_USD, 4))+ ' USD' or '', value_column_style)
                            if wizard.currency_id and wizard.currency_id.name == 'CAD':
                                col += 1
                                worksheet.write(row, col, amount_older_CAD and str(round(amount_older_CAD, 4))+ ' CAD' or '', value_column_style)
                            if wizard.currency_id and wizard.currency_id.name == 'USD':
                                col += 1
                                worksheet.write(row, col, amount_older_USD and str(round(amount_older_USD, 4))+ ' USD' or '', value_column_style)
                            col += 1
                            worksheet.write(row, col, amount_older and str(round(amount_older, 4))+ ' ' +user_company.currency_id.symbol or '', value_column_style)
                    
                    total_sum_amount_CAD = sum_amount_today_CAD + sum_amount_1_30_CAD + sum_amount_31_60_CAD + \
                                            sum_amount_61_90_CAD + sum_amount_91_120_CAD + sum_amount_older_CAD
                    grand_total_sum_amount_CAD += total_sum_amount_CAD
                    total_sum_amount_USD = sum_amount_today_USD + sum_amount_1_30_USD + sum_amount_31_60_USD + \
                                            sum_amount_61_90_USD + sum_amount_91_120_USD + sum_amount_older_USD
                    grand_total_sum_amount_USD += total_sum_amount_USD
                    total_sum_amount = sum_amount_today + sum_amount_1_30 + sum_amount_31_60 + \
                                            sum_amount_61_90 + sum_amount_91_120 + sum_amount_older
                    grand_total_sum_amount += total_sum_amount
                       
                    worksheet.write(temp_row, 0, partner[1], easyxf('font:height 200; font:bold True;'))
                    col = 4
                    if not wizard.currency_id:
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_today_CAD, 4))+ ' CAD', total_column_style)
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_today_USD, 4))+ ' USD', total_column_style)
                    if wizard.currency_id and wizard.currency_id.name == 'CAD':
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_today_CAD, 4))+ ' CAD', total_column_style)
                    if wizard.currency_id and wizard.currency_id.name == 'USD':
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_today_USD, 4))+ ' USD', total_column_style)
                    col += 1
                    worksheet.write(temp_row, col, str(round(sum_amount_today, 4))+ ' ' +user_company.currency_id.symbol, total_column_style)
                    
                    if not wizard.currency_id:
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_1_30_CAD, 4))+ ' CAD', total_column_style)
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_1_30_USD, 4))+ ' USD', total_column_style)
                    if wizard.currency_id and wizard.currency_id.name == 'CAD':
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_1_30_CAD, 4))+ ' CAD', total_column_style)
                    if wizard.currency_id and wizard.currency_id.name == 'USD':
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_1_30_USD, 4))+ ' USD', total_column_style)
                    col += 1
                    worksheet.write(temp_row, col, str(round(sum_amount_1_30, 4))+ ' ' +user_company.currency_id.symbol, total_column_style)
                    
                    if not wizard.currency_id:
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_31_60_CAD, 4))+ ' CAD', total_column_style)
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_31_60_USD, 4))+ ' USD', total_column_style)
                    if wizard.currency_id and wizard.currency_id.name == 'CAD':
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_31_60_CAD, 4))+ ' CAD', total_column_style)
                    if wizard.currency_id and wizard.currency_id.name == 'USD':
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_31_60_USD, 4))+ ' USD', total_column_style)
                    col += 1
                    worksheet.write(temp_row, col, str(round(sum_amount_31_60, 4))+ ' ' +user_company.currency_id.symbol, total_column_style)
                    
                    if not wizard.currency_id:
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_61_90_CAD, 4))+ ' CAD', total_column_style)
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_61_90_USD, 4))+ ' USD', total_column_style)
                    if wizard.currency_id and wizard.currency_id.name == 'CAD':
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_61_90_CAD, 4))+ ' CAD', total_column_style)
                    if wizard.currency_id and wizard.currency_id.name == 'USD':
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_61_90_USD, 4))+ ' USD', total_column_style)
                    col += 1
                    worksheet.write(temp_row, col, str(round(sum_amount_61_90, 4))+ ' ' +user_company.currency_id.symbol, total_column_style)
                    
                    if not wizard.currency_id:
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_91_120_CAD, 4))+ ' CAD', total_column_style)
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_91_120_USD, 4))+ ' USD', total_column_style)
                    if wizard.currency_id and wizard.currency_id.name == 'CAD':
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_91_120_CAD, 4))+ ' CAD', total_column_style)
                    if wizard.currency_id and wizard.currency_id.name == 'USD':
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_91_120_USD, 4))+ ' USD', total_column_style)
                    col += 1
                    worksheet.write(temp_row, col, str(round(sum_amount_91_120, 4))+ ' ' +user_company.currency_id.symbol, total_column_style)
                    
                    if not wizard.currency_id:
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_older_CAD, 4))+ ' CAD', total_column_style)
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_older_USD, 4))+ ' USD', total_column_style)
                    if wizard.currency_id and wizard.currency_id.name == 'CAD':
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_older_CAD, 4))+ ' CAD', total_column_style)
                    if wizard.currency_id and wizard.currency_id.name == 'USD':
                        col += 1
                        worksheet.write(temp_row, col, str(round(sum_amount_older_USD, 4))+ ' USD', total_column_style)
                    col += 1
                    worksheet.write(temp_row, col, str(round(sum_amount_older, 4))+ ' ' +user_company.currency_id.symbol, total_column_style)
                    
                    if not wizard.currency_id:
                        col += 1
                        worksheet.write(temp_row, col, str(round(total_sum_amount_CAD, 4))+ ' CAD', total_column_style)
                        col += 1
                        worksheet.write(temp_row, col, str(round(total_sum_amount_USD, 4))+ ' USD', total_column_style)
                    if wizard.currency_id and wizard.currency_id.name == 'CAD':
                        col += 1
                        worksheet.write(temp_row, col, str(round(total_sum_amount_CAD, 4))+ ' CAD', total_column_style)
                    if wizard.currency_id and wizard.currency_id.name == 'USD':
                        col += 1
                        worksheet.write(temp_row, col, str(round(total_sum_amount_USD, 4))+ ' USD', total_column_style)
                    col += 1
                    worksheet.write(temp_row, col, str(round(total_sum_amount, 4))+ ' ' +user_company.currency_id.symbol, total_column_style)
                    row += 1
                    
                row += 1
                worksheet.write(row, 0, _('Total'), column_heading_style) 
                col = 4
                if not wizard.currency_id:
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_today_CAD, 4))+ ' CAD', grand_total_column_style)
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_today_USD, 4))+ ' USD', grand_total_column_style)
                if wizard.currency_id and wizard.currency_id.name == 'CAD':
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_today_CAD, 4))+ ' CAD', grand_total_column_style)
                if wizard.currency_id and wizard.currency_id.name == 'USD':    
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_today_USD, 4))+ ' USD', grand_total_column_style)
                col += 1
                worksheet.write(row, col, str(round(total_sum_amount_today, 4))+ ' ' +user_company.currency_id.symbol, grand_total_column_style)
                
                if not wizard.currency_id:
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_1_30_CAD, 4))+ ' CAD', grand_total_column_style)
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_1_30_USD, 4))+ ' USD', grand_total_column_style)
                if wizard.currency_id and wizard.currency_id.name == 'CAD':
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_1_30_CAD, 4))+ ' CAD', grand_total_column_style)
                if wizard.currency_id and wizard.currency_id.name == 'USD':    
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_1_30_USD, 4))+ ' USD', grand_total_column_style)
                col += 1
                worksheet.write(row, col, str(round(total_sum_amount_1_30, 4))+ ' ' +user_company.currency_id.symbol, grand_total_column_style)
                
                if not wizard.currency_id:
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_31_60_CAD, 4))+ ' CAD', grand_total_column_style)
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_31_60_USD, 4))+ ' USD', grand_total_column_style)
                if wizard.currency_id and wizard.currency_id.name == 'CAD':
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_31_60_CAD, 4))+ ' CAD', grand_total_column_style)
                if wizard.currency_id and wizard.currency_id.name == 'USD':    
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_31_60_USD, 4))+ ' USD', grand_total_column_style)
                col += 1
                worksheet.write(row, col, str(round(total_sum_amount_31_60, 4))+ ' ' +user_company.currency_id.symbol, grand_total_column_style)
                
                if not wizard.currency_id:
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_61_90_CAD, 4))+ ' CAD', grand_total_column_style)
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_61_90_USD, 4))+ ' USD', grand_total_column_style)
                if wizard.currency_id and wizard.currency_id.name == 'CAD':
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_61_90_CAD, 4))+ ' CAD', grand_total_column_style)
                if wizard.currency_id and wizard.currency_id.name == 'USD':
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_61_90_USD, 4))+ ' USD', grand_total_column_style)
                col += 1
                worksheet.write(row, col, str(round(total_sum_amount_61_90, 4))+ ' ' +user_company.currency_id.symbol, grand_total_column_style)
                
                if not wizard.currency_id:
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_91_120_CAD, 4))+ ' CAD', grand_total_column_style)
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_91_120_USD, 4))+ ' USD', grand_total_column_style)
                if wizard.currency_id and wizard.currency_id.name == 'CAD':
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_91_120_CAD, 4))+ ' CAD', grand_total_column_style)
                if wizard.currency_id and wizard.currency_id.name == 'USD':
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_91_120_USD, 4))+ ' USD', grand_total_column_style)
                col += 1
                worksheet.write(row, col, str(round(total_sum_amount_91_120, 4))+ ' ' +user_company.currency_id.symbol, grand_total_column_style)
                
                if not wizard.currency_id:
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_older_CAD, 4))+ ' CAD', grand_total_column_style)
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_older_USD, 4))+ ' USD', grand_total_column_style)
                if wizard.currency_id and wizard.currency_id.name == 'CAD':
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_older_CAD, 4))+ ' CAD', grand_total_column_style)
                if wizard.currency_id and wizard.currency_id.name == 'USD':
                    col += 1
                    worksheet.write(row, col, str(round(total_sum_amount_older_USD, 4))+ ' USD', grand_total_column_style)
                col += 1
                worksheet.write(row, col, str(round(total_sum_amount_older, 4))+ ' ' +user_company.currency_id.symbol, grand_total_column_style)
                
                if not wizard.currency_id:
                    col += 1
                    worksheet.write(row, col, str(round(grand_total_sum_amount_CAD, 4))+ ' CAD', grand_total_column_style)
                    col += 1
                    worksheet.write(row, col, str(round(grand_total_sum_amount_USD, 4))+ ' USD', grand_total_column_style)
                if wizard.currency_id and wizard.currency_id.name == 'CAD':
                    col += 1
                    worksheet.write(row, col, str(round(grand_total_sum_amount_CAD, 4))+ ' CAD', grand_total_column_style)
                if wizard.currency_id and wizard.currency_id.name == 'USD':
                    col += 1
                    worksheet.write(row, col, str(round(grand_total_sum_amount_USD, 4))+ ' USD', grand_total_column_style)
                col += 1
                worksheet.write(row, col, str(round(grand_total_sum_amount, 4))+ ' ' +user_company.currency_id.symbol, grand_total_column_style)
                
            fp = io.BytesIO()
            workbook.save(fp)
            excel_file = base64.encodebytes(fp.getvalue())
            wizard.file = excel_file
            wizard.file_name = 'Aged Receivable with Transaction Currency.xls'
            wizard.report_printed = True
            fp.close()
            return {
                    'view_mode': 'form',
                    'res_id': wizard.id,
                    'res_model': 'print.aged.receivable',
                    'view_type': 'form',
                    'type': 'ir.actions.act_window',
                    'context': self.env.context,
                    'target': 'new',
                }

    
    
    

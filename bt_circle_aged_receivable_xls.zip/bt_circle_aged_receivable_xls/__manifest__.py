# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name': 'BT Circle Aged Receivale Report',
    'summary': 'BT Circle Aged Receivale Report',
    'description': """
    	BT Circle Aged Receivale Report

	""",
    'version': '16.1.0',
    'depends': ['account'],
    'data' : [
        'security/ir.model.access.csv',
        'wizard/print_aged_receivable_view.xml',
        'wizard/print_aged_payable_view.xml',
     ],
    'test': [
    ],
    'demo': [
    ],
    'installable': True,
    'auto_install': False,
    'application': True,

}

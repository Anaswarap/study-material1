from odoo import models, fields, api, _



class ProductProduct(models.Model):
    _inherit = 'product.product'

    jet_mail_reference = fields.Char(string='Jetmail Reference', copy=False)
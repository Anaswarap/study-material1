{
    'name': 'Jet Mail Integration',
    'version': '15.0',
    'category': 'sale',
    'description': """
         Jet Mail Integration
    """,
    'author': 'BroadTech IT Solutions Pvt Ltd',
    'website': 'http://www.broadtech-innovations.com',
    'depends': ['base','btl_purchase_customization'],
    'data': [
            'views/product_view.xml'
        ],

    'license': 'AGPL-3',
    'installable': True,
    'auto_install': False,
    'web_preload': False,
}
# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError


class BalanceSheetReportXlsx(models.Model):
    _name = "balance.sheet.report.xlsx"
    _description = "BalanceSheetReportXlsx"

    name = fields.Char(string="Main category Name")
    line_ids = fields.One2many(string="Lines", comodel_name='balance.sheet.report.xlsx.line', inverse_name='config_id')
    company_id = fields.Many2one(comodel_name='res.company', string='Company')




class BalanceSheetReportXlsxLine(models.Model):
    _name = "balance.sheet.report.xlsx.line"

    name = fields.Char(string="Sub Name")
    config_id = fields.Many2one(string="Balance Sheet Lines",comodel_name='balance.sheet.report.xlsx')
    account_ids = fields.Many2many('account.account', string='Account')


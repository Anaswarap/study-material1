# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import models, fields, api, _
from odoo.exceptions import UserError
import xlwt
from xlwt import easyxf, Formula
import datetime
import io
import base64
from dateutil.relativedelta import relativedelta


class BalanceSheetReportPrintXlsx(models.TransientModel):
    _name = 'balance.sheet.report.print.xlsx'
    _description = 'Balance Sheet Report Print Xlsx'

    date = fields.Date(string='Date')
    file = fields.Binary('Balance Sheet Xlsx Report')
    file_name = fields.Char('File Name')
    report_printed = fields.Boolean('Report Printed', default=False)
    company_id = fields.Many2one('res.company', string='Company')
    start_month = fields.Date(string='Start Month')
    end_month = fields.Date(string='End Month')



    def net_income_calculate(self):

        start_of_year = self.date.replace(month=1, day=1)
        start_of_last_year = start_of_year - relativedelta(years=1)
        end_of_last_year = self.date - relativedelta(years=1)



        domain_ytd = [
            ('date', '>=', start_of_year),
            ('date', '<=', self.date),
            ('parent_state', '=', 'posted'),
            ('company_id', '=', self.company_id.id)
        ]

        domain_prior_ytd = [
            ('date', '>=', start_of_last_year),
            ('date', '<=', end_of_last_year),
            ('parent_state', '=', 'posted'),
            ('company_id', '=', self.company_id.id)
        ]


        # Fetch balances for current YTD
        # Operating Income
        opincome_ytd = -sum(self.env['account.move.line'].search(
            domain_ytd + [('account_id.account_type', '=', 'income'), ('account_id.code', '!=', '999999')]
        ).mapped('balance')) or 0.0


        # Other Income
        other_income_ytd = -sum(self.env['account.move.line'].search(
            domain_ytd + [('account_id.account_type', '=', 'income_other')]
        ).mapped('balance')) or 0.0


        # Cost of Sales
        cos_ytd = sum(self.env['account.move.line'].search(
            domain_ytd + [('account_id.account_type', '=', 'expense_direct_cost')]
        ).mapped('balance')) or 0.0


        # Operating Expenses
        exp_ytd = sum(self.env['account.move.line'].search(
            domain_ytd + [('account_id.account_type', '=', 'expense')]
        ).mapped('balance')) or 0.0




        # Depreciation Expense
        dep_ytd = sum(self.env['account.move.line'].search(
            domain_ytd + [('account_id.account_type', '=', 'expense_depreciation')]
        ).mapped('balance')) or 0.0


        #prior year
        # Operating Income (Last Year)
        opincome_prior_ytd = -sum(self.env['account.move.line'].search(
            domain_prior_ytd + [('account_id.account_type', '=', 'income'), ('account_id.code', '!=', '999999')]
        ).mapped('balance')) or 0.0

        # Other Income (Last Year)
        other_income_prior_ytd = -sum(self.env['account.move.line'].search(
            domain_prior_ytd + [('account_id.account_type', '=', 'income_other')]
        ).mapped('balance')) or 0.0


        # Cost of Sales (Last Year)
        cos_prior_ytd = sum(self.env['account.move.line'].search(
            domain_prior_ytd + [('account_id.account_type', '=', 'expense_direct_cost')]
        ).mapped('balance')) or 0.0


        # Operating Expenses (Last Year)
        exp_prior_ytd = sum(self.env['account.move.line'].search(
            domain_prior_ytd + [('account_id.account_type', '=', 'expense')]
        ).mapped('balance')) or 0.0

        # Depreciation Expense (Last Year)
        dep_prior_ytd = sum(self.env['account.move.line'].search(
            domain_prior_ytd + [('account_id.account_type', '=', 'expense_depreciation')]
        ).mapped('balance')) or 0.0


        # **Calculate Net Profit**
        net_profit_ytd = opincome_ytd + other_income_ytd - cos_ytd - exp_ytd - dep_ytd

        net_profit_prior_ytd = opincome_prior_ytd + other_income_prior_ytd - cos_prior_ytd - exp_prior_ytd - dep_prior_ytd

        return {
            'net_profit_ytd': net_profit_ytd,
            'net_profit_prior_ytd': net_profit_prior_ytd
        }




    def action_print(self):
        net_income_data = self.net_income_calculate()
        net_income = net_income_data.get('net_profit_ytd', 0.0)
        net_prior = net_income_data.get('net_profit_prior_ytd', 0.0)



        if not self.company_id:
            raise UserError(_("Please select a company before printing the report."))

        workbook = xlwt.Workbook()
        column_heading_style = easyxf('font:height 200;font:bold True;align:horiz left;align:vertical center;')
        report_header_style = easyxf('font:name Arial;font:height 250;font: colour black,bold True;borders: top_color olive_ega, bottom_color olive_ega, right_color olive_ega, left_color olive_ega,\
                                     left dotted, right dotted, top dotted, bottom dotted;align:vertical center;align:horizontal center;pattern: pattern solid, fore_colour white')
        sub_header_style = easyxf('font:name Arial;font:height 200;font: colour black,bold True;borders: top_color olive_ega, bottom_color olive_ega, right_color olive_ega, left_color olive_ega,\
                                     left dotted, right dotted, top dotted, bottom dotted;align:vertical center;align:horiz center;pattern: pattern solid, fore_colour white')
        data_style = easyxf('font:name Arial;font:height 200;align:vertical center;align:horiz left;')
        chart_of_account_style = easyxf(
            'font:height 200;font:bold True;align:horiz left;align:vertical center;pattern: pattern solid, fore_colour gray25;')
        currency_style = xlwt.easyxf('align: horiz right', num_format_str='"$" #,##0.00')
        percentage_style = xlwt.easyxf('align: horiz right', num_format_str='0.00%')
        sheet = workbook.add_sheet('Balance Sheet Report Xlsx', cell_overwrite_ok=True)
        company_name = self.company_id.name.upper()

        sheet.write_merge(2, 2, 0, 9, company_name, report_header_style)
        sheet.write_merge(3, 3, 0, 9, 'Balance Sheet', sub_header_style)
        sheet.write(8, 3, 'Current YTD', column_heading_style)
        sheet.write(8, 4, 'Prior Year YTD', column_heading_style)
        sheet.write(8, 5, '$ Change', column_heading_style)
        sheet.write(8, 6, '% Change', column_heading_style)
        sheet.col(0).width = 4500
        sheet.col(1).width = 4500
        sheet.col(2).width = 4500
        sheet.col(3).width = 4500
        sheet.col(4).width = 4500
        sheet.col(5).width = 4500
        sheet.col(6).width = 4500

        if self.date:
            report_date = self.date.strftime("%B %d, %Y")
            sheet.write_merge(4, 4, 0, 9, f"As Of {report_date}", sub_header_style)

        start_of_year = self.date.replace(month=1, day=1)



        move_lines = self.env['account.move.line'].search([('date', '<=', self.date), ('company_id', '=', self.company_id.id),
             ('parent_state', '=', 'posted')])

        # move_lines = self.env['account.move.line'].search(
        #     [('date', '>=', start_of_year), ('date', '<=', self.date), ('company_id', '=', self.company_id.id),
        #      ('parent_state', '=', 'posted')])

        # opening_balance_current = self.env['account.move.line'].search([
        #     ('date', '<', start_of_year),
        #     ('company_id', '=', self.company_id.id),
        #     ('parent_state', '=', 'posted')
        # ])


        start_of_last_year = start_of_year - relativedelta(years=1)


        end_of_last_year = start_of_last_year.replace(month=12, day=31)


        prior_year_move_lines = self.env['account.move.line'].search(
            [('date', '<=', end_of_last_year),
             ('company_id', '=', self.company_id.id), ('parent_state', '=', 'posted')])

        # prior_year_move_lines = self.env['account.move.line'].search(
        #     [('date', '>=', start_of_last_year), ('date', '<=', end_of_last_year),
        #      ('company_id', '=', self.company_id.id), ('parent_state', '=', 'posted')])
        #
        # opening_balance_prior = self.env['account.move.line'].search([
        #     ('date', '<', start_of_last_year),
        #     ('company_id', '=', self.company_id.id),
        #     ('parent_state', '=', 'posted')
        # ])




        account_balances_current = {}
        account_balances_prior = {}

        # opening_balances_current = {}
        # opening_balances_prior = {}

        # for line in opening_balance_current:
        #     if line.account_id.id not in opening_balances_current:
        #         opening_balances_current[line.account_id.id] = 0
        #     opening_balances_current[line.account_id.id] += line.debit - line.credit


        for line in move_lines:
            if line.account_id.id not in account_balances_current:
                account_balances_current[line.account_id.id] = line.debit - line.credit
            else:
                account_balances_current[line.account_id.id] += line.debit - line.credit

        #
        # for line in opening_balance_prior:
        #     if line.account_id.id not in opening_balances_prior:
        #         opening_balances_prior[line.account_id.id] = 0
        #     opening_balances_prior[line.account_id.id] += line.debit - line.credit



        for line in prior_year_move_lines:
            if line.account_id.id not in account_balances_prior:
                account_balances_prior[line.account_id.id] = line.debit - line.credit
            else:
                account_balances_prior[line.account_id.id] += line.debit - line.credit



        # ending_balances = {
        #     account_id: opening_balances_current.get(account_id, 0) + account_balances_current.get(account_id, 0)
        #     for account_id in account_balances_current.keys()
        # }



        balance_sheet_configs = self.env['balance.sheet.report.xlsx'].search([('company_id', '=', self.company_id.id)])

        row = 6
        flag = 1
        balansheet_len = len(balance_sheet_configs)
        profit_loss_written = False



        for config in balance_sheet_configs:
            sheet.write_merge(row, row, 0, 9, config.name.upper(), sub_header_style)
            row += 1
            row += 2

            current_config_total = 0
            current_config_total_value = 0
            prior_config_total = 0
            prior_config_total_value = 0
            change_config_total = 0
            change_config_total_value = 0
            percent_change_config_total = 0
            percent_change_config_total_value = 0

            for line in config.line_ids:
                current_line_balance = 0
                prior_line_balance = 0
                change_line_balance = 0
                percent_change_line_balance = 0
                sheet.write(row, 0, line.name, data_style)
                row_head = row

                if line.account_ids:

                    for account in line.account_ids:

                        current_balance = account_balances_current.get(account.id, 0)

                        prior_balance = account_balances_prior.get(account.id, 0)


                        if config.name == 'ASSETS':
                            current_balance = current_balance

                            prior_balance = prior_balance
                        elif config.name == 'LIABILITIES & SHAREHOLDER\'S EQUITY':
                            current_balance = -current_balance
                            prior_balance = -prior_balance



                        current_line_balance += current_balance




                        sheet.write(row_head, 3, current_line_balance, currency_style)
                        prior_line_balance += prior_balance
                        sheet.write(row_head, 4, prior_line_balance, currency_style)

                        change = current_balance - prior_balance
                        change_line_balance += change
                        sheet.write(row_head, 5, change_line_balance, currency_style)

                        percent_change_line_balance = (
                                (current_line_balance - prior_line_balance) / current_line_balance
                        ) if current_line_balance != 0 else 0.0



                        sheet.write(row_head, 6, percent_change_line_balance, percentage_style)

                        sheet.write(row + 1, 1, account.code or '', chart_of_account_style)
                        sheet.write(row + 1, 2, account.name or '', chart_of_account_style)
                        sheet.write(row + 1, 3, current_balance, currency_style)
                        sheet.write(row + 1, 4, prior_balance, currency_style)
                        sheet.write(row + 1, 5, change, currency_style)
                        sheet.write(row + 1, 6, percent_change_line_balance, percentage_style)

                        row += 1

                    current_config_total += current_line_balance
                    prior_config_total += prior_line_balance
                    change_config_total += change_line_balance

                row += 1

            if flag == balansheet_len:
                sheet.write_merge(row, row, 0, 2, 'Profit (Loss) for the period', column_heading_style)
                sheet.write(row, 3, net_income, currency_style)
                sheet.write(row, 4, net_prior, currency_style)
                sheet.write(row, 5, net_income - net_prior, currency_style)
                sheet.write(row, 6, ((net_income - net_prior) / net_income)
                if net_income else 0.0, percentage_style)

                row += 1
                profit_loss_written = True
                current_config_total_value = current_config_total + net_income

                prior_config_total_value = prior_config_total + net_prior

                change_config_total_value = change_config_total + (net_income - net_prior)




                if current_config_total_value != 0:
                    percent_change_config_total_value = (current_config_total_value - prior_config_total_value) / current_config_total_value
                else:
                    percent_change_config_total_value = 0
            if not profit_loss_written:

                current_config_total_value = current_config_total
                prior_config_total_value = prior_config_total
                change_config_total_value = change_config_total
                percent_change_config_total_value = (current_config_total - prior_config_total) / current_config_total if current_config_total else 0.0

            sheet.write_merge(row, row, 0, 2, f'TOTAL {config.name.upper()}', column_heading_style)
            sheet.write(row, 3, current_config_total_value, currency_style)
            sheet.write(row, 4, prior_config_total_value, currency_style)
            sheet.write(row, 5, change_config_total_value, currency_style)
            sheet.write(row, 6, percent_change_config_total_value, percentage_style)

            row += 2
            flag += 1





        fp = io.BytesIO()
        workbook.save(fp)
        excel_file = base64.encodebytes(fp.getvalue()).decode('utf-8')
        self.file = excel_file
        self.file_name = 'Balance Sheet Xlsx Report.xls'
        self.report_printed = True
        fp.close()

        return {
            'view_mode': 'form',
            'res_id': self.id,
            'res_model': 'balance.sheet.report.print.xlsx',
            'view_type': 'form',
            'type': 'ir.actions.act_window',
            'context': self.env.context,
            'target': 'new',
        }

# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name': 'BT Balance Sheet Report Xlsx',
    'version': '16.1',
    'summary': """BT Balance Sheet Report Xlsx """,
    'license':'LGPL-3',
    'description': """
    BT Balance Sheet Report Xlsx
""",
    'author' : 'Your odoo partner',
    'website' : 'http://yourodoopartner.com/',
    'depends': ['base','account'],
    'images': [],
    'data': [
        'security/ir.model.access.csv',
        'views/balance_sheet_report_xlsx_view.xml',
        'wizard/balance_sheet_report_xlsx_view.xml'

    ],
    'qweb': [],
    'installable': True,
    'auto_install': False,
    'application': True
}
# -*- coding: utf-8 -*-pack
{
    'name': 'Fedex Shipping Integration',
    'category': 'Website',
    'version': '15.0.1.14',
    'summary': """Fedex Shipping Integration""",
    'description': """
        Fedex Integration helps you to integrate & manage your fedex account in odoo. manage your Delivery/shipping operations directly from odoo.Export Order To Selected Carrier while Validate Delivery Order.Auto Import Tracking Detail to odoo.
        Generate Label in Odoo
""",
    'depends': [
        'stock',
        'delivery',
        'btl_sale_customization',
        'dev_picking_cancel',
        'printnode_base',
        'btl_product_customisation',
        'btl_loan_demo_luminary',
        'btl_suggested_product',
        'btl_ship_non_revenue',
        'btl_3dbinpacking_info',
        # 'checkout',
    ],
    'data': [
        'security/ir.model.access.csv',
        'data/delivery_fedex.xml',
        'data/ir_cron.xml',
        'views/res_company.xml',
        'views/product_view.xml',
        'views/delivery_carrier.xml',
        'views/sale_view.xml',
        'views/stock_picking_vts.xml',
        'views/product_packaging.xml',
        'wizard/select_shipping_address.xml',
        'wizard/combo_shipping_rate.xml',
        'wizard/choose_delivery_package_views.xml',
        'views/ship_non_revenue_view.xml',
        'wizard/revenue_combo_shipping_rate.xml',
        'wizard/revenue_select_shipping_address.xml',
        # 'views/checkout.xml',
        'views/holiday_view.xml',
        'views/fedex_pod_order_transfer_view.xml'

    ],
    'author': 'BroadTech IT Solutions Pvt Ltd',
    'website': 'http://wwww.broadtech-innovations.com',
    'license': 'OPL-1',
    'demo': [],
    'installable': True,
    'application': True,
    'auto_install': False,

}

from odoo import api, models, _
from odoo.exceptions import ValidationError


class SaleCancel(models.TransientModel):
    _inherit = "action.cancel.wizard"

    def action_cancel(self):
        picking_ids = []
        order = False
        ctx = self._context
        if ctx.get('active_model') == 'sale.order' and ctx.get('active_id'):
            order = self.env['sale.order'].search([('id', '=', ctx.get('active_id'))])
            picking_ids = order.picking_ids.filtered(lambda o: o.state=='done')
            
        res = super(SaleCancel, self).action_cancel()
        if order and order.carrier_tracking_ref:
            for picking in picking_ids:
                if picking.carrier_tracking_ref and picking.carrier_id:
                    cancel_tracking = picking.carrier_id.fedex_shipping_provider_cancel_shipment(picking)
                        
        return res

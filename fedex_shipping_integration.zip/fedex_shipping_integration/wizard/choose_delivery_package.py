# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _
from odoo.exceptions import UserError
from odoo.tools.float_utils import float_compare, float_is_zero, float_round


class UpdateDeliveryPackage(models.TransientModel):
    _name = 'update.delivery.package'
    _description = "Update Delivery Package"
    
    
    override_weight = fields.Boolean('Override Weight')
    shipping_weight = fields.Float("Package Weight")
    result_package_id = fields.Many2one('stock.quant.package', 'Package')
    move_line_id = fields.Many2one('stock.move.line', 'Move Line', default=lambda self: self._default_move_line_id())
    
    def _default_move_line_id(self):
        if self.env.context.get('default_move_line_id'):
            return self.env['stock.move.line'].browse(self.env.context['default_move_line_id'])
        
        
    def update_package(self):
        if self.move_line_id:
            self.move_line_id.result_package_id.update({
                'override_weight': self.override_weight,
                'shipping_weight': self.shipping_weight
                })
            
            
            
class ChooseDeliveryPackage(models.TransientModel):
    _inherit = 'choose.delivery.package'

    
    move_line_id = fields.Many2one('stock.move.line', 'Move Line', default=lambda self: self._default_move_line_id())
    move_line_ids = fields.Many2many('stock.move.line', 'package_stock_move_line_rel', 'line_id', 'package_id', 'Move Lines')
    move_lines = fields.Many2many('stock.move.line', 'package_move_line_rel', 'line_id', 'package_id', 'Move Lines')
    override_weight = fields.Boolean('Override Weight')
    
    def _default_move_line_id(self):
        if self.env.context.get('default_move_line_id'):
            return self.env['stock.move.line'].browse(self.env.context['default_move_line_id'])
        
    def put_in_pack(self):
        if self.delivery_packaging_id:
            if self.move_line_id:
                self.put_in_pack_move_line()
            elif self.move_line_ids:
                self.put_in_pack_move_line_ids()
        else:
            return super(ChooseDeliveryPackage, self).put_in_pack()
        
    def put_in_pack_move_line(self):
        move_line = self.move_line_id
        if move_line and move_line.qty_done > 0:
            self.put_packages_lines(move_line)
        else:
            raise UserError(_('You must first set the quantity you will put in the pack.'))
    
    def put_in_pack_move_line_ids(self):
        move_line_ids = self.move_line_ids.filtered(lambda o: o.qty_done > 0  and not o.product_id.own_packing)
        own_packing_move_line_ids = self.move_line_ids.filtered(lambda o: o.qty_done > 0 and not o.result_package_id and o.product_id.own_packing)
        if move_line_ids:
            self.put_packages_lines(move_line_ids)
        elif own_packing_move_line_ids:
            product_names = [line.product_id.name for line in own_packing_move_line_ids]
            raise UserError(_('You must assign own packages for the following products. \n\n%s' % "\n".join(product_names)))
        else:
            raise UserError(_('You must first set the quantity you will put in the pack.'))
        
    
    
    def put_packages_lines(self, move_line_ids, delivery_packaging_id=False):
        move_lines_to_pack = self.env['stock.move.line']
        package = self.env['stock.quant.package'].create({})
        shipping_weight = 0.0
        for ml in move_line_ids:
            
            shipping_weight += ml.picking_id.company_id.weight_convertion(ml.picking_id.carrier_id and ml.picking_id.carrier_id.fedex_weight_uom, ml.product_id.weight * ml.qty_done or 0.0)
            if float_compare(ml.qty_done, ml.product_uom_qty,
                             precision_rounding=ml.product_uom_id.rounding) >= 0:
                move_lines_to_pack |= ml
            else:
                quantity_left_todo = float_round(
                    ml.product_uom_qty - ml.qty_done,
                    precision_rounding=ml.product_uom_id.rounding,
                    rounding_method='UP')
                done_to_keep = ml.qty_done
                new_move_line = ml.copy(
                    default={'product_uom_qty': 0, 'qty_done': ml.qty_done})
                ml.write({'product_uom_qty': quantity_left_todo, 'qty_done': 0.0})
                new_move_line.write({'product_uom_qty': done_to_keep})
                move_lines_to_pack |= new_move_line
            ml.pack_select = False

        package_level = self.env['stock.package_level'].create({
            'package_id': package.id,
            'picking_id': move_line_ids.mapped('picking_id').id,
            'location_id': False,
            'location_dest_id': move_line_ids.mapped('location_dest_id').id,
            'move_line_ids': [(6, 0, move_lines_to_pack.ids)],
            'pack_move_line_ids': [(6, 0, move_lines_to_pack.ids)]
            
        })
        move_lines_to_pack.write({
            'result_package_id': package.id,
        })
        
        if delivery_packaging_id:
            package.packaging_id = delivery_packaging_id
            if shipping_weight:
                package.shipping_weight = shipping_weight
        else:
            package.packaging_id = self.delivery_packaging_id
            if self.override_weight:
                package.shipping_weight = self.shipping_weight
                package.override_weight = True
            else:
                package.shipping_weight = shipping_weight
        
        
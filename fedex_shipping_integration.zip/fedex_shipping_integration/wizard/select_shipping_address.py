from odoo import fields, models, api,_
from odoo.exceptions import RedirectWarning, UserError, ValidationError

class ShippingAddress(models.TransientModel):
    _name = 'btl.select.shipping.address'
    _description = 'Selecting shipping address'

    return_address_ids = fields.Many2many('res.partner', 'res_partner_shipping_rel', 'partner_id', 'shipping_id', string='Shipping Address')
    sale_id = fields.Many2one('sale.order')
    
    
    def select_shipping_address(self):
        
        for shipping_obj in self:
            sale_obj = shipping_obj.sale_id
            return_address_ids = shipping_obj.return_address_ids.filtered(lambda o: o.shipping_select)
            if return_address_ids:
                if len(return_address_ids) > 1:
                    raise UserError(_("Please select one shipping address."))
                
                sale_obj.partner_shipping_id = return_address_ids[0].id
                return_address_ids[0].shipping_select = False
                self._cr.execute("insert into btl_combo_shipping_rate(signature_type, fedex_saturday_service, \
                    signature_type_changed, fedex_saturday_service_changed, sale_id) values('%s', %s, '%s', %s, %s) RETURNING id" % (
                        sale_obj.signature_type or 'DIRECT', sale_obj.fedex_saturday_service, sale_obj.signature_type  or 'DIRECT',\
                        sale_obj.fedex_saturday_service, sale_obj.id))
                shiping_vals_ids = [m['id'] for m in self._cr.dictfetchall()]
                if shiping_vals_ids:
                    shipping_price_obj = self.env['btl.combo.shipping.rate'].browse(shiping_vals_ids[0])
                    res = shipping_price_obj.get_shipping_charge()
                    return res
                
            else:
                raise UserError(_("You must select atleast one shipping address."))
            pass



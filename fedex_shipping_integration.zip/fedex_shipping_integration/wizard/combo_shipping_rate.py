from datetime import datetime
import datetime as dt
from datetime import timedelta

from odoo import fields, models, api,_
from odoo.exceptions import RedirectWarning, UserError, ValidationError

class ComboShippingRate(models.TransientModel):
    _name = 'btl.combo.shipping.rate'
    _description = 'Combo Shipping Rates'

    name = fields.Char(string='Name')
    sale_id = fields.Many2one('sale.order')
    shipping_rate_line_ids = fields.One2many('btl.combo.shipping.rate.line', 'combo_rate_id', string='FedEx Shipping Rate')
    signature_type = fields.Selection([('DIRECT', 'DIRECT'), ('ADULT', 'ADULT')],
                                      string="Signature Type", help="", default="ADULT")
    fedex_saturday_service = fields.Boolean(string='FedEx Saturday Service', copy=False)
    
    signature_type_changed = fields.Selection([('DIRECT', 'DIRECT'), ('ADULT', 'ADULT')],
                                      string="Signature Type", help="", default="DIRECT")
    fedex_saturday_service_changed = fields.Boolean(string='FedEx Saturday Service', copy=False)
    
    
    select_rate = fields.Selection([('list', 'List Rate'), ('account', 'Account Rate')], 'Select Rate', default='list')
    fedex_attribute_changed = fields.Boolean(string='FedEx Attribute', copy=False)
    weight = fields.Float('Total Weight')
    package_count = fields.Integer('Estimated Package Count')
    fedex_package_count = fields.Char('Estimated Package Count')
    
    return_address_ids = fields.One2many('btl.fedex.return.address', 'return_id', string='FedEx Return Address')
    return_carrier_id = fields.Many2one('delivery.carrier', string='Return Carrier')
    source_address_id = fields.Many2one('res.partner', 'Source Location')
    dest_address_id = fields.Many2one('res.partner', 'Destination Location')
    return_signature_type = fields.Selection([('DIRECT', 'DIRECT'), ('ADULT', 'ADULT')],
                                      string="Return Signature Type", help="", default="")
    
    package_3dbin_ids = fields.Many2many('response.bin', 'response_bin_rel', 'shipping_id', 'bin_id', string='FedEx Package info')
    future_day = fields.Datetime('Future Day')
    future_day_changed = fields.Datetime('Future Day')
    disable_future_day = fields.Boolean('Disable Future Day')



    @api.onchange('fedex_saturday_service', 'signature_type', 'future_day')
    def _onchange_fedex_attribute_changed(self):
        for line in self:
            if line.fedex_saturday_service != line.fedex_saturday_service_changed or line.signature_type != line.signature_type_changed \
                or line.future_day != line.future_day_changed:
                line.fedex_attribute_changed = True
                
                future_day = datetime.now() + timedelta(days=10)
                if line.future_day > future_day:
                    line.future_day = False
                    return {"warning": {"title": _("Choose Future Date"), "message": "FedEx allows scheduling shipments up to 10 days from the actual ship date. Please choose a future date within that range."}}
            
                
            else:
                line.fedex_attribute_changed = False

    def get_shipping_charge(self):
        for shipping_obj in self:
            shipping_obj.sale_id.update({
                'signature_type': shipping_obj.signature_type,
                'fedex_saturday_service': shipping_obj.fedex_saturday_service,
                'future_day': shipping_obj.future_day,
            })


            fedex_carriers = shipping_obj.env['delivery.carrier'].search(
                [('delivery_type', '=', 'fedex_shipping_provider')]
            )
            carrier_rate_details = []
            package_count = 0
            jetmail_package_count = 0

            for carrier in fedex_carriers:
                try:

                    rate_data = carrier.fedex_shipping_provider_rate_shipment_3dbin(
                        orders=[shipping_obj.sale_id],
                        selected_rate_type=shipping_obj.select_rate
                    )

                    if rate_data.get('success'):
                        carrier_rate_details.append({
                            'carrier_id': carrier.id,
                            'carrier_rate': rate_data.get('price'),
                            'carrier_account_rate': rate_data.get('account_price'),
                            'error_msg': False,
                            'delivery_date': rate_data.get('delivery_date'),


                            'list_base_charge': rate_data.get('list_base_charge') or 0.0,
                            'list_fuel_charge': rate_data.get('list_fuel_charge') or 0.0,
                            'list_signature_charge': rate_data.get('list_signature_charge') or 0.0,
                            'list_tax': rate_data.get('list_tax') or 0.0,
                            'list_discount': rate_data.get('list_discount') or 0.0,
                            'list_total_shipping_cost': rate_data.get('list_total_shipping_cost') or 0.0,
                            'list_rural': rate_data.get('list_rural') or 0.0,
                            'list_oda': rate_data.get('list_oda') or 0.0,

                            'account_base_charge': rate_data.get('account_base_charge') or 0.0,
                            'account_fuel_charge': rate_data.get('account_fuel_charge') or 0.0,
                            'account_signature_charge': rate_data.get('account_signature_charge') or 0.0,
                            'account_tax': rate_data.get('account_tax') or 0.0,
                            'account_discount': rate_data.get('account_discount') or 0.0,
                            'account_total_shipping_cost': rate_data.get('account_total_shipping_cost') or 0.0,
                            'account_rural': rate_data.get('account_rural') or 0.0,
                            'account_oda': rate_data.get('account_oda') or 0.0,
                        })
                        package_count = rate_data.get('package_count', 0)
                        jetmail_package_count = rate_data.get('jetmail_pack', 0)
                    else:
                        carrier_rate_details.append({
                            'carrier_id': carrier.id,
                            'carrier_rate': 0.0,
                            'carrier_account_rate': 0.0,
                            'error_msg': rate_data.get('error_message', False),
                            'delivery_date': False,
                        })
                except Exception as error:
                    carrier_rate_details.append({
                        'carrier_id': carrier.id,
                        'carrier_rate': 0.0,
                        'carrier_account_rate': 0.0,
                        'error_msg': str(error),
                        'delivery_date': False,
                    })


            if carrier_rate_details:
                if shipping_obj.shipping_rate_line_ids:
                    shipping_obj.shipping_rate_line_ids.unlink()
                for carrier_rate in carrier_rate_details:
                    shipping_obj.shipping_rate_line_ids = [(0, 0, {
                        'carrier_id': carrier_rate.get('carrier_id'),
                        'carrier_rate': carrier_rate.get('carrier_rate'),
                        'carrier_account_rate': carrier_rate.get('carrier_account_rate'),
                        'error_msg': carrier_rate.get('error_msg'),
                        'delivery_date': carrier_rate.get('delivery_date'),


                        'list_base_charge': carrier_rate.get('list_base_charge'),
                        'list_fuel_charge': carrier_rate.get('list_fuel_charge'),
                        'list_signature_charge': carrier_rate.get('list_signature_charge'),
                        'list_tax': carrier_rate.get('list_tax'),
                        'list_discount': carrier_rate.get('list_discount'),
                        'list_total_shipping_cost': carrier_rate.get('list_total_shipping_cost'),
                        'list_rural': carrier_rate.get('list_rural') or 0.0,
                        'list_oda': carrier_rate.get('list_oda') or 0.0,

                        'account_base_charge': carrier_rate.get('account_base_charge'),
                        'account_fuel_charge': carrier_rate.get('account_fuel_charge'),
                        'account_signature_charge': carrier_rate.get('account_signature_charge'),
                        'account_tax': carrier_rate.get('account_tax'),
                        'account_discount': carrier_rate.get('account_discount'),
                        'account_total_shipping_cost': carrier_rate.get('account_total_shipping_cost'),
                        'account_rural': carrier_rate.get('account_rural') or 0.0,
                        'account_oda': carrier_rate.get('account_oda') or 0.0,
                    })]


            total_weight = sum([
                (line.product_id.weight * line.product_uom_qty)
                for line in shipping_obj.sale_id.order_line
                if line.default_shipping_type in ('fedex', 'jetmail', 'fedex_ground') and not line.override_fedex_flow
            ]) or 0.0

            fedex_package_count = package_count - jetmail_package_count

            shipping_obj.update({
                'weight': total_weight,
                'package_count': package_count,
                'fedex_package_count': f"{fedex_package_count} / {jetmail_package_count}",
            })

            shipping_obj._cr.commit()

        return {
            'name': _('Add a shipping method'),
            'type': 'ir.actions.act_window',
            'view_id': self.env.ref(
                'fedex_shipping_integration.fedex_shipping_integration_combo_shipping_rate_view_form'
            ).id,
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'btl.combo.shipping.rate',
            'res_id': shipping_obj.id,
            'target': 'new'
        }





class ComboShippingRateLine(models.TransientModel):
    _name = 'btl.combo.shipping.rate.line'
    _description = 'Combo Shipping Rate Lines'

    carrier_id = fields.Many2one('delivery.carrier', string='Carrier')
    carrier_rate = fields.Float(string='List Rate')

    carrier_account_rate = fields.Float(string='Account Rate')
    error_msg = fields.Text(string='Error Message')
    combo_rate_id = fields.Many2one('btl.combo.shipping.rate', string='Combo Rate')
    delivery_date = fields.Datetime('Delivery Date')


    list_base_charge = fields.Float(string='List Base Charge')
    list_fuel_charge = fields.Float(string='List Fuel Charge')
    list_signature_charge = fields.Float(string='List Signature Charge')
    list_tax = fields.Float(string='List Tax')
    list_discount = fields.Float(string='List Discount')
    list_total_shipping_cost = fields.Float(string='List Total Shipping Cost')
    list_rural = fields.Float(string='List Rural Charge')
    list_oda = fields.Float(string='List ODA Charge')


    account_base_charge = fields.Float(string='Account Base Charge')
    account_fuel_charge = fields.Float(string='Account Fuel Charge')
    account_signature_charge = fields.Float(string='Account Signature Charge')
    account_tax = fields.Float(string='Account Tax')
    account_discount = fields.Float(string='Account Discount')
    account_total_shipping_cost = fields.Float(string='Account Total Shipping Cost')
    account_rural = fields.Float(string='Account Rural Charge')
    account_oda = fields.Float(string='Account ODA Charge')

    def select_delivery_line(self):
        shipping_obj = self
        sale_id = self.combo_rate_id.sale_id
        if self.combo_rate_id.select_rate == 'account':
            delivery_price = shipping_obj.carrier_account_rate
            base_charge = shipping_obj.account_base_charge
            fuel_charge = shipping_obj.account_fuel_charge
            signature_charge = shipping_obj.account_signature_charge
            tax = shipping_obj.account_tax
            discount = shipping_obj.account_discount
            total_shipping_cost = shipping_obj.account_total_shipping_cost
            rural = shipping_obj.account_rural
            oda = shipping_obj.account_oda
        else:
            delivery_price = shipping_obj.carrier_rate
            base_charge = shipping_obj.list_base_charge
            fuel_charge = shipping_obj.list_fuel_charge
            signature_charge = shipping_obj.list_signature_charge
            tax = shipping_obj.list_tax
            discount = shipping_obj.list_discount
            total_shipping_cost = shipping_obj.list_total_shipping_cost
            rural = shipping_obj.list_rural
            oda = shipping_obj.list_oda

        extra_charge = rural if rural else oda


        sale_id._remove_delivery_line()
        sale_id.carrier_id = shipping_obj.carrier_id.id


        sale_id._create_delivery_line(carrier=shipping_obj.carrier_id, price_unit=delivery_price)


        sale_id.write({
            'fedex_base_charge': base_charge,
            'fedex_fuel_charge': fuel_charge,
            'fedex_signature_charge': signature_charge,
            'fedex_tax': tax,
            'fedex_discount': discount,
            'fedex_rural': rural,
            'fedex_oda': oda,
            'fedex_delivery_total_charge': delivery_price,
            'fedex_cost': base_charge + fuel_charge + signature_charge + tax + extra_charge,
        })

        return True

    
#     def generate_address_link(self, return_line, old_return_address_id):
#         address_log = '<div> &nbsp; &nbsp; &bull; Return address changed for product line ' + return_line.sale_line_id.product_id.name + " from " + \
#             ('<a href=# data-oe-model=res.partner data-oe-id=%d>%s</a>')% (old_return_address_id.id, old_return_address_id.name)  + \
#             (' <span aria-label="Changed" class="fa fa-long-arrow-right" role="img" title="Changed"></span><span> <a href=# data-oe-model=res.partner data-oe-id=%d>%s</a>') % (return_line.return_address_id.id, return_line.return_address_id.name)
#         
#         return_line.sale_line_id.order_id.message_post(body=address_log)




class AeturnAddress(models.TransientModel):
    _name = 'btl.fedex.return.address'
    _description = 'Fedex Return Address'
 
    sale_line_id = fields.Many2one('sale.order.line', string='Order Line')
    product_id = fields.Many2one('product.product', string='Product')
    return_id = fields.Many2one('btl.combo.shipping.rate', string='Return')
#     return_address_id = fields.Many2one('res.partner', 'Return Address')
    generate_return_label = fields.Boolean(string='Generate Return Label', copy=False)
    
    
    
from datetime import datetime
import datetime as dt
from datetime import timedelta


from odoo import fields, models, api,_
from odoo.exceptions import RedirectWarning, UserError, ValidationError

class ComboShippingRate(models.TransientModel):
    _name = 'btl.nonrevenue.combo.shipping.rate'
    _description = 'Combo non-revenue combo shipping rate'

    name = fields.Char(string='Name')
    revenue_id = fields.Many2one('ship.nonrevenue')
    shipping_rate_line_ids = fields.One2many('btl.revenue.combo.shipping.rate.line', 'combo_rate_id', string='FedEx Shipping Rate')
    signature_type = fields.Selection([('DIRECT', 'DIRECT'), ('ADULT', 'ADULT')],
                                      string="Signature Type", help="", default="ADULT")
    fedex_saturday_service = fields.Boolean(string='FedEx Saturday Service', copy=False)
    
    signature_type_changed = fields.Selection([('DIRECT', 'DIRECT'), ('ADULT', 'ADULT')],
                                      string="Signature Type", help="", default="DIRECT")
    fedex_saturday_service_changed = fields.Boolean(string='FedEx Saturday Service', copy=False)
    
    
    select_rate = fields.Selection([('list', 'List Rate'), ('account', 'Account Rate')], 'Select Rate', default='list')
    fedex_attribute_changed = fields.Boolean(string='FedEx Attribute', copy=False)
    weight = fields.Float('Total Weight')
    package_count = fields.Integer('Estimated Package Count')
    
    return_address_ids = fields.One2many('btl.nonrevenue.fedex.return.address', 'return_id', string='FedEx Return Address')
    return_carrier_id = fields.Many2one('delivery.carrier', string='Return Carrier')
    source_address_id = fields.Many2one('res.partner', 'Source Location')
    dest_address_id = fields.Many2one('res.partner', 'Destination Location')
    return_signature_type = fields.Selection([('DIRECT', 'DIRECT'), ('ADULT', 'ADULT')],
                                      string="Return Signature Type", help="", default="")
    
    future_day = fields.Datetime('Future Day')
    future_day_changed = fields.Datetime('Future Day')
    disable_future_day = fields.Boolean('Disable Future Day') 
    
    @api.onchange('fedex_saturday_service', 'signature_type', 'future_day')
    def _onchange_fedex_attribute_changed(self):
        for line in self:
            if line.fedex_saturday_service != line.fedex_saturday_service_changed or line.signature_type != line.signature_type_changed\
                or line.future_day != line.future_day_changed:
                
                
                future_day = datetime.now() + timedelta(days=10)
                if line.future_day > future_day:
                    line.future_day = False
                    line.fedex_attribute_changed = True
                    return {"warning": {"title": _("Choose Future Date"), "message": "FedEx allows scheduling shipments up to 10 days from the actual ship date. Please choose a future date within that range."}}
            
                
                line.fedex_attribute_changed = True
            else:
                line.fedex_attribute_changed = False
    
    def get_shipping_charge(self):
        
        for shipping_obj in self:
            shipping_obj.revenue_id.update({
                'signature_type': shipping_obj.signature_type,
                'fedex_saturday_service': shipping_obj.fedex_saturday_service,
                'future_day': shipping_obj.future_day,
                })


            fedex_carriers = shipping_obj.env['delivery.carrier'].search([('delivery_type', '=', 'fedex_shipping_provider')])
            carrier_rate_details = []
            package_count = 0
            for carrier in fedex_carriers:
                try:
                    rate_data = carrier.fedex_shipping_provider_rate_shipment_non_revenue(orders=shipping_obj.revenue_id)
                    if rate_data.get('success'):
                        carrier_rate_details.append({
                            'carrier_rate': rate_data.get('price'),
                            'carrier_account_rate': rate_data.get('account_price'),
                            'carrier_id': carrier.id,
                            'error_msg': False,
                            'delivery_date': rate_data.get('delivery_date'),
                        })
                        package_count = rate_data.get('package_count', 0.0)
                except Exception as error:
                    carrier_rate_details.append({
                        'carrier_rate': 0.0,
                        'carrier_account_rate': 0.0,
                        'carrier_id': carrier.id,
                        'error_msg': error,
                        'delivery_date': False,
                    })
            if carrier_rate_details:
    #             shipping_obj.revenue_id.fedex_set_price_line(carrier_rate_details,self)
                if shipping_obj.shipping_rate_line_ids:
                    shipping_obj.shipping_rate_line_ids.unlink()
                for carrier_rate in carrier_rate_details:
                    shipping_obj.shipping_rate_line_ids = [(0, 0, {
                        'carrier_id': carrier_rate and carrier_rate.get('carrier_id'),
                        'carrier_rate': carrier_rate.get('carrier_rate'),
                        'carrier_account_rate': carrier_rate.get('carrier_account_rate'),
                        'error_msg': carrier_rate.get('error_msg'),
                        'delivery_date': carrier_rate.get('delivery_date'),
                        })]
            return_address_ids = []
            for line in shipping_obj.revenue_id.order_line1:
                if line.default_shipping_type in ('fedex', 'jetmail', 'fedex_ground') and not line.override_fedex_flow:
                    generate_return_label = False
                    if line.generate_return_label:
                        generate_return_label = True
                        
                    return_address_ids.append((0, 0, {
                        'revenue_line_id': line.id,
                        'product_id': line.product_id.id,
                        'generate_return_label': generate_return_label,
#                         'return_address_id': line.return_address_id.id,
                        }))
            shipping_obj.return_address_ids = [(5,)]
            if return_address_ids:
                shipping_obj.return_address_ids = return_address_ids
#             shipping_obj.signature_type_changed = shipping_obj.signature_type
#             shipping_obj.fedex_saturday_service_changed = shipping_obj.fedex_saturday_service
#             shipping_obj.fedex_attribute_changed = False
            total_weight = sum([(line.product_id.weight * line.product_uom_qty) for line in shipping_obj.revenue_id.order_line1 if line.default_shipping_type in ('fedex', 'jetmail', 'fedex_ground') and not line.override_fedex_flow]) or 0.0
#             shipping_obj.weight = total_weight
            shipping_obj.update({
                'signature_type_changed': shipping_obj.signature_type,
                'fedex_saturday_service_changed': shipping_obj.fedex_saturday_service,
                'fedex_attribute_changed': False,
                'weight': total_weight,
                'package_count': package_count,
                'source_address_id': shipping_obj.revenue_id.source_address_id and shipping_obj.revenue_id.source_address_id.id or shipping_obj.revenue_id.partner_shipping_id,
                'dest_address_id': shipping_obj.revenue_id.dest_address_id and shipping_obj.revenue_id.dest_address_id.id or shipping_obj.revenue_id.company_id.partner_id,
                'future_day': shipping_obj.future_day,
                'future_day_changed': shipping_obj.future_day,
                'disable_future_day': shipping_obj.revenue_id.company_id.disable_future_day
                })
            
            if not shipping_obj.revenue_id.return_carrier_id:
                fedex_service_type = self.env['delivery.carrier'].search([('fedex_service_type', '=', 'FEDEX_GROUND')], limit=1)
                if fedex_service_type:
                    shipping_obj.return_carrier_id = fedex_service_type.id
            else:
                shipping_obj.return_carrier_id = shipping_obj.revenue_id.return_carrier_id.id
                    
            shipping_obj._cr.commit()
            
            return {
                'name': _('Add a shipping method'),
                'type': 'ir.actions.act_window',
                'view_id': self.env.ref('fedex_shipping_integration.fedex_shipping_integration_nonrevenue_combo_shipping_rate_view_form').id,
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'btl.nonrevenue.combo.shipping.rate',
                'res_id': shipping_obj.id,
                'target':'new'
            }



class ComboShippingRateLine(models.TransientModel):
    _name = 'btl.revenue.combo.shipping.rate.line'
    _description = 'Revenue combo shipping rate lines'

    carrier_id = fields.Many2one('delivery.carrier', string='Carrier')
    carrier_rate = fields.Float(string='List Rate')
    
    carrier_account_rate = fields.Float(string='Account Rate')
    error_msg = fields.Char(string='Error Message')
    combo_rate_id = fields.Many2one('btl.nonrevenue.combo.shipping.rate', string='Combo Rate')
    delivery_date = fields.Datetime('Delivery Date')
    
    
    
    def select_delivery_line(self):
        revenue_id = self.combo_rate_id and self.combo_rate_id.revenue_id
        
        if self.combo_rate_id.signature_type != self.combo_rate_id.signature_type_changed or  \
            self.combo_rate_id.fedex_saturday_service != self.combo_rate_id.fedex_saturday_service_changed:
            raise UserError(_("You have changed the Signature Type/FedEx Saturday Service value. Please press the 'Get Charges' button before selecting the rates"))
            
        delivery_price = self.carrier_rate
        if self.combo_rate_id.select_rate == 'account':
            delivery_price = self.carrier_account_rate
        
        old_carrier = self.env['ship.revenue.line'].search([('order_id', '=', revenue_id.id), ('is_delivery', '=', True)])
        old_carrier_name = False
        old_carrier_rate = 0.0
        if old_carrier:
            old_carrier_name = old_carrier.product_id.name
            old_carrier_rate = old_carrier.price_unit
        
        
        revenue_id.delivery_price = delivery_price
        revenue_id.carrier_id = self.carrier_id and self.carrier_id.id
        
        revenue_id._remove_delivery_line()
        revenue_id._create_delivery_line(carrier=self.carrier_id, price_unit=delivery_price)
        
        
        for revenue_line in revenue_id.order_line1:
            if revenue_line.fedex_attribute_changed:
                revenue_line.fedex_attribute_changed = False
            if self.carrier_id.default_shipping_type  and revenue_line.default_shipping_type in ('fedex', 'fedex_ground') and not revenue_line.is_delivery:
                revenue_line.default_shipping_type = self.carrier_id.default_shipping_type
        for return_line in self.combo_rate_id.return_address_ids:
            
#                 if return_line.revenue_line_id.return_address_id != return_line.return_address_id and return_line.generate_return_label:
#                     self.generate_address_link(return_line, return_line.revenue_line_id.return_address_id)
            
                return_line.revenue_line_id.update({
#                         'return_address_id' : return_line.return_address_id.id,
                    'generate_return_label': return_line.generate_return_label,
                    })
                
#         if revenue_id.source_address_id.id != self.combo_rate_id.source_address_id.id:
#             address_log = '<div> &nbsp; &nbsp; &bull; Source Location ' + ('<a href=# data-oe-model=res.partner data-oe-id=%d>%s</a>')% (revenue_id.source_address_id.id, revenue_id.source_address_id.name)  + \
#                 (' <span aria-label="Changed" class="fa fa-long-arrow-right" role="img" title="Changed"></span><span> <a href=# data-oe-model=res.partner data-oe-id=%d>%s</a>') % (self.combo_rate_id.source_address_id.id, self.combo_rate_id.source_address_id.name)
#             revenue_id.message_post(body=address_log)
#             revenue_id.source_address_id = self.combo_rate_id.source_address_id.id
#         
#         if revenue_id.company_id.partner_id.id != self.combo_rate_id.dest_address_id.id:
#             address_log = '<div> &nbsp; &nbsp; &bull; Destination Location ' + ('<a href=# data-oe-model=res.partner data-oe-id=%d>%s</a>')% (revenue_id.company_id.partner_id.id, revenue_id.company_id.partner_id.name)  + \
#                 (' <span aria-label="Changed" class="fa fa-long-arrow-right" role="img" title="Changed"></span><span> <a href=# data-oe-model=res.partner data-oe-id=%d>%s</a>') % (self.combo_rate_id.dest_address_id.id, self.combo_rate_id.dest_address_id.name)
#             revenue_id.message_post(body=address_log)
#             revenue_id.source_address_id = self.combo_rate_id.source_address_id.id
            
        shipping_rate_log = ''
#         if self.combo_rate_id.signature_type and revenue_id.signature_type != self.combo_rate_id.signature_type:
#             shipping_rate_log = '<div> &nbsp; &nbsp; &bull; Signature Type: ' + self.combo_rate_id.signature_type + '<div> &nbsp; &nbsp; &bull; Select  Rate: ' + (self.combo_rate_id.select_rate == 'account' and 'Account Rate ' or 'List Rate ')
        
        
        
        
        if old_carrier_name and old_carrier_name != self.carrier_id.name:
            shipping_rate_log += '<div> &nbsp; &nbsp; &bull; Rate: ' + str(old_carrier_rate) + ' <span aria-label="Changed" class="fa fa-long-arrow-right" role="img" title="Changed"></span><span> ' + \
                str(delivery_price) 
        else:
            shipping_rate_log += '<div> &nbsp; &nbsp; &bull; Rate: ' + str(delivery_price)
            
        if self.combo_rate_id.return_carrier_id:
            revenue_id.return_carrier_id = self.combo_rate_id.return_carrier_id
            shipping_rate_log += '<div> &nbsp; &nbsp; &bull; Return Carrier: ' + (self.combo_rate_id.return_carrier_id.name or "")
            
        if self.combo_rate_id.source_address_id:
            revenue_id.source_address_id = self.combo_rate_id.source_address_id
            shipping_rate_log += '<div> &nbsp; &nbsp; &bull; Return Source: ' + (self.combo_rate_id.source_address_id.name or "")
            
        if self.combo_rate_id.dest_address_id:
            revenue_id.dest_address_id = self.combo_rate_id.dest_address_id
            shipping_rate_log += '<div> &nbsp; &nbsp; &bull; Return Destination: ' + (self.combo_rate_id.dest_address_id.name or "")
        
        if self.combo_rate_id.return_signature_type:
            revenue_id.return_signature_type = self.combo_rate_id.return_signature_type
            shipping_rate_log += '<div> &nbsp; &nbsp; &bull; Return Signature Type: ' + (self.combo_rate_id.return_signature_type  or "")
            
        revenue_id.message_post(body=shipping_rate_log)
        
        
        return True
    
#     def generate_address_link(self, return_line, old_return_address_id):
#         address_log = '<div> &nbsp; &nbsp; &bull; Return address changed for product line ' + return_line.revenue_line_id.product_id.name + " from " + \
#             ('<a href=# data-oe-model=res.partner data-oe-id=%d>%s</a>')% (old_return_address_id.id, old_return_address_id.name)  + \
#             (' <span aria-label="Changed" class="fa fa-long-arrow-right" role="img" title="Changed"></span><span> <a href=# data-oe-model=res.partner data-oe-id=%d>%s</a>') % (return_line.return_address_id.id, return_line.return_address_id.name)
#         
#         return_line.revenue_line_id.order_id.message_post(body=address_log)




class AeturnAddress(models.TransientModel):
    _name = 'btl.nonrevenue.fedex.return.address'
    _description = 'Fedex non-revenue return address'
 
    revenue_line_id = fields.Many2one('ship.revenue.line', string='Order Line')
    product_id = fields.Many2one('product.product', string='Product')
    return_id = fields.Many2one('btl.nonrevenue.combo.shipping.rate', string='Return')
#     return_address_id = fields.Many2one('res.partner', 'Return Address')
    generate_return_label = fields.Boolean(string='Generate Return Label', copy=False)
    
    

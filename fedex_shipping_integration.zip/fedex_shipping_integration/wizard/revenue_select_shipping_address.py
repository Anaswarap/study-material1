from odoo import fields, models, api,_
from odoo.exceptions import RedirectWarning, UserError, ValidationError

class ShippingAddress(models.TransientModel):
    _name = 'btl.nonrevenue.select.shipping.address'
    _description = 'Shipping address for non-revenue'

    return_address_ids = fields.Many2many('res.partner', 'btl_nonrevenue_res_partner_shipping_rel', 'partner_id', 'shipping_id', string='Shipping Address')
    revenue_id = fields.Many2one('ship.nonrevenue')
    
    
    def select_shipping_address(self):
        
        for shipping_obj in self:
            revenue_obj = shipping_obj.revenue_id
            return_address_ids = shipping_obj.return_address_ids.filtered(lambda o: o.shipping_select)
            if return_address_ids:
                if len(return_address_ids) > 1:
                    raise UserError(_("Please select one shipping address."))
                
                revenue_obj.partner_shipping_id = return_address_ids[0].id
                return_address_ids[0].shipping_select = False
                self._cr.execute("insert into btl_nonrevenue_combo_shipping_rate(signature_type, fedex_saturday_service, \
                    signature_type_changed, fedex_saturday_service_changed, revenue_id) values('%s', %s, '%s', %s, %s) RETURNING id" % (
                        revenue_obj.signature_type or 'DIRECT', revenue_obj.fedex_saturday_service, revenue_obj.signature_type  or 'DIRECT',\
                        revenue_obj.fedex_saturday_service, revenue_obj.id))
                shiping_vals_ids = [m['id'] for m in self._cr.dictfetchall()]
                if shiping_vals_ids:
                    shipping_price_obj = self.env['btl.nonrevenue.combo.shipping.rate'].browse(shiping_vals_ids[0])
                    res = shipping_price_obj.get_shipping_charge()
                    return res
                
            else:
                raise UserError(_("You must select atleast one shipping address."))
            pass



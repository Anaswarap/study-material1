import requests
import base64
import json
import xml.etree.ElementTree as etree
import logging
import pytz

import http.client
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime
import datetime as dt
from datetime import timedelta


from odoo.exceptions import ValidationError, UserError
from odoo import models, fields, api, _


_logger = logging.getLogger(__name__)


class SaleOrder(models.Model):
    _inherit = "sale.order"

    def _get_disable_fedex(self):
        return self.env.user.company_id.disable_fedex
    
    
    fedex_third_party_account_number_sale_order = fields.Char(copy=False, string='FexEx Third-Party Account Number',
                                                              help="Please Enter the Third Party account number ")
    fedex_bill_by_third_party_sale_order = fields.Boolean(string="FedEx Third Party Payment", copy=False, default=False,
                                                          help="when this fields is true,then we can visible fedex_third party account number")

    fedex_saturday_service = fields.Boolean(string='FedEx Saturday Service', copy=False)
    signature_type = fields.Selection([('DIRECT', 'DIRECT'), ('ADULT', 'ADULT')], string="Signature Type", help="",
                                      default="DIRECT", copy=False, tracking=True)
    fedex_attribute_changed = fields.Boolean(string='FedEx Attribute', copy=False, store=True,
                                             compute='_fedex_attribute_changed',
                                             inverse='_set__fedex_attribute_changed')
    carrier_tracking_ref = fields.Char(string='Tracking Reference', copy=False)
    return_carrier_tracking_ref = fields.Char(string='Return Tracking Reference', copy=False)

    fedex_line = fields.Boolean(string='FedEx Line', copy=False, store=True, compute='_fedex_line',
                                inverse='_set__fedex_line')

    return_carrier_id = fields.Many2one('delivery.carrier', string='Return Carrier', tracking=True)
    source_address_id = fields.Many2one('res.partner', 'Return Source Location', tracking=True)
    dest_address_id = fields.Many2one('res.partner', 'Return Destination Location', tracking=True)
    return_signature_type = fields.Selection([('DIRECT', 'DIRECT'), ('ADULT', 'ADULT')], string="Return Signature Type",
                                             help="", default="", tracking=True)
    carrier_id = fields.Many2one('delivery.carrier', string="Delivery Method", tracking=True,
                                 help="Fill this field if you plan to invoice the shipping based on picking.")

    disable_fedex = fields.Boolean('Disable FedEx', default=_get_disable_fedex, readonly=True, index=True, states={'draft': [('readonly', False)], 'sent': [('readonly', False)]},)
    delivery_price = fields.Float(string='Estimated Delivery Price', readonly=True, copy=False)
    future_day = fields.Datetime('Future Day', copy=False,
                             default=fields.Datetime.now)
    jetmail_signature_required = fields.Boolean(string='Jetmail Signature Required', copy=False, default=False)
    website_order = fields.Boolean("Website Order", copy=False, default=False)
    pod_status = fields.Selection([('not_received', 'Not Received'),('received', 'Received'),],string="POD Status",default='not_received',tracking=True,copy=False)

    fedex_base_charge = fields.Float("Base Rate")
    fedex_fuel_charge = fields.Float("Fuel Surcharge")
    fedex_signature_charge = fields.Float("Signature Required")
    fedex_tax = fields.Float("Tax")
    fedex_delivery_total_charge = fields.Float("Estimated Total Cost")
    fedex_discount = fields.Float("Total Discount")
    fedex_cost = fields.Float("Shipping Costs")
    fedex_rural = fields.Float("Rural Destination")
    fedex_oda = fields.Float("Out of Delivery Area")

    pod_status_display = fields.Html(
        string="POD Status",
        compute="_compute_pod_status_display",
        sanitize=False
    )

    def _compute_pod_status_display(self):
        for order in self:
            if order.pod_status == 'received':
                order.pod_status_display = '<span style="color:green;font-weight:bold;">Received</span>'
            else:
                order.pod_status_display = '<span style="color:red;font-weight:bold;">Not Received</span>'




    @api.onchange('future_day')
    def _onchange_future_day(self):
        for order in self:
            future_day = datetime.now() + timedelta(days=10)
            if order.future_day and order.future_day > future_day:
                order.future_day = False
                return {"warning": {"title": _("Choose Future Date"), "message": "FedEx allows scheduling shipments up to 10 days from the actual ship date. Please choose a future date within that range."}}


    def get_shipping_state_valid(self):

        state_valid = True
        for order in self:
            fedex_excluded_state_ids = order.company_id.fedex_excluded_state_ids.ids

            if fedex_excluded_state_ids and order.partner_shipping_id.state_id and order.partner_shipping_id.state_id.id in fedex_excluded_state_ids:

                state_valid = False
            fedex_supported_country_ids = order.company_id.fedex_country_ids.ids
            if fedex_supported_country_ids and order.partner_shipping_id.country_id and order.partner_shipping_id.country_id.id not in fedex_supported_country_ids:

                state_valid = False
        return state_valid

    def order_disable_fedex(self, vals):
        if 'disable_fedex' in vals:
            if vals['disable_fedex']:
                for line in self.order_line:
                    #                     line.default_shipping_type = ''
                    line.generate_return_label = False
                    line.override_fedex_flow = True
                    # self.carrier_id = False
                    # is_delivery_objs = self.env['sale.order.line'].search([('order_id', '=', self.id), ('is_delivery', '=', True)])
                    # if is_delivery_objs:
                    #     is_delivery_objs.unlink()
                self.fedex_attribute_changed = False
            else:
                if not self.get_shipping_state_valid() and self.company_id.fedex_shipping_warning:
                    raise UserError(self.company_id.fedex_shipping_warning)
                for line in self.order_line:
                    if line.product_id:
                        if line.product_id.fedex_return_label:
                            line.generate_return_label = True
                        if line.product_id.default_shipping_type and not line.default_shipping_type:
                            line.default_shipping_type = line.product_id.default_shipping_type
                        line.override_fedex_flow = False
                if self.fedex_line:
                    self.fedex_attribute_changed = True

    def get_return_carrier(self):
        fedex_ground = self.env['delivery.carrier'].search([('fedex_service_type', '=', 'FEDEX_GROUND')], limit=1)
        if fedex_ground:
            self.return_carrier_id = fedex_ground.id
            self.return_signature_type = ''

    @api.model
    def create(self, vals):
        order = super(SaleOrder, self).create(vals)
        if order.website_order:
            if not order.get_shipping_state_valid():
                order.disable_fedex = True
            else:
                order.disable_fedex = False
            order.get_return_carrier()
        order.order_disable_fedex(vals)
        return order

    def write(self, vals):
        res = super(SaleOrder, self).write(vals)
        for sale in self:
            sale.order_disable_fedex(vals)
            if vals.get('partner_shipping_id', False):
                if not sale.get_shipping_state_valid():
                    sale.disable_fedex = True
                else:
                    sale.disable_fedex = False
                # Remove delivery charges line if shipping address is changes so the new line can add
                sale._remove_delivery_line()
            if vals.get('carrier_id', False):
                if sale.website_order:
                    if sale.carrier_id.default_shipping_type:
                        for line in sale.order_line:
                            if line.product_id.default_shipping_type in ('fedex', 'fedex_ground') and not line.is_delivery:
                                line.default_shipping_type = sale.carrier_id.default_shipping_type
                    sale.get_return_carrier()
        return res

    @api.depends('order_line', 'order_line.fedex_attribute_changed')
    def _fedex_attribute_changed(self):
        for order in self:
            changed = order.mapped('order_line').filtered(
                lambda line: line.fedex_attribute_changed == True and line.default_shipping_type in (
                'fedex', 'jetmail', 'fedex_ground'))
            fedex_line = order.mapped('order_line').filtered(
                lambda line: line.default_shipping_type in ('fedex', 'jetmail', 'fedex_ground'))
            delivery_line = order.mapped('order_line').filtered(lambda line: line.is_delivery == True)
            if changed or (fedex_line and not delivery_line) and not order.disable_fedex:
                order.fedex_attribute_changed = True
            else:
                order.fedex_attribute_changed = False

    def _set__fedex_attribute_changed(self):
        for order in self:
            pass

    @api.depends('order_line', 'order_line.fedex_attribute_changed')
    def _fedex_line(self):
        for order in self:
            fedex_line = order.mapped('order_line').filtered(
                lambda line: line.default_shipping_type in ('fedex', 'jetmail', 'fedex_ground'))
            if fedex_line:
                order.fedex_line = True
            else:
                order.fedex_line = False

    def _set__fedex_line(self):
        for order in self:
            pass
    
    
    @api.onchange('disable_fedex')
    def _onchange_disable_fedex(self):
        for order in self:
            if order.disable_fedex:
                order.future_day = ''
                for line in order.order_line:
                    # line.default_shipping_type = ''
                    line.generate_return_label = False
            else:
                order.future_day = datetime.now().date()
                for line in order.order_line:
                    if line.product_id:
                        if line.product_id.fedex_return_label:
                            line.generate_return_label = True
                        if line.product_id.default_shipping_type and not line.default_shipping_type:
                            line.default_shipping_type = line.product_id.default_shipping_type

    @api.onchange('partner_shipping_id')
    def _onchange_fedex_attribute_changed(self):
        for order in self:
            order.fedex_attribute_changed = True
            order.source_address_id = order.partner_shipping_id
            
            dest_address_id = self.env['res.partner'].search([('name', '=', 'BTL Service')], limit=1)
            if dest_address_id:
                order.dest_address_id = dest_address_id.id
            else:
                order.dest_address_id = order.company_id.partner_id

            fedex_service_type = self.env['delivery.carrier'].search([('fedex_service_type', '=', 'FEDEX_GROUND')], limit=1)
            if fedex_service_type:
                order.return_carrier_id = fedex_service_type.id
            
            if not order.get_shipping_state_valid():
                order.disable_fedex = True
                
    
    def compare_order_confirm_time(self, order_date):
        
        time_float = 0
        if self.carrier_id.default_shipping_type == 'fedex' and self.company_id.fedex_express_specified_time:
            time_float = self.company_id.fedex_express_specified_time
        elif self.carrier_id.default_shipping_type == 'fedex_ground' and self.company_id.fedex_ground_specified_time:
            time_float = self.company_id.fedex_ground_specified_time
        elif not self.carrier_id and self.company_id.fedex_ground_specified_time:
            time_float = self.company_id.fedex_ground_specified_time
        
        time_float = 16
        # Extract hours and minutes from the float time
        hours = int(time_float)
        minutes = int((time_float - hours) * 60)
        
        # Create a time object for the FedEx specified time
        fedex_specified_time = dt.time(hour=hours, minute=minutes)
        
        user_timezone = 'US/Eastern'
        # Define the timezone in US/Eastern
        if self.env.user.tz:
            user_timezone = self.env.user.tz
            
        eastern = pytz.timezone(user_timezone)
        utc = pytz.utc
        
        # Create a datetime object with a dummy date (e.g., today) and the time
        today_date = datetime.now().date()
        local_datetime = datetime.combine(today_date, fedex_specified_time)
        
        # Localize the datetime to Eastern Time
        localized_time = eastern.localize(local_datetime)
        
        # Convert to UTC
        utc_time = localized_time.astimezone(utc)
        
        fedex_specified_time = utc_time.time()
        # order_date = self.date_order
        
        # date_string = "2024-11-26 22:57:09"
        # order_date = datetime.strptime(date_string, "%Y-%m-%d %H:%M:%S")
        
        order_time = order_date.time()
        # Check if today is Friday and the order is processed after the FedEx specified time
        if order_date.weekday() == 4 and order_time > fedex_specified_time:  # 4 represents Friday
            future_day = order_date + timedelta(days=3)  # Assume Monday as next working day
        elif order_time > fedex_specified_time:
            future_day = order_date + timedelta(days=1)
        else:
            future_day = order_date  # Order processed before the specified time, same day
        # Exclude holidays and weekends from the future day
        self.future_day = self.get_next_working_day(future_day)
        return True

    def get_next_working_day(self, date):
        # Define your holiday list or use an external holiday library if available
        holiday_list = [holiday.date.strftime('%Y-%m-%d') for holiday in  self.env['btl.holidays.list'].search([])]
        while date.weekday() >= 5 or date.strftime('%Y-%m-%d') in holiday_list:  # Check if weekend or holiday
            date += timedelta(days=1)  # Move to the next day
        return date


    def action_confirm(self):
        for order in self:
            if order.fedex_attribute_changed and not order.nr_id and not order.website_order:
                raise UserError(_("You have modified the sale order. Please apply new shipping rate before proceeding"))
            
            if order.disable_fedex:
                is_delivery_objs = order.mapped('order_line').filtered(lambda line: line.is_delivery == True)
                if is_delivery_objs:
                    raise UserError(_("Please remove the fedex line because the Disable Fedex feature enabled for the order"))
            
            if not order.disable_fedex:
                fedex_line = order.mapped('order_line').filtered(lambda line: line.default_shipping_type in ('fedex', 'jetmail', 'fedex_ground'))
                is_delivery_objs = order.mapped('order_line').filtered(lambda line: line.is_delivery == True)
                if fedex_line and not is_delivery_objs:
                    raise UserError(_("Please added shipping method before proceeding"))

        res = super(SaleOrder, self).action_confirm()

        for order in self:
            if order.picking_ids and order.carrier_id:
                if order.disable_fedex:
                    for pick in order.picking_ids:
                        pick.carrier_id = False
                else:
                    # two_step_picking = order.picking_ids.filtered(
                    #     lambda o: o.picking_type_id.id == order.company_id.two_step_picking_type_id.id and o.state not in (
                    #     'done', 'cancel'))
                    # if two_step_picking:
                    #     picking = order.picking_ids.filtered(lambda o: o.carrier_id and order.company_id.two_step_picking_type_id.id != o.picking_type_id.id and o.state not in ('done', 'cancel'))
                    #     if picking:
                    #         picking.write({'carrier_id': False})
                    #     two_step_picking.write({'carrier_id': order.carrier_id.id})
                    #     for picking_id in two_step_picking:
                    #         for pack in order.pack_info_ids:
                    #             pack.picking_id = picking_id.id
                    if not order.company_id.disable_future_day:
                        if order.future_day:
                            self.compare_order_confirm_time(order.future_day)
                        else:
                            self.compare_order_confirm_time(order.date_order)
                        
                    for picking in order.picking_ids:
                        if picking.picking_type_id.id != picking.picking_type_id.warehouse_id.out_type_id.id and picking.carrier_id:
                            picking.carrier_id = False
                        elif picking.picking_type_id.id ==  picking.picking_type_id.warehouse_id.out_type_id.id and not picking.carrier_id:
                            picking.carrier_id = order.carrier_id.id
                            
        return res

    def get_delivery_price(self):
        for order in self.filtered(lambda o: o.state in ('draft', 'sent') and len(o.order_line) > 0):
            # We do not want to recompute the shipping price of an already validated/done SO
            # or on an SO that has no lines yet
            order.delivery_rating_success = False
            res = order.carrier_id.rate_shipment(order)
            if res['success']:
                order.delivery_rating_success = True
                order.delivery_price = res['price']
                order.delivery_message = res['warning_message']
            else:

                order.delivery_rating_success = False
                order.delivery_price = 0.0
                order.delivery_message = res['error_message']

    #     def get_delivery_price(self):
    #         return self.get_shipping_charge()

    def get_shipping_charge(self):
        shipping_price_obj = self.env['btl.combo.shipping.rate']
        for sale_obj in self:
            #             if sale_obj.partner_invoice_id.id != sale_obj.partner_shipping_id.id:
            #                 action = self.env.ref('fedex_shipping_integration.btl_select_shipping_address_action').read()[0]
            #                 for address in sale_obj.partner_id.child_ids:
            #                     if sale_obj.partner_shipping_id.id == address.id:
            #                         address.shipping_select = True
            #                     else:
            #                         address.shipping_select = False
            #
            #                 child_ids = sale_obj.partner_id.child_ids.ids
            #                 if child_ids:
            #                     child_ids.append(sale_obj.partner_id.id)
            #                     child_ids.append(sale_obj.partner_invoice_id.id)
            #                     child_ids = list(set(child_ids))
            #                 action['context'] = {
            #                     'default_return_address_ids': [(6, 0, child_ids)],
            #                     'default_sale_id': sale_obj.id,
            #                     }
            #                 return action
            #             else:
            if sale_obj.fedex_attribute_changed:
                sale_obj.calculate_package()
                
            
            if not sale_obj.company_id.disable_future_day:
                sale_obj.compare_order_confirm_time(dt.datetime.now())
                # sale_obj.compare_order_confirm_time(sale_obj.date_order)
            
            shiping_vals = {
                # 'signature_type': sale_obj.signature_type or 'DIRECT',
                'signature_type': 'ADULT',
                'fedex_saturday_service': sale_obj.fedex_saturday_service,
                'signature_type_changed': sale_obj.signature_type or 'DIRECT',
                'fedex_saturday_service_changed': sale_obj.fedex_saturday_service,
                'sale_id': sale_obj.id,
                'future_day': sale_obj.future_day,
                'disable_future_day': sale_obj.company_id.disable_future_day
            }

            shipping_price_id = shipping_price_obj.create(shiping_vals)
            res = shipping_price_id.get_shipping_charge()
            return res

    @api.depends('order_line')
    def _compute_bulk_weight(self):
        weight = 0.0
        for line in self.order_line:
            weight += line.product_uom_id._compute_quantity(line.product_uom_qty,
                                                            line.product_id.uom_id) * line.product_id.weight
        self.weight_bulk = weight

    
    
    def set_delivery_line(self, carrier, amount):

        # Remove delivery products from the sales order
        self._remove_delivery_line()

        for order in self:
            order.carrier_id = carrier.id
            # amount = order.delivery_price
            order._create_delivery_line(carrier, amount)
        return True


    def open_website_url_stock_picking(self):
        self.ensure_one()
        for so in self:
            picking_ids = so.picking_ids.filtered(lambda o: o.carrier_tracking_url)
            if picking_ids:
                for picking in picking_ids:
                    if picking.state == 'done':
                        if not picking.carrier_tracking_url or not picking.carrier_id or not picking.delivery_type:
                            raise UserError(
                                _(
                                    "No Shipment Found."))
                        if not picking.carrier_tracking_url:
                            raise UserError(
                                _(
                                    "Your delivery method has no redirect on courier provider's website to track this order."))

                        carrier_trackers = []
                        try:
                            carrier_trackers = json.loads(picking.carrier_tracking_url)
                        except ValueError:
                            carrier_trackers = picking.carrier_tracking_url
                        else:
                            msg = "Tracking links for shipment: <br/>"
                            for tracker in carrier_trackers:
                                msg += '<a href=' + tracker[1] + '>' + tracker[0] + '</a><br/>'
                            self.message_post(body=msg)
                            return self.env.ref('delivery.act_delivery_trackers_url').read()[0]

                        client_action = {
                            'type': 'ir.actions.act_url',
                            'name': "Shipment Tracking Page",
                            'target': 'new',
                            'url': picking.carrier_tracking_url,
                        }
                        return client_action
            else:
                raise UserError(
                    _(
                        "No Shipment Found."))

    
    
    def calculate_package(self):
        for order in self:
            if order.pack_info_ids:
                order.pack_info_ids.unlink()
            order.calculate_3db_package(['fedex', 'fedex_ground'])
            jetmail_line = order.mapped('order_line').filtered(lambda line: line.default_shipping_type in ('jetmail',))
            if jetmail_line:
                order.calculate_3db_package(['jetmail'], True)
    
    
    def calculate_3db_package(self, default_shipping_type, jetmail=False):
        for so in self:
            if not so.is_pack_calc_needed:
                try:
                    bin_config = self.env['pack.config'].search([])[0]
                except IndexError:
                    raise UserError('You need to configure 3DBN API details first.')
                username = bin_config.name
                api_key = bin_config.api_key

                packBin = self.env['stock.package.type'].search([('disable', '!=', True)])
                if not packBin:
                    raise UserError('No Delivery Packages to pack. ')
                
                
                bins = []
                for bin in packBin:
                    bin_param = {"w": bin.width, "h": bin.height, "d": bin.packaging_length, "max_wg": bin.max_wg, "id": str(bin.name), "q": bin.q}
                    bins.append(bin_param)
                items = []
                # Delete previous packages if calculated
                
                for line in so.order_line:
                    if line.product_id.type not in ['service', 'digital'] and  not line.is_delivery and \
                        line.default_shipping_type in default_shipping_type and \
                        not line.override_fedex_flow:
                        if not line.product_id.own_packing:
                            item_vals = {
                                'id': line.prodlot_id and line.prodlot_id.name or line.product_id.name,
                                'q': line.product_uom_qty,
                                'w': line.product_id.width,
                                'h': line.product_id.height,
                                'd': line.product_id.depth,
                                'wg': line.product_id.weight,
                                'vr': 1
                            }
                            items.append(item_vals)
                            
                        elif line.product_id.own_packing:
                            for i in range(int(line.product_uom_qty)):
                                container_id = line.product_id.fedex_package_id.name + '(' + line.product_id.name + ')'
                                vals = {
                                    'd': line.product_id.fedex_package_id.package_type_id and line.product_id.fedex_package_id.package_type_id.packaging_length or 0,
                                    'h': line.product_id.fedex_package_id.package_type_id and line.product_id.fedex_package_id.package_type_id.height or 0,
                                    'container_id': container_id,
                                    'order_id': so.id,
                                    'w': line.product_id.fedex_package_id.package_type_id and line.product_id.fedex_package_id.package_type_id.width or 0,
                                    'weight': line.product_id.weight,
                                    'item_data':line.prodlot_id and line.prodlot_id.name or line.product_id.name,
                                    'jetmail': jetmail,
                                }
                                packBin_id = self.env['response.bin'].create(vals)
                        
                        
                        if so.website_order:
                            
                            for suggest in line.product_id.suggested_product_ids:
                                if suggest.default_shipping_type in default_shipping_type:
                                    if not suggest.product_id.own_packing:
                                        item_vals = {
                                            'id': suggest.product_id.name,
                                            'q': suggest.quantity,
                                            'w': suggest.product_id.width,
                                            'h': suggest.product_id.height,
                                            'd': suggest.product_id.depth,
                                            'wg': suggest.product_id.weight,
                                            'vr': 1
                                        }
                                        items.append(item_vals)
                                    elif suggest.product_id.own_packing:
                                        for i in range(int(suggest.quantity)):
                                            container_id = suggest.product_id.fedex_package_id.name + '(' + suggest.product_id.name + ')'
                                            vals = {
                                                'd': suggest.product_id.fedex_package_id.package_type_id and suggest.product_id.fedex_package_id.package_type_id.packaging_length or 0,
                                                'h': suggest.product_id.fedex_package_id.package_type_id and suggest.product_id.fedex_package_id.package_type_id.height or 0,
                                                'container_id': container_id,
                                                'order_id': so.id,
                                                'w': suggest.product_id.fedex_package_id.package_type_id and suggest.product_id.fedex_package_id.package_type_id.width or 0,
                                                'weight': suggest.product_id.weight,
                                                'item_data': suggest.product_id.name,
                                                'jetmail': jetmail,
                                            }
                                            packBin_id = self.env['response.bin'].create(vals)


                conn = http.client.HTTPConnection(host='global-api.3dbinpacking.com', port=80)
                data = {"bins": bins, "items": items, "username": username, "api_key": api_key}
                
                
                if items:
                    params = urllib.parse.urlencode({'query': json.dumps(data)})
                    conn.request("POST", "/packer/packIntoMany", params, {"Content-type": "application/x-www-form-urlencoded", "Accept": "text/plain"})
    
                    content1 = conn.getresponse().read()
                    conn.close()
                    # GET THE PACK BIN IDS
                    content = json.loads(content1.decode('utf-8'))
                    total_packs = len(content['response']['bins_packed'])
                    for i in range(total_packs):
                        bin_data = content['response']['bins_packed'][i]['bin_data']
    
                        prdcts = []
                        for item in content['response']['bins_packed'][i]['items']:
                            prdcts.append(item['id'])
                        vals = {
                            'd': bin_data['d'],
                            'h': bin_data['h'],
                            'container_id': bin_data['id'],
                            'order_id': so.id,
                            'used_space': bin_data['used_space'],
                            'used_weight': bin_data['used_weight'],
                            'w': bin_data['w'],
                            'weight': bin_data['weight'],
                            'item_data': {x: prdcts.count(x) for x in prdcts},
                            'jetmail': jetmail,
                        }
                        packBin_id = self.env['response.bin'].create(vals)
                    # response_file = base64.encodestring(str(content['response']).encode())
                    response_file = base64.b64encode(str(content['response']).encode('utf8'))
                    self.env['packconfig.data.fetch.history'].create({
                        'packConfig_id': bin_config.id,
                        'response_file': response_file,
                        'file_name': datetime.now().strftime('%m-%d-%Y-%H-%M-%S') + '.json',
                        'partner_id': so.partner_id.id,
                        'order_id': so.id
                    })
                    # GET THE NOT PACKED ITEM ID
                    if len(content['response']['not_packed_items']) != 0:
                        msg = content['response']['errors'][0]['message']
                        raise UserError(_(msg))
            return True
    
    
#     def action_cancel(self):
#         for order in self:
#             if order.carrier_tracking_ref:
#                 for picking in order.picking_ids:
#                     if picking.carrier_tracking_ref:
#                         cancel_tracking = self.env['delivery.carrier'].fedex_shipping_provider_cancel_shipment(picking)
#         res = super(SaleOrder, self).action_cancel()
#             
#         return res


    # Fetch FedEx signed pod from tracking API
    def action_fedex_track(self):
        for order in self:
            if order.pod_status == 'received':
                raise UserError(_("POD already received for this order."))


            picking = order.picking_ids.filtered(lambda p: p.state == 'done')[:1]

            if not picking:
                raise UserError("No validated delivery found.")


            tracking_number = str(picking.carrier_tracking_ref or "").strip()



            if not tracking_number:
                raise UserError("Tracking number not found on delivery.")

            company = order.company_id

            api_url = company.fedex_track_api_url

            token = company.fedex_track_access_token


            if not token:
                raise UserError(_("FedEx access token not configured."))





            headers = {
                "Content-Type": "application/json",
                'Authorization': 'Bearer {0}'.format(token)
            }




            post_url = api_url.rstrip("/") + "/track/v1/trackingdocuments"


            payload = {
                "trackDocumentDetail": {
                    "documentType": "SIGNATURE_PROOF_OF_DELIVERY",
                    "documentFormat": "PDF"
                },
                "trackDocumentSpecification": [
                    {
                        "trackingNumberInfo": {

                            "trackingNumber": tracking_number,
                        },

                        "accountNumber": company.fedex_account_number,
                    }
                ]
            }




            try:

                response = requests.post(post_url, headers=headers, json=payload)



                status = response.status_code

                _logger.info("FedEx Response Status: %s", status)
                _logger.info("FedEx Response Body: %s", response.text)

                if status != 200:
                    raise UserError(_("POD is not available"))


                data = response.json()


                documents = data.get("output", {}).get("documents", [])


                if not documents:
                    raise UserError("No document returned by FedEx.")


                pdf_base64 = documents[0]

                file_name = f'FedEx_POD_{tracking_number}.pdf'

                # Get POD Document Template
                document_template = self.env['product.document'].search([
                    ('string_match', '=', 'pod'),
                    ('type', '=', 'sale')
                ], limit=1)

                if not document_template:
                    raise UserError(_("POD Document Template not configured."))

                # Prevent duplicate per picking
                existing = self.env['product.avail.doc'].search([
                    ('picking_id', '=', picking.id),
                    ('doc_temp_id', '=', document_template.id)
                ], limit=1)

                if existing:
                    raise UserError(_("POD document already exists for this delivery."))

                # Create attachment
                attachment = self.env['ir.attachment'].create({
                    'name': file_name,
                    'type': 'binary',
                    'datas': pdf_base64,
                    'res_model': 'product.avail.doc',
                    'mimetype': 'application/pdf',
                })

                # Create product.avail.doc
                avail_doc = self.env['product.avail.doc'].create({
                    'name': file_name,
                    'so_id': order.id,
                    'picking_id': picking.id,
                    'doc_temp_id': document_template.id,
                    'partner_id': order.partner_id.id,
                    'file': pdf_base64,
                    'filename': file_name,
                    'initial_file_name': file_name,
                    'doc_type': 'receive',
                    'date': fields.Date.today(),
                    'attachment_ids': [(4, attachment.id)],
                })

                # Link attachment to document
                attachment.write({
                    'res_model': 'product.avail.doc',
                    'res_id': avail_doc.id
                })

                #Update order
                order.pod_status = 'received'

                # Post message in chatter
                order.message_post(
                    body=f"FedEx Proof of Delivery received for tracking number {tracking_number}.",
                    attachment_ids=[attachment.id],
                )

                picking.message_post(
                    body=f"FedEx Proof of Delivery received for tracking number {tracking_number}.",
                    attachment_ids=[attachment.id],
                )
            except UserError:
                    raise
            except Exception as e:
                    # raise UserError(_("Error fetching FedEx POD: %s") % e)
                    _logger.exception("Unexpected error in FedEx POD fetch")
                    raise UserError(_("POD is not available"))

    def cron_auto_fetch_fedex_pod(self):
        """
        Scheduled job to automatically fetch FedEx POD
        for delivered sale orders.
        """

        start_date = datetime(2026, 3, 1)


        orders = self.sudo().search([
            ('pod_status', '=', 'not_received'),
            ('state', 'in', ['sale', 'done']),
            ('date_order','>=', start_date)
        ])


        for order in orders:
            try:
                picking = order.picking_ids.filtered(lambda p: p.state == 'done')[:1]

                if not picking:
                    continue

                tracking_number = (picking.carrier_tracking_ref or "").strip()

                if not tracking_number:
                    continue

                company = order.company_id
                api_url = company.fedex_track_api_url
                token = company.fedex_track_access_token

                if not api_url or not token:
                    continue

                headers = {
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {token}"
                }

                post_url = api_url.rstrip("/") + "/track/v1/trackingdocuments"

                payload = {
                    "trackDocumentDetail": {
                        "documentType": "SIGNATURE_PROOF_OF_DELIVERY",
                        "documentFormat": "PDF"
                    },
                    "trackDocumentSpecification": [
                        {
                            "trackingNumberInfo": {
                                "trackingNumber": tracking_number,
                            },
                            "accountNumber": company.fedex_account_number,
                        }
                    ]
                }

                response = requests.post(post_url, headers=headers, json=payload)


                if response.status_code != 200:
                    continue

                data = response.json()
                documents = data.get("output", {}).get("documents", [])

                if not documents:
                    continue

                pdf_base64 = documents[0]

                file_name = f'FedEx-POD-{tracking_number}.pdf'


                document_template = self.env['product.document'].sudo().search([
                    ('string_match', '=', 'pod'),
                    ('type', '=', 'sale')
                ], limit=1)

                if not document_template:
                    _logger.warning("No POD document template found.")
                    continue


                existing = self.env['product.avail.doc'].sudo().search([
                    ('so_id', '=', order.id),
                    ('doc_temp_id', '=', document_template.id)
                ], limit=1)

                if existing:
                    _logger.info("POD already exists for SO %s", order.name)
                    continue


                attachment = self.env['ir.attachment'].sudo().create({
                    'name': file_name,
                    'type': 'binary',
                    'datas': pdf_base64,
                    'res_model': 'product.avail.doc',
                    'mimetype': 'application/pdf',
                })


                avail_doc = self.env['product.avail.doc'].sudo().create({
                    'name': file_name,
                    'so_id': order.id,
                    'picking_id': picking.id,
                    'doc_temp_id': document_template.id,
                    'partner_id': order.partner_id.id,
                    'file': pdf_base64,
                    'filename': file_name,
                    'initial_file_name': file_name,
                    'doc_type': 'receive',
                    'date': fields.Date.today(),
                    'attachment_ids': [(4, attachment.id)],
                })


                attachment.sudo().write({
                    'res_model': 'product.avail.doc',
                    'res_id': avail_doc.id
                })


                order.sudo().write({
                    'pod_status': 'received'
                })


                order.message_post(
                    body=f"FedEx POD automatically fetched for tracking number {tracking_number}.",
                    attachment_ids=[attachment.id]
                )

                _logger.info("FedEx POD created for SO %s", order.name)

                picking.message_post(
                    body=f"FedEx Proof of Delivery received for tracking number {tracking_number}.",
                    attachment_ids=[attachment.id],
                )
                _logger.info("FedEx POD created for Transfer %s", picking.name)



            except Exception as e:
                _logger.exception(
                    "Error while processing FedEx POD for SO %s: %s",
                    order.name if order else 'Unknown',
                    str(e)
                )
                continue




class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    fedex_attribute_changed = fields.Boolean(string='FedEx Attribute', copy=False)
    override_fedex_flow = fields.Boolean(string='Manual FedEx', copy=False)
    generate_return_label = fields.Boolean(string='Return Label')
    return_address_id = fields.Many2one('res.partner', 'Return Address')
    default_shipping_type = fields.Selection(selection_add=[
        ('fedex_ground', 'Fedex Ground'),
        ('no_box', 'No Box'),
    ], string="Ship Type")


    @api.model
    def create(self, vals):
        line = super(SaleOrderLine, self).create(vals)
        if line.product_id:
            if not line.order_id.disable_fedex:
                if line.product_id.fedex_return_label:
                    line.generate_return_label = True
                if line.order_id.website_order and line.order_id.carrier_id.default_shipping_type and line.product_id.default_shipping_type in (
                'fedex', 'fedex_ground') and not line.is_delivery:
                    line.default_shipping_type = line.order_id.carrier_id.default_shipping_type
                elif line.product_id.default_shipping_type and not line.default_shipping_type:
                    line.default_shipping_type = line.product_id.default_shipping_type
            else:
                #                 line.default_shipping_type = ''
                line.generate_return_label = False
                line.override_fedex_flow = True
            if line.is_delivery:
                line.sequence = 1000000
        return line

    @api.onchange('product_id', 'product_uom_qty', 'default_shipping_type', 'prodlot_id')
    def _onchange_fedex_attribute_changed(self):
        for line in self:
            if not line.order_id.disable_fedex:

                if line.default_shipping_type in ('fedex', 'jetmail', 'fedex_ground'):
                    line.fedex_attribute_changed = True
                if line.product_id:
                    if line.product_id.fedex_return_label:
                        line.generate_return_label = True
                    else:
                        line.generate_return_label = False
            else:
                #                 line.default_shipping_type = ''
                line.generate_return_label = False
                line.override_fedex_flow = True

    def unlink(self):
        if 'from_cancel' not in self._context:
            for line in self:
                if not line.is_delivery and line.default_shipping_type in ('fedex', 'jetmail', 'fedex_ground'):
                    is_delivery_objs = self.env['sale.order.line'].search(
                        [('order_id', '=', line.order_id.id), ('is_delivery', '=', True)])
                    if is_delivery_objs:
                        fedex_line = line.order_id.mapped('order_line').filtered(
                            lambda sale_line: sale_line.id != line.id and sale_line.default_shipping_type in (
                            'fedex', 'jetmail', 'fedex_ground'))
                        if fedex_line:
                            line.order_id.fedex_attribute_changed = True
                        is_delivery_objs.unlink()
        return super(SaleOrderLine, self).unlink()
    
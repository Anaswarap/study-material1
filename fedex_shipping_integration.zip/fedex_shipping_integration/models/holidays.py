from odoo import models, fields,api

class BtlHolidays(models.Model):
    _name= "btl.holidays.list"
    _description = 'BTL Holidays'
    _order = 'date, id'
    
    name = fields.Char('Name')
    date = fields.Date('Date')
from odoo import fields, models, api


class ProductPackagingClass(models.Model):
    _inherit = 'stock.package.type'

    package_carrier_type = fields.Selection([('fedex_shipping_provider', 'Fedex')])
#     override_weight = fields.Boolean('Override Weight')
    cover_amount_option = fields.Selection([('fixed', 'Fixed Amount'), ('percentage', '% of Product Price')])
    cover_amount = fields.Integer('Cover Amount')
    q = fields.Integer(string='Max Number of containers', default=100, help="Maximum number of containers of given dimensions")
    max_wg = fields.Float(string='Maximum weight of items', help="Maximum weight of items in a container")
    disable = fields.Boolean('Disable', default=False)


class ResponsePackage(models.Model):
    _inherit = 'response.bin'

    jetmail = fields.Boolean('Jetmail', default=False)
    non_revenue_order_id = fields.Many2one('ship.nonrevenue', 'Non-Revenue Order')
    picking_id = fields.Many2one('stock.picking', 'Picking')


class Packaging(models.Model):
    _inherit = 'pack.bin'

    non_revenue_order_id = fields.Many2one('ship.nonrevenue', 'Non-Revenue Order')


class packconfigDataHistory(models.Model):
    _inherit = 'packconfig.data.fetch.history'

    non_revenue_order_id = fields.Many2one('ship.nonrevenue', 'Non-Revenue Order')
import requests
import base64
import json
import logging

import http.client
import urllib.error
import urllib.parse
import urllib.request
import json
import ast
from datetime import datetime


from odoo.exceptions import ValidationError,ValidationError,UserError
from odoo import models, fields, api, _
from odoo.tools.float_utils import float_compare, float_is_zero, float_round
from odoo.addons import decimal_precision as dp


_logger = logging.getLogger(__name__)


class StockPicking(models.Model):
    _inherit = "stock.picking"
    
    
    
    @api.depends('move_lines', 'move_ids_without_package','package_ids', 'weight_bulk', 'shipping_weight')
    def _cal_weight(self):
        for picking in self:
            weight = 0.0
            for move in picking.move_lines:
                if move.state != 'cancel' and move.product_id.weight > 0.00:
                    weight += (move.product_qty * move.product_id.weight)
            picking.weight = weight

    @api.depends('move_line_ids', 'move_line_ids.result_package_id','move_line_ids.result_package_id.shipping_weight','package_ids', 'weight_bulk')
    def _compute_shipping_pack_weight(self):
        for picking in self:
            shipping_weight = picking.weight_bulk
            for pack in picking.package_ids:
                if pack.override_weight:
                    shipping_weight += pack.shipping_weight
                else:
                    weight = 0.0
                    for move_line in picking.move_line_ids:
                        if pack.id == move_line.result_package_id.id:
                            weight += move_line.product_uom_id._compute_quantity(move_line.qty_done, move_line.product_id.uom_id) * move_line.product_id.weight
                    shipping_weight += weight
            picking.shipping_weight = shipping_weight
                    
    
    
    fedex_saturday_service = fields.Boolean(string='FedEx Saturday Service')
    weight = fields.Float(compute='_cal_weight', digits='Stock Weight', store=True)
    shipping_weight = fields.Float("Weight for Shipping", compute='_compute_shipping_pack_weight')
    return_carrier_tracking_ref = fields.Char(string='Return Tracking Reference', copy=False)
    pod_status = fields.Selection(related='sale_id.pod_status',string="POD Status",store=True,readonly=True)

    def create_return_order(self):
        for picking in self:
            with_context = self._context.copy()
            with_context.update({'use_fedex_return': True})
            res = self.carrier_id.with_context(with_context).fedex_shipping_provider_send_shipping(picking)
            picking.write({'carrier_tracking_ref': res[0].get('tracking_number', ''),
                           'carrier_price': res[0].get('exact_price', 0.0)})
            
    def fedex_return_shipping(self):
        for picking in self:
            if picking.non_revenue_id:
                picking.fedex_return_shipping_non_revenue()
            else:
                if picking.sale_id and picking.sale_id.return_carrier_id:
                    res = picking.sale_id.return_carrier_id.fedex_return_shipping(picking)
                else:
                    res = picking.carrier_id.fedex_return_shipping(picking)
                tracking_ref = res[0].get('tracking_number', '')
                picking.update({
                    'return_carrier_tracking_ref': tracking_ref
                    })


                if not tracking_ref:
                    return

                message_domain = [
                    ('model', '=', 'stock.picking'),
                    ('res_id', '=', picking.id),
                    ('message_type', '=', 'notification'),
                    ('attachment_ids', '!=', False),
                    ('body', 'ilike', tracking_ref),
                    ]
                if picking.carrier_id.fedex_shipping_label_file_type == 'ZPLII':
                    message_domain.append(('attachment_ids.mimetype', '!=', 'application/pdf'))
                else:
                    message_domain.append(('attachment_ids.mimetype', '=', 'application/pdf'))

                messages_to_parse = self.env['mail.message'].search(message_domain)



                for message in messages_to_parse:
                    self._create_return_shipping_label(message)
                messages_to_parse.unlink()
                document_ids = picking.document_ids.filtered(lambda l: l.filename and '.ZPLII' in l.filename)
                if document_ids:
                    document_ids.unlink()
                sale_document_ids = picking.sale_id.document_ids.filtered(lambda l: l.filename and '.ZPLII' in l.filename)
                if sale_document_ids:
                    sale_document_ids.unlink()
            
    def calculate_package(self):
        for picking in self:
            if picking.non_revenue_id:
                picking.calculate_package_non_revenue()
            else:
                order = picking.sale_id
                pack_data = ''
                for pack in order.pack_info_ids:
                    if pack.item_data.find('{') == -1:
                        pack_data +=  ' ' + pack.item_data
                    else:
                        pack_data += ' ' + pack.item_data
                calculate_package = False
                if pack_data:
                    for line in picking.move_lines:
                        if line.default_shipping_type in ['fedex', 'fedex_ground', 'jetmail'] and line.move_line_ids:
                            for move_line in line.move_line_ids:
                                if move_line.lot_id:
                                    if move_line.lot_id.name not in pack_data:
                                        calculate_package = True
                                elif line.product_id.name not in pack_data:
                                    calculate_package = True
                else:
                    calculate_package = True

                if calculate_package:
                    if order.pack_info_ids:
                        order.pack_info_ids.unlink()
                        order.calculate_package()
                        if self._context.get('do_validation', False):
                            self._cr.commit()

    def calculate_3db_package(self, default_shipping_type, jetmail=False):
        for picking in self:
            so = picking.sale_id
            if not so.is_pack_calc_needed:
                try:
                    bin_config = self.env['pack.config'].search([])[0]
                except IndexError:
                    raise UserError('You need to configure 3DBN API details first.')
                username = bin_config.name
                api_key = bin_config.api_key

                packBin = self.env['stock.package.type'].search([('disable', '!=', True)])
                if not packBin:
                    raise UserError('No Delivery Packages to pack. ')
                
                
                bins = []
                for bin in packBin:
                    bin_param = {"w": bin.width, "h": bin.height, "d": bin.packaging_length, "max_wg": bin.max_wg, "id": str(bin.name), "q": bin.q}
                    bins.append(bin_param)
                items = []
                # Delete previous packages if calculated
                for line in picking.move_lines:
                    if line.product_id.type not in ['service', 'digital'] and \
                        line.default_shipping_type in default_shipping_type and \
                        not line.override_fedex_flow:

                        if not line.product_id.own_packing:
                            for move_line in line.move_line_ids:
                                product_uom_qty = move_line.qty_done
                                if product_uom_qty == 0 and move_line.product_uom_qty > 0:
                                    product_uom_qty = move_line.product_uom_qty
                                item_vals = {
                                    'id': move_line.lot_id and move_line.lot_id.name or move_line.product_id.name,
                                    'q': product_uom_qty,
                                    'w': line.product_id.width,
                                    'h': line.product_id.height,
                                    'd': line.product_id.depth,
                                    'wg': line.product_id.weight,
                                    'vr': 1
                                }
                                items.append(item_vals)

                        elif line.product_id.own_packing:
                            if line.product_id.fedex_package_id and not line.product_id.fedex_package_id.package_type_id:
                                raise ValidationError(
            'Product is own packing, Please define the Fedex packaging type for product %s' % (line.product_id.name))
                            for move_line in line.move_line_ids:
                                product_uom_qty = move_line.qty_done
                                if product_uom_qty == 0 and move_line.product_uom_qty > 0:
                                    product_uom_qty = move_line.product_uom_qty
                                for i in range(int(product_uom_qty)):
                                    container_id = line.product_id.fedex_package_id.name + '(' + line.product_id.name + ')'
                                    vals = {
                                        'd': line.product_id.fedex_package_id.package_type_id and line.product_id.fedex_package_id.package_type_id.packaging_length or 0,
                                        'h': line.product_id.fedex_package_id.package_type_id and line.product_id.fedex_package_id.package_type_id.height or 0,
                                        'container_id': container_id,
                                        'order_id': so.id,
                                        'w': line.product_id.fedex_package_id.package_type_id and line.product_id.fedex_package_id.package_type_id.width or 0,
                                        'weight': line.product_id.weight,
                                        'item_data':move_line.lot_id and move_line.lot_id.name or line.product_id.name,
                                        'jetmail': jetmail,
                                    }
                                    packBin_id = self.env['response.bin'].create(vals)

                conn = http.client.HTTPConnection(host='global-api.3dbinpacking.com', port=80)
                data = {"bins": bins, "items": items, "username": username, "api_key": api_key}
                params = urllib.parse.urlencode({'query': json.dumps(data)})
                conn.request("POST", "/packer/packIntoMany", params, {"Content-type": "application/x-www-form-urlencoded", "Accept": "text/plain"})

                content1 = conn.getresponse().read()
                conn.close()
                # GET THE PACK BIN IDS
                content = json.loads(content1.decode('utf-8'))
                total_packs = len(content['response']['bins_packed'])
                for i in range(total_packs):
                    bin_data = content['response']['bins_packed'][i]['bin_data']

                    prdcts = []
                    for item in content['response']['bins_packed'][i]['items']:
                        prdcts.append(item['id'])
                    vals = {
                        'd': bin_data['d'],
                        'h': bin_data['h'],
                        'container_id': bin_data['id'],
                        'order_id': so.id,
                        'used_space': bin_data['used_space'],
                        'used_weight': bin_data['used_weight'],
                        'w': bin_data['w'],
                        'weight': bin_data['weight'],
                        'item_data': {x: prdcts.count(x) for x in prdcts},
                        'jetmail': jetmail,
                    }
                    packBin_id = self.env['response.bin'].create(vals)
                # response_file = base64.encodestring(str(content['response']).encode())
                response_file = base64.b64encode(str(content['response']).encode('utf8'))
                self.env['packconfig.data.fetch.history'].create({
                    'packConfig_id': bin_config.id,
                    'response_file': response_file,
                    'file_name': datetime.now().strftime('%m-%d-%Y-%H-%M-%S') + '.json',
                    'partner_id': so.partner_id.id,
                    'order_id': so.id,
                })
                # GET THE NOT PACKED ITEM ID
                if len(content['response']['not_packed_items']) != 0:
                    msg = content['response']['errors'][0]['message']
                    raise UserError(_(msg))
            return True
    
    def button_validate(self):
        self.ensure_one()
        for picking in self:
            if picking.carrier_id:
                picking.with_context(do_validation=True).calculate_package()

                
                # assign_move_line_ids = picking.move_line_ids.filtered(lambda o: not o.result_package_id and o.default_shipping_type in ('fedex', 'fedex_ground'))
                # if assign_move_line_ids:
                #     picking._3dbn_put_in_pack()

                picking.refresh()
                non_fedex_move_ids = picking.move_lines.filtered(lambda o: o.default_shipping_type not in ('fedex', 'fedex_ground'))
                if non_fedex_move_ids:
                    picking.action_assign()
                    non_fedex_move_line_ids = picking.move_line_ids.filtered(lambda o: o.default_shipping_type not in ('fedex', 'fedex_ground'))
                    if non_fedex_move_line_ids:
                        for move_line in non_fedex_move_line_ids:
                            move_line.qty_done = move_line.product_uom_qty

        res = super(StockPicking, self).button_validate()
        return res

    
    def _action_done(self):
        for picking in self:
            move_ids = picking.move_lines.filtered(lambda o: o.reserved_availability == 0 and o.quantity_done == 0)
            if move_ids:
                for move in move_ids:
                    if not move.product_id.bypass_gen_lot_sn:
                        move.quantity_done = move.product_uom_qty
                    # move._quantity_done_set()
            if picking.carrier_id:
                assign_move_line_ids = picking.move_line_ids.filtered(lambda o: o.qty_done > 0 and
                                                                                not o.result_package_id and
                                                                                o.default_shipping_type in ('fedex', 'fedex_ground'))
                if assign_move_line_ids:
                    picking.manage_packages()
                    
        res = super(StockPicking, self)._action_done()
        for picking in self:
            if picking.sale_id:
                template = self.env.ref('fedex_shipping_integration.btl_website_order_do_confirmation_so', False)
                if template and picking.carrier_id and picking.carrier_tracking_ref and picking.sale_id.website_order:
                    template.send_mail(picking.sale_id.id)
                
        return res
    
    def send_to_shipper(self):
        self.ensure_one()

        if self.non_revenue_id:
            self.send_to_shipper_non_revenue()
        else:
            if self.carrier_id:
                self.manage_packages()
            user = self.env.user
            auto_print = user.company_id.auto_send_slp and \
                user.company_id.printnode_enabled and user.printnode_enabled

            if auto_print and user.company_id.print_package_with_label:
                if self.picking_type_id == self.picking_type_id.warehouse_id.out_type_id:
                    move_lines_without_package = self.move_line_ids_without_package.filtered(
                        lambda l: not l.result_package_id)
                    if move_lines_without_package:
                        raise UserError(_('Some products on Delivery Order are not in Package. For '
                                          'printing Package Slips + Shipping Labels, please, put in '
                                          'pack remaining products. If you want to print only Shipping '
                                          'Label, please, deactivate "Print Package just after Shipping'
                                          ' Label" checkbox in PrintNode/Configuration/Settings'))

            if auto_print:
                # Expected UserError if there is no shipping label printer is available.
                user.get_shipping_label_printer()

            res = self.carrier_id.send_shipping(self)[0]
            if self.carrier_id.free_over and self.sale_id and self.sale_id._compute_amount_total_without_delivery() >= self.carrier_id.amount:
                res['exact_price'] = 0.0
            self.carrier_price = res['exact_price']
            if res['tracking_number']:
                self.carrier_tracking_ref = res['tracking_number']
                order_currency = self.sale_id.currency_id or self.company_id.currency_id
                msg = _("Shipment sent to carrier %s for shipping with tracking number %s<br/>Cost: %.2f %s") % (self.carrier_id.name, self.carrier_tracking_ref, self.carrier_price, order_currency.name)
                self.message_post(body=msg)

            tracking_ref = self.carrier_tracking_ref
            if not tracking_ref:
                return

            message_domain = [
                ('model', '=', 'stock.picking'),
                ('res_id', '=', self.id),
                ('message_type', '=', 'notification'),
                ('attachment_ids', '!=', False),
                ('body', 'ilike', tracking_ref),
                ]
            if self.carrier_id.fedex_shipping_label_file_type == 'ZPLII':
                message_domain.append(('attachment_ids.mimetype', '!=', 'application/pdf'))
            else:
                message_domain.append(('attachment_ids.mimetype', '=', 'application/pdf'))

            messages_to_parse = self.env['mail.message'].search(message_domain)
            for message in messages_to_parse:
                self._create_shipping_label(message)
            messages_to_parse.unlink()

            document_ids = self.document_ids.filtered(lambda l: l.filename and '.ZPLII' in l.filename)
            if document_ids:
                document_ids.unlink()
            sale_document_ids = self.sale_id.document_ids.filtered(lambda l: l.filename and '.ZPLII' in l.filename)
            if sale_document_ids:
                sale_document_ids.unlink()

            self.fedex_return_shipping()

            if auto_print and (self.shipping_label_ids or user.company_id.print_sl_from_attachment):
                self.with_context(raise_exception_slp=False).print_last_shipping_label()


    def unreserve_stock_quant(self, product_id, location_id, update_qty, lot_id):
        StockQuant = self.env['stock.quant']
        domain = [
            ('product_id', '=', product_id.id),
            ('location_id', '=', location_id.id),
            ('quantity', '>=', update_qty),
            ]
        if lot_id:
            domain.append(('lot_id', '=', lot_id.id))

        quants = StockQuant.search(domain)
        for quant in quants:
            available_qty = quant.quantity - quant.reserved_quantity
            if available_qty < update_qty:
                quant.reserved_quantity = 0
        return True




    def _3dbn_create_move_lines(self, sale_lines, quantity, pack, pack_data, own_packing=False, lot_search=False):
        for sale_line in sale_lines:
            if own_packing:
                quantity = sale_line.product_uom_qty
            moves = self.env['stock.move'].search([('sale_line_id', '=', sale_line.id), ('picking_id', '=', self.id)])
            for move in moves:
                update_qty = 0.0
                if quantity == move.availability:
                    update_qty = move.availability
                elif quantity < move.availability:
                    update_qty = quantity
                elif quantity > move.availability:
                    update_qty = move.availability
                if move.reserved_availability < move.product_uom_qty:
                    lot_id = False
                    if lot_search:
                        lot_id = lot_search
                    else:
                        lot_id = move.prodlot_id

                    self.unreserve_stock_quant(move.product_id, move.location_id, update_qty, lot_id)

                    quants = self.env['stock.quant']._update_reserved_quantity(move.product_id, move.location_id,
                                                                               update_qty, lot_id=lot_id, strict=True)
                    if quants:
                        move_line_vals =  move._prepare_move_line_vals(quantity=update_qty, reserved_quant=quants[0][0])
                    else:
                        move_line_vals =  move._prepare_move_line_vals(quantity=update_qty)
                    move_line_vals['qty_done'] = update_qty
                    move_line_vals['lot_id'] = lot_id.id
                    move_line = self.env['stock.move.line'].create(move_line_vals)
                    move.write({'move_line_ids': [(4, move_line.id)]})
                    
                    quantity -= update_qty
                    if pack.id not in pack_data:
                        pack_data[pack.id] = [move_line.id]
                    if move_line.id not in pack_data[pack.id]:
                        pack_data[pack.id].append(move_line.id)

    def generate_move_lines(self):
        for pick in self.filtered(lambda p: p.state not in ('done', 'cancel')):
            if pick.non_revenue_id:
                return pick.generate_move_lines_non_revenue()

            else:
                selected_move_lines = []
                pack_info_data = {}
                for pack in pick.sale_id.pack_info_ids:
                    move_lines_to_pack = self.env['stock.move.line']
                    if pack.item_data.find('{') == -1:
                        pack_data = pack.item_data
                        lot_search = self.env['stock.production.lot'].search([('name', '=', pack_data)], limit=1)

                        if lot_search:
                            sale_lines = pick.sale_id.order_line.filtered(lambda x: x.prodlot_id.id == lot_search.id)
                            if not sale_lines:
                                sale_lines = pick.sale_id.order_line.filtered(lambda x: x.product_id.id == lot_search.product_id.id)

                            pick._3dbn_create_move_lines(sale_lines, 0, pack, pack_info_data, True, lot_search)

                    else:
                        pack_data = pack.item_data
                        dict_pack = ast.literal_eval(pack_data)
                        for pack_name in dict_pack:
                            quantity = dict_pack[pack_name]
                            lot_search = self.env['stock.production.lot'].search([('name', '=', pack_name)], limit=1)
                            product_id = self.env['product.product'].search([('name', '=', pack_name)], limit=1)
                            if lot_search:
                                sale_lines = pick.sale_id.order_line.filtered(lambda x: x.prodlot_id.id == lot_search.id)
                                if not sale_lines:
                                    sale_lines = pick.sale_id.order_line.filtered(lambda x: x.product_id.id == lot_search.product_id.id)

                                pick._3dbn_create_move_lines(sale_lines, quantity, pack, pack_info_data, False, lot_search)

                            elif product_id:
                                sale_lines = pick.sale_id.order_line.filtered(lambda x: x.product_id.id == product_id.id)
                                pick._3dbn_create_move_lines(sale_lines, quantity, pack, pack_info_data, False)

                return pack_info_data

    # def dbn_put_in_pack(self):
    #     move_lines = self.env['stock.move.line'].search([('picking_id', '=', self.id), ('product_id.own_packing', '=', False),
    #                                                      ('default_shipping_type', 'in', ('fedex', 'fedex_ground'))])
    #     if move_lines:
    #         self.do_unreserve()
    #         move_lines = self.env['stock.move.line'].search([('picking_id', '=', self.id), ('product_id.own_packing', '=', False),
    #                                                          ('default_shipping_type', 'in', ('fedex', 'fedex_ground'))])
    #         move_lines.unlink()
    #
    #     move_lines = self.env['stock.move.line'].search([
    #         ('picking_id', '=', self.id), ('product_id.bypass_gen_lot_sn', '=', True),
    #         ('product_id.own_packing', '=', True), ('default_shipping_type', 'in', ('fedex', 'fedex_ground'))])
    #     if move_lines:
    #         self.do_unreserve()
    #         move_lines = self.env['stock.move.line'].search([
    #             ('picking_id', '=', self.id), ('product_id.bypass_gen_lot_sn', '=', True),
    #             ('product_id.own_packing', '=', True), ('default_shipping_type', 'in', ('fedex', 'fedex_ground'))])
    #         move_lines.unlink()
    #
    #     pack_info_data = self.generate_move_lines()
    #     # self._3dbn_put_in_package()

    def my_put_in_pack(self):
        if self.non_revenue_id:
                return self.my_put_in_pack_non_revenue()
        else:
            if self.sale_id:
                if not self.sale_id.is_pack_calc_needed:
                    self.calculate_package()

            for pick in self.filtered(lambda p: p.state not in ('done', 'cancel')):
                selected_move_lines = []
                pack_info_data = {}
                for pack in pick.sale_id.pack_info_ids:
                    if pack.item_data.find('{') == -1:
                        pack_data = pack.item_data
                        lot_search = self.env['stock.production.lot'].search([('name', '=', pack_data)], limit=1)
                        if lot_search:
                            sale_lines = pick.sale_id.order_line.filtered(lambda x: x.prodlot_id.id == lot_search.id)
                            if not sale_lines:
                                sale_lines = pick.sale_id.order_line.filtered(lambda x: x.product_id.id == lot_search.product_id.id)
                            ###################Block Start ############
                            for sale_line in sale_lines:
                                moves = self.env['stock.move'].search([('sale_line_id', '=', sale_line.id), ('picking_id', '=', self.id)])
                                for move in moves:
                                    for sml in move.move_line_ids.filtered(lambda x: x.product_id.id == sale_line.product_id.id and
                                                                                     x.lot_id.id == lot_search.id):
                                        selected_move_lines.append(sml.id)
                                    if pack.id not in pack_info_data:
                                        pack_info_data[pack.id] = [sml.id]
                                    if sml.id not in pack_info_data[pack.id]:
                                        pack_info_data[pack.id].append(sml.id)
                            ###################Block END ############
                    else:
                        pack_data = pack.item_data
                        dict_pack = ast.literal_eval(pack_data)
                        for pack_name in dict_pack:
                            lot_search = self.env['stock.production.lot'].search([('name', '=', pack_name)], limit=1)
                            product_id = self.env['product.product'].search([('name', '=', pack_name)], limit=1)
                            if lot_search:
                                sale_lines = pick.sale_id.order_line.filtered(lambda x: x.prodlot_id.id == lot_search.id)
                                if not sale_lines:
                                    sale_lines = pick.sale_id.order_line.filtered(lambda x: x.product_id.id == lot_search.product_id.id)
                                ###################Block Start ############
                                for sale_line in sale_lines:
                                    moves = self.env['stock.move'].search([('sale_line_id', '=', sale_line.id), ('picking_id', '=', self.id)])
                                    for move in moves:
                                        for sml in move.move_line_ids.filtered(lambda x: x.product_id.id == sale_line.product_id.id and
                                                                                         x.lot_id.id == lot_search.id):
                                            selected_move_lines.append(sml.id)
                                        if pack.id not in pack_info_data:
                                            pack_info_data[pack.id] = [sml.id]
                                        if sml.id not in pack_info_data[pack.id]:
                                            pack_info_data[pack.id].append(sml.id)
                                ###################Block END ############
                            elif product_id:
                                sale_lines = pick.sale_id.order_line.filtered(lambda x: x.product_id.id == product_id.id)
                                ###################Block Start ############
                                for sale_line in sale_lines:
                                    moves = self.env['stock.move'].search([('sale_line_id', '=', sale_line.id), ('picking_id', '=', self.id)])
                                    for move in moves:
                                        for sml in move.move_line_ids.filtered(lambda x: x.product_id.id == sale_line.product_id.id):
                                            selected_move_lines.append(sml.id)
                                        if pack.id not in pack_info_data:
                                            pack_info_data[pack.id] = [sml.id]
                                        if sml.id not in pack_info_data[pack.id]:
                                            pack_info_data[pack.id].append(sml.id)
                                ###################Block END ############
            self._3dbn_put_in_package(pack_info_data)

    def _3dbn_put_in_pack(self):
        if self.non_revenue_id:
            return self._3dbn_put_in_pack_non_revenue()
        else:
            if self.sale_id:
                if not self.sale_id.is_pack_calc_needed:
                    self.calculate_package()

            move_lines = self.env['stock.move.line'].search([('picking_id', '=', self.id), ('product_id.own_packing', '=', False),
                                                             ('default_shipping_type', 'in', ('fedex', 'fedex_ground'))])
            if move_lines:
                self.do_unreserve()
                move_lines = self.env['stock.move.line'].search([('picking_id', '=', self.id), ('product_id.own_packing', '=', False),
                                                                 ('default_shipping_type', 'in', ('fedex', 'fedex_ground'))])
                move_lines.unlink()

            move_lines = self.env['stock.move.line'].search([
                ('picking_id', '=', self.id), ('product_id.bypass_gen_lot_sn', '=', True),
                ('product_id.own_packing', '=', True), ('default_shipping_type', 'in', ('fedex', 'fedex_ground'))])
            if move_lines:
                self.do_unreserve()
                move_lines = self.env['stock.move.line'].search([
                    ('picking_id', '=', self.id), ('product_id.bypass_gen_lot_sn', '=', True),
                    ('product_id.own_packing', '=', True), ('default_shipping_type', 'in', ('fedex', 'fedex_ground'))])
                move_lines.unlink()

            pack_info_data = self.generate_move_lines()
            self._3dbn_put_in_package(pack_info_data)

    def _3dbn_put_in_package(self, pack_info_data={}):
        package_ids = self.env['stock.quant.package']
        cover = 0
        for pick in self.filtered(lambda p: p.state not in ('done', 'cancel')):
            move_line_ids = pick.move_line_ids.filtered(lambda o: o.qty_done > 0 and o.result_package_id)
            move_line_ids.write({'result_package_id': False})
            for pack in pick.sale_id.pack_info_ids:
                move_lines_to_pack = self.env['stock.move.line']
                if pack.item_data.find('{') == -1:
                    lot_search = self.env['stock.production.lot'].search([('name', '=', pack.item_data)], limit=1)
                    move_line = self.env['stock.move.line'].search([('lot_id', '=', lot_search.id), ('move_id.picking_id', '=', self.id)])

                    if self.carrier_id.fedex_default_product_packaging_id.cover_amount_option == 'fixed':
                        cover = self.carrier_id.fedex_default_product_packaging_id.cover_amount
                    else:
                        cover_amount = sum([po.qty_done * po.product_id.lst_price for po in move_line])
                        cover = cover_amount

                    package = self.env['stock.quant.package'].create({
                        'height': pack.h,
                        'width': pack.w,
                        'length': pack.d,
                        'weight': pack.weight,
                        'shipping_weight': pack.weight,
                        'cover_amount': cover,
                        # 'packaging_id': self.carrier_id.fedex_default_product_packaging_id.id,
                        'order_id': pick.sale_id.id,
                        'picking_id': pick.id,
                        'override_weight': True
                    })
                    for ml in move_line:
                        # calculating --------->
                        if float_compare(ml.qty_done, ml.product_uom_qty, precision_rounding=ml.product_uom_id.rounding) >= 0:
                            move_lines_to_pack |= ml
                        else:
                            quantity_left_todo = float_round(
                                ml.product_uom_qty - ml.qty_done,
                                precision_rounding=ml.product_uom_id.rounding,
                                rounding_method='UP')
                            done_to_keep = ml.qty_done
                            if done_to_keep > 0:
                                new_move_line = ml.copy(default={'product_uom_qty': 0, 'qty_done': ml.qty_done})
                                vals = {'product_uom_qty': quantity_left_todo, 'qty_done': 0.0}
                                if pick.picking_type_id.code == 'incoming':
                                    if ml.lot_id:
                                        vals['lot_id'] = False
                                    if ml.lot_name:
                                        vals['lot_name'] = False

                                ml.write(vals)
                                new_move_line.write({'product_uom_qty': done_to_keep})
                                move_lines_to_pack |= new_move_line
                            else:
                                move_lines_to_pack |= ml
                else:
                    cover = 0
                    pack_data = pack.item_data
                    # pack_data = pack_data.replace("\'", "\"")
                    # dict_pack = json.loads(pack_data)
                    dict_pack = ast.literal_eval(pack_data)
                    package = self.env['stock.quant.package'].create({
                        'height': pack.h,
                        'width': pack.w,
                        'length': pack.d,
                        'weight': pack.weight,
                        'shipping_weight': pack.weight,
                        # 'packaging_id': self.carrier_id.fedex_default_product_packaging_id.id,
                        'order_id': pick.sale_id.id,
                        'picking_id': pick.id,
                        'override_weight': True
                    })

                    if pack.id in pack_info_data:
                        move_lines_to_pack_lines = self.env['stock.move.line'].browse(pack_info_data[pack.id])
                        cover_amount = sum([po.qty_done * po.product_id.lst_price for po in move_lines_to_pack_lines])

                        for prod_line in move_lines_to_pack_lines:
                            if prod_line.product_id.fedex_package_id.cover_amount_option == 'fixed':
                                cover_amount = prod_line.product_id.fedex_package_id.cover_amount
                        cover += cover_amount

                        move_lines_to_pack |= move_lines_to_pack_lines

                    package.cover_amount = cover
                package_level = self.env['stock.package_level'].create({
                    'package_id': package.id,
                    'picking_id': pick.id,
                    'location_id': False,
                    'location_dest_id': move_line_ids.mapped('location_dest_id').id,
                    'move_line_ids': [(6, 0, move_lines_to_pack.ids)],
                    'pack_move_line_ids': [(6, 0, move_lines_to_pack.ids)],
                    'company_id': self.env.user.company_id.id,
                })
                move_lines_to_pack.write({'result_package_id': package.id})
                package_ids |= package

            # for return_pack in pick.sale_id.return_packaging_ids:
            #     package = self.env['stock.quant.package'].create({
            #         'height': return_pack.height,
            #         'width': return_pack.width,
            #         'length': return_pack.length,
            #         'weight': return_pack.weight,
            #         'shipping_weight': return_pack.weight,
            #         'cover_amount': return_pack.cover_amount,
            #         'packaging_id': self.carrier_id.fedex_default_product_packaging_id.id,
            #         'order_id': pick.sale_id.id,
            #         'picking_id':pick.id,
            #       })
            #     package_ids |= package
        return package_ids
    
    def _put_in_pack(self):
        package = False
        for pick in self.filtered(lambda p: p.state not in ('done', 'cancel')):
            if pick.non_revenue_id:
                return pick._put_in_pack_non_revenue()
            else:
            # if pick.sale_id:
            #     if not pick.sale_id.is_pack_calc_needed:
            #         package = pick._3dbn_put_in_pack()
            # else:
                move_line_ids = pick.move_line_ids.filtered(lambda o: o.qty_done > 0 and not o.result_package_id and not o.product_id.own_packing and o.default_shipping_type in ('fedex', 'fedex_ground'))
                own_packing_move_line_ids = pick.move_line_ids.filtered(lambda o: o.qty_done > 0 and not o.result_package_id and o.product_id.own_packing and o.default_shipping_type in ('fedex', 'fedex_ground'))
                if move_line_ids:
                    if pick.sale_id:
                        if not pick.sale_id.is_pack_calc_needed:
                            # package = pick._3dbn_put_in_pack()
                            package = pick.my_put_in_pack()
                    else:
                        move_lines_to_pack = self.env['stock.move.line']
                        package = self.env['stock.quant.package'].create({})
                        for ml in move_line_ids:
                            if float_compare(ml.qty_done, ml.product_uom_qty,
                                             precision_rounding=ml.product_uom_id.rounding) >= 0:
                                move_lines_to_pack |= ml
                            else:
                                quantity_left_todo = float_round(
                                    ml.product_uom_qty - ml.qty_done,
                                    precision_rounding=ml.product_uom_id.rounding,
                                    rounding_method='UP')
                                done_to_keep = ml.qty_done
                                new_move_line = ml.copy(
                                    default={'product_uom_qty': 0, 'qty_done': ml.qty_done})
                                ml.write({'product_uom_qty': quantity_left_todo, 'qty_done': 0.0})
                                new_move_line.write({'product_uom_qty': done_to_keep})
                                move_lines_to_pack |= new_move_line

                        package_level = self.env['stock.package_level'].create({
                            'package_id': package.id,
                            'picking_id': pick.id,
                            'location_id': False,
                            'location_dest_id': move_line_ids.mapped('location_dest_id').id,
                            'move_line_ids': [(6, 0, move_lines_to_pack.ids)],
                            'pack_move_line_ids': [(6, 0, move_lines_to_pack.ids)],
                            'company_id': self.env.user.company_id.id,
                        })
                        move_lines_to_pack.write({
                            'result_package_id': package.id,
                        })
                elif own_packing_move_line_ids:
                    product_names = [line.product_id.name for line in own_packing_move_line_ids]
                    raise UserError(_('You must first assign own packages for the following products. \n\n%s' % "\n".join(product_names)))
                else:
                    raise UserError(_('You must first set the quantity you will put in the pack.'))
                return package
    
    
    def manage_packages(self):
        package = False
        for pick in self.filtered(lambda p: p.state not in ('done', 'cancel')):
            if pick.non_revenue_id:
                return pick.manage_packages_non_revenue()
            # if pick.sale_id:
            #     if not pick.sale_id.is_pack_calc_needed:
            #         pick._3dbn_put_in_pack()
            # else:
            else:
                assign_move_line_ids = pick.move_line_ids.filtered(lambda o: o.qty_done > 0 and not o.result_package_id and o.default_shipping_type in ('fedex', 'fedex_ground'))
                if assign_move_line_ids:
                    if pick.sale_id:
                        if not pick.sale_id.is_pack_calc_needed:
                            # pick._3dbn_put_in_pack()
                            pick.my_put_in_pack()
                    else:
                        move_line_ids = pick.move_line_ids.filtered(lambda o: o.qty_done > 0 and not o.result_package_id and not o.product_id.own_packing and o.default_shipping_type in ('fedex', 'fedex_ground'))
                        own_packing_move_line_ids = pick.move_line_ids.filtered(lambda o: o.qty_done > 0 and not o.result_package_id and o.product_id.own_packing and o.product_id.fedex_package_id and o.default_shipping_type in ('fedex', 'fedex_ground'))
                        for line in own_packing_move_line_ids:
                            self.env['choose.delivery.package'].put_packages_lines(line, line.product_id.fedex_package_id)

                        if move_line_ids:
                            self.env['choose.delivery.package'].put_packages_lines(move_line_ids, pick.carrier_id.fedex_default_product_packaging_id)
                else:
                    unassign_move_line_ids = pick.move_line_ids.filtered(lambda o: o.qty_done == 0 and not o.result_package_id and o.default_shipping_type in ('fedex', 'fedex_ground'))
                    if unassign_move_line_ids:
                        raise UserError(_('You must first set the quantity you will put in the pack.'))
                
    
#             move_line_ids = pick.move_line_ids.filtered(lambda o: o.qty_done > 0 and not o.product_id.own_packing and o.default_shipping_type == 'fedex')
#             
#             if move_line_ids:
#                 view_id = self.env.ref('delivery.choose_delivery_package_view_form').id
#                 return {
#                     'name': _('Package Details'),
#                     'type': 'ir.actions.act_window',
#                     'view_mode': 'form',
#                     'res_model': 'choose.delivery.package',
#                     'view_id': view_id,
#                     'views': [(view_id, 'form')],
#                     'target': 'new',
#                     'context': {
#                         'default_move_lines': [(6, 0, move_line_ids.ids)],
#                         'default_move_line_ids': [(6, 0, move_line_ids.ids)],
#                         'current_package_carrier_type': pick.carrier_id.delivery_type if pick.carrier_id.delivery_type not in ['base_on_rule', 'fixed'] else 'none',
#                         }
#                     }
#             else:
#                 if not own_packing_move_line_ids:
#                     raise UserError(_('You must first either select line or set the quantity you will put in the pack.'))
                
    
    
    def manage_change_packages(self):
        package = False
        for pick in self.filtered(lambda p: p.state not in ('done', 'cancel')):
            

                move_line_ids = pick.move_line_ids.filtered(lambda o: o.qty_done > 0 and o.result_package_id and not o.product_id.own_packing and o.default_shipping_type in ('fedex', 'fedex_ground'))
                
                if move_line_ids:
                    if pick.sale_id:
                        if not pick.sale_id.is_pack_calc_needed:
                            pick._3dbn_put_in_pack()
                    else:
                        view_id = self.env.ref('delivery.choose_delivery_package_view_form').id
                        return {
                            'name': _('Package Details'),
                            'type': 'ir.actions.act_window',
                            'view_mode': 'form',
                            'res_model': 'choose.delivery.package',
                            'view_id': view_id,
                            'views': [(view_id, 'form')],
                            'target': 'new',
                            'context': {
                                'default_move_lines': [(6, 0, move_line_ids.ids)],
                                'default_move_line_ids': [(6, 0, move_line_ids.ids)],
                                'default_delivery_packaging_id': pick.carrier_id.fedex_default_product_packaging_id.id,
                                'current_package_carrier_type': pick.carrier_id.delivery_type if pick.carrier_id.delivery_type not in ['base_on_rule', 'fixed'] else 'none',
                                }
                            }
                else:
                    raise UserError(_("You must first either click 'Put In Pack' or set the quantity you will put in the pack."))
    
    
    def create_product_avail_doc(self, attach, doc_template, return_label=False, pick=False):
        attach_name = attach.name
        if return_label:
            attach_name = 'Return ' + attach.name
        attachment_id = self.env['ir.attachment'].create({
            'name': attach_name,
            'type': 'binary',
            # 'datas_fname': attach.datas_fname,
            'datas': attach.datas,
            'res_model': 'product.avail.doc'
        })
        so_id = False
        if self.sale_id:
            so_id = self.sale_id.id
        avail_doc = self.env['product.avail.doc'].create({
            'doc_temp_id': doc_template.id,
            'initial_file_name': attach_name,
            'file': attachment_id.datas,
            'filename': attach_name,
            'name': attach_name,
            'attachment_ids': [(4, attachment_id.id)],
#             'picking_id': pick.id,
#             'is_do_view': True,
#             'so_id': so_id
        })
        avail_doc.so_id = so_id
        attachment_id.res_id = avail_doc.id
#         self.env['so.require.doc'].create({
#             'name': attach_name,
#             'filename': attach_name,
#             'file': avail_doc.file, 
#             'doc_temp_id':doc_template.id, 
#             'picking_id': pick.id, 
#             'doc_line_id':avail_doc.id
#             })
                            
        
        
    def _create_shipping_label(self, message,):
        
        picking_ids = [self]
        for move in self.move_ids_without_package:
            for dest_move in move.move_dest_ids:
                if dest_move.picking_id:
                    picking_ids.append(dest_move.picking_id)
        picking_ids = list(set(picking_ids))
        
        label_attachments = []
        
        shipping_label_vals = {
            'carrier_id': self.carrier_id.id,
            'picking_id': self.id,
            'label_status': 'active',
            'label_name': 'Fedex Label'
            }
        
        
        doc_template = self.env['product.document'].search([('name', 'like', 'FedEx Label')], limit=1)
        if not doc_template:
            doc_template = self.env['product.document'].search([('name', '=', 'General')], limit=1)
        if not doc_template:
            raise ValidationError("No template found for FedEx Label file name")
        
        
        
        
        label_attachments = []
        label_ref = []
        if len(self.package_ids) == len(message.attachment_ids):
            
            for index in range(len(self.package_ids)):
                vals = {
                    'document_id': message.attachment_ids[-index - 1].id,
                    'package_id': self.package_ids[index].id
                }
                label_attachments.append((0, 0, vals))
#                 shipping_label_vals['label_ids'] = label_attachments
                label = self.carrier_tracking_ref
                for ref in self.carrier_tracking_ref.split(','):
                    if ref in message.attachment_ids[-index - 1].name:
                        label = ref
                        break
                
                label_ref.append(label)
#                 shipping_label_vals['tracking_numbers'] = label
#                 for pick in picking_ids:
#                     shipping_label_vals['picking_id'] = pick.id
#                     self.env['shipping.label'].create(shipping_label_vals)
                
                # if self.sale_id:
                #     self.with_context(fedex_picking_ids=picking_ids).create_product_avail_doc(message.attachment_ids[-index - 1], doc_template, False)
                
                
        else:
            for attach in message.attachment_ids:
#                 label_attachments = [(0, 0, {'document_id': attach.id})]
                label_attachments.append((0, 0, {'document_id': attach.id}))
#                 shipping_label_vals['label_ids'] = label_attachments
                label = self.carrier_tracking_ref
                for ref in self.carrier_tracking_ref.split(','):
                    if ref in attach.name:
                        label = ref
                        break
                label_ref.append(label)
#                 shipping_label_vals['tracking_numbers'] = label
#                 for pick in picking_ids:
#                     shipping_label_vals['picking_id'] = pick.id
#                     self.env['shipping.label'].create(shipping_label_vals)
                    
                # if self.sale_id:
                #     self.with_context(fedex_picking_ids=picking_ids).create_product_avail_doc(attach, doc_template, False)
                
        
        shipping_labe_objs = []
        shipping_label_vals['tracking_numbers'] = ', '.join(label_ref)
        shipping_label_vals['label_ids'] = label_attachments
        for pick in picking_ids:
            shipping_label_vals['picking_id'] = pick.id
            shipping_labe_obj = self.env['shipping.label'].create(shipping_label_vals)
    
    def _create_return_shipping_label(self, message):
        
        picking_ids = [self]
        for move in self.move_ids_without_package:
            for dest_move in move.move_dest_ids:
                if dest_move.picking_id:
                    picking_ids.append(dest_move.picking_id)
        picking_ids = list(set(picking_ids))
        
        label_attachments = []
#         shipping_label_vals = {
#             'carrier_id': self.carrier_id.id,
#             'picking_id': self.id,
#             'label_status': 'active',
#             'label_name': 'FedEx Return Label'
#             }
        pdf_attachment = False
        doc_template = self.env['product.document'].search([('name', 'like', 'Return FedEx Label')], limit=1)
        if not doc_template:
            doc_template = self.env['product.document'].search([('name', '=', 'General')], limit=1)
        if not doc_template:
            raise ValidationError("No template found for Return FedEx Label file name")
        
        label_attachments = []
        label_ref = []
        
        if len(self.package_ids) == len(message.attachment_ids):
            for index in range(len(self.package_ids)):
                if 'pdf' in message.attachment_ids[-index - 1].name:
                    pdf_attachment = True
                vals = {
                    'document_id': message.attachment_ids[-index - 1].id,
                    'package_id': self.package_ids[index].id,
                    'is_return_label': True
                }
#                 label_attachments = [(0, 0, vals)]
                label_attachments.append((0, 0, vals))
#                 shipping_label_vals['label_ids'] = label_attachments
                label = self.return_carrier_tracking_ref
                for ref in self.return_carrier_tracking_ref.split(','):
                    if ref in message.attachment_ids[-index - 1].name:
                        label = ref
                        break
                label_ref.append(label)
#                 shipping_label_vals['tracking_numbers'] = label
                
#                 for pick in picking_ids:
#                     shipping_label_vals['picking_id'] = pick.id
#                     self.env['shipping.label'].create(shipping_label_vals)
                
                # if self.sale_id:
                #     self.with_context(fedex_picking_ids=picking_ids).create_product_avail_doc(message.attachment_ids[-index - 1], doc_template, True)
        else:
            for attach in message.attachment_ids:
                if 'pdf' in attach.name:
                    pdf_attachment = True
                label_attachments.append((0, 0, {'document_id': attach.id, 'is_return_label': True}))
#                 label_attachments = [(0, 0, {'document_id': attach.id})]
#                 shipping_label_vals['label_ids'] = label_attachments
                label = self.return_carrier_tracking_ref
                for ref in self.return_carrier_tracking_ref.split(','):
                    if ref in attach.name:
                        label = ref
                        break
                label_ref.append(label)
#                 shipping_label_vals['tracking_numbers'] = label
#                 for pick in picking_ids:
#                     shipping_label_vals['picking_id'] = pick.id
#                     self.env['shipping.label'].create(shipping_label_vals)
                # if self.sale_id:
                #     self.with_context(fedex_picking_ids=picking_ids).create_product_avail_doc(attach, doc_template, True)
        
        for pick in picking_ids:
            
            for label in pick.shipping_label_ids:
                create_label = False
                if pdf_attachment and label.label_ids.filtered(lambda l: '.pdf' in l.document_id.name):
                    create_label = True
                
                if not pdf_attachment and label.label_ids.filtered(lambda l: '.pdf' not in l.document_id.name):
                    create_label = True
                
                if create_label:
                    label.update({
                        'return_label_ids': label_attachments,
                        'return_tracking_numbers': ', '.join(label_ref)
                        })
                
    
class StockMoveLine(models.Model):
    _inherit = 'stock.move.line'
    
    
            
    def manage_package_type(self):
        self.ensure_one()
        
        if self.result_package_id:
            
            view_id = self.env.ref('fedex_shipping_integration.update_delivery_package_view_form_inherit').id
            return {
                'name': _('Update Package Details'),
                'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'res_model': 'update.delivery.package',
                'view_id': view_id,
                'views': [(view_id, 'form')],
                'target': 'new',
                'context': {
                    'default_move_line_id': self.id,
                    'default_result_package_id': self.result_package_id.id,
                    'default_shipping_weight': self.result_package_id.shipping_weight,
                    'default_override_weight': self.result_package_id.override_weight,
                    }
            }
        
        if self.product_id.own_packing and self.product_id.fedex_package_id and self.qty_done > 0:
            self.env['choose.delivery.package'].put_packages_lines(self, self.product_id.fedex_package_id)
        else:
            view_id = self.env.ref('delivery.choose_delivery_package_view_form').id
            return {
                'name': _('Package Details'),
                'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'res_model': 'choose.delivery.package',
                'view_id': view_id,
                'views': [(view_id, 'form')],
                'target': 'new',
                'context': {
                    'default_move_line_id': self.id,
                    'default_stock_quant_package_id': self.result_package_id.id,
                    'current_package_carrier_type': self.picking_id.carrier_id.delivery_type if self.picking_id.carrier_id.delivery_type not in ['base_on_rule', 'fixed'] else 'none',
                    }
            }
        
    pack_select = fields.Boolean('Package Select', copy=False)
    default_shipping_type = fields.Selection(related='move_id.default_shipping_type', string="Ship Type", readonly=False)
    override_fedex_flow = fields.Boolean(related='move_id.override_fedex_flow', string="Manual FedEx", readonly=False)
    generate_return_label = fields.Boolean(related='move_id.generate_return_label',string='Return Label', copy=False)
    
class StockMove(models.Model):
    _inherit = 'stock.move'

    def _get_new_picking_values(self):
        vals = super(StockMove, self)._get_new_picking_values()
        order_id = self.sale_line_id.order_id
        if order_id and order_id.fedex_saturday_service:
            vals.update({
                'fedex_saturday_service': True
            })
            
#         if self.sale_line_id and  vals.get('carrier_id', False):
#             del vals['carrier_id']
#         else:
#             if self.origin:
#                 sale_obj = self.env['sale.order'].search([('name', '=', self.origin)], limit=1)
#                 if sale_obj and sale_obj.carrier_id:
#                     vals['carrier_id'] = sale_obj.carrier_id.id
        return vals
    
    override_fedex_flow = fields.Boolean(string='Manual FedEx', copy=False)
    generate_return_label = fields.Boolean(string='Return Label', copy=False)
    default_shipping_type = fields.Selection(selection_add=[
        ('fedex_ground','Fedex Ground'),
        ('no_box', 'No Box'),
        ], string="Ship Type")
    
    
class FedExPackageDetails(models.Model):
    _inherit = "stock.quant.package"
    
    
    custom_tracking_number = fields.Char(string = "FedEx Tracking Number", help = "If tracking number available print it in this field.")
    override_weight = fields.Boolean('Override Weight')
    
    
class StockRule(models.Model):
    _inherit = 'stock.rule'
    
    
    def _get_stock_move_values(self, product_id, product_qty, product_uom, location_id, name, origin, values, group_id):
        res = super(StockRule, self)._get_stock_move_values(product_id, product_qty, product_uom, location_id, name or '', origin, values, group_id)
        if res.get('sale_line_id'):
            so_line = self.env['sale.order.line'].search([('id', '=', res.get('sale_line_id'))])
            if so_line.override_fedex_flow:
                res.update({'override_fedex_flow': so_line.override_fedex_flow})
            if so_line.generate_return_label:
                res.update({'generate_return_label': so_line.generate_return_label})
        if 'move_dest_ids' in res and res.get('move_dest_ids'):
            for mv in res.get('move_dest_ids'):
                if len(mv) > 1:
                    mv_record = self.env['stock.move'].search([('id', '=', mv[1])])
                    res.update({
                        'override_fedex_flow': mv_record.override_fedex_flow,
                        'generate_return_label': mv_record.generate_return_label,
                        })
        return res
    

class ShippingLabel(models.Model):
    _inherit = 'shipping.label'
    
    label_name = fields.Char('Label')
    return_tracking_numbers = fields.Char(
        string='Return Tracking Number(s)',
        readonly=True,
    )
    
    

class StockPackageLevel(models.Model):
    _inherit = 'stock.package_level'

    pack_move_line_ids = fields.Many2many('stock.move.line', 'stock_move_line_package_level_rel', 'package_level_id', 'move_line_id', 'Pack Move Lines')
    

class StockQuantPackage(models.Model):
    _inherit = 'stock.quant.package'
    
    
    
    def _compute_package_quant_ids(self):
        for line in self:
            quants = self.env['stock.quant']
            package_level = self.env['stock.package_level'].search([('package_id', '=', line.id)], limit=1)
            if package_level:
                for move in package_level.pack_move_line_ids:
                    if move.lot_id and move.result_package_id:
                        quants += self.env['stock.quant'].search([('package_id', '=', move.result_package_id.id),('lot_id', '=', move.lot_id.id)], limit=1)
            
            self.package_quant_ids = quants
            if line.quant_ids:
                self.package_quant = True
            else:
                self.package_quant = False



    package_quant_ids = fields.Many2many('stock.quant', string='Bulk Content', compute='_compute_package_quant_ids')
    package_quant = fields.Boolean('Package Quant Set', compute='_compute_package_quant_ids')
    
    
    
    
    
    
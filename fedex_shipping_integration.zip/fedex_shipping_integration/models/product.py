from odoo import models, fields, api, _


class ProductProduct(models.Model):
    _inherit = 'product.product'

    own_packing = fields.Boolean(string='Own Packing')
    width = fields.Float('Width', default=1)
    height = fields.Float('Height', default=1)
    depth = fields.Float('Length', default=1)
    fedex_package_id = fields.Many2one('product.packaging', 'Package')
    fedex_return_label = fields.Boolean(string='FedEx Return Label')
    default_shipping_type = fields.Selection(selection_add=[
        ('fedex_ground','Fedex Ground'),
        ('no_box', 'No Box'),
        ], string="Default Shipping Type")
    
    # jet_mail_reference = fields.Char(string='Jetmail Reference', copy=False)


class ProductPackaging(models.Model):
    _inherit = 'product.packaging'

    shipper_package_code = fields.Char('Carrier Code')
    package_carrier_type = fields.Selection([('fedex_shipping_provider', 'Fedex')])
    max_weight = fields.Float('Max Weight', help='Maximum weight shippable in this packaging')
    
    
    
    
class ProductTemplate(models.Model):
    _inherit = 'product.template'
    
    is_retail_fee = fields.Boolean(string="Is Retail Fee ?", default=False, help="Using this field sale order line auto added product where confirgured in avatax advance tab")



    
# class SuggestedProduct(models.Model):
#     _inherit = 'btl.suggested.product'
#
#     default_shipping_type = fields.Selection([
#         ('freight', 'Freight'),
#         ('fedex','Fedex Express'),
#         ('fedex_ground','Fedex Ground'),
#         ('jetmail', 'Jetmail'),
#         ('no_box', 'No Box'),
#         ], string="Default Shipping Type")
#
#     def update_default_shipping_type(self, vals):
#         if vals.get('default_shipping_type', False):
#             sale_line_obj = self.env['sale.order.line'].search([('order_id.state', 'in', ('draft', 'sent')), ('product_id', '=', self.product_id.id)])
#             for line in sale_line_obj:
#                 line.default_shipping_type = self.default_shipping_type
#
#     @api.model
#     def create(self, vals):
#         res = super(SuggestedProduct, self).create(vals)
#         res.update_default_shipping_type(vals)
#         return res
#
#     def write(self, vals):
#         res = super(SuggestedProduct, self).write(vals)
#         self.update_default_shipping_type(vals)
#         return res
#
class RequiredDoc(models.Model):
    _inherit = 'so.require.doc'

    def _compute_file(self):
        for rec in self:
            if rec.doc_line_id and rec.doc_line_id.doc_temp_id and rec.doc_line_id.is_do_view:
                if rec.picking_id.picking_type_id.code in ('outgoing', 'internal'):
                    rec.file = rec.doc_line_id.file
                    rec.filename = rec.doc_line_id.filename
                    rec.doc_temp_id = rec.doc_line_id.doc_temp_id.id

    def _get_attachment_list(self):
        self.ensure_one()
        attachment_list = []
        if self.doc_line_id:
            if 'Fedex-' in self.filename or 'Return Fedex-' in self.filename:
                params = {
                    'title': self.filename,
                    'type': 'qweb-pdf',
                    'size': 200,
                }
                if self.file:
                    attachment_list.append((self.file.decode('ascii'), params))
            else:
                for doc in self.doc_line_id.so_id.document_ids:
                    for att in doc.attachment_ids:
                        doc = att
                        params = {
                            'title': doc.name,
                            'type': 'qweb-pdf' if doc.mimetype == 'application/pdf' else 'qweb-text',
                            'size': 200,
                        }
                        if doc.datas:
                            attachment_list.append((doc.datas.decode('ascii'), params))
        return attachment_list


class ir_attachment(models.Model):
    _inherit = "ir.attachment"

    @api.model
    def __get_document_id(self, res_model, res_id, name):
        obj_model = self.env[res_model]
        if obj_model._name == 'product.avail.doc':
            return res_id
        if 'Fedex' not in name:
            record = obj_model.browse(res_id)
            attachment_name = ''
            if len(attachment_name) > 10:
                attachment_name = name.split('.')[0][:-5]
            try:
                for doc in record.document_ids:
                    if doc.name and attachment_name.upper() in doc.name.upper():
                        return doc.id
            except Exception as e:
                pass
        return False


class ProductAvailDoc(models.Model):
    _inherit = "product.avail.doc"
    
    
    def write(self, vals):
        res = super(ProductAvailDoc, self).write(vals)
        for obj in self:
            if 'non_revenue_id' in vals and vals['non_revenue_id']:
                if obj.initial_file_name and 'Fedex' in obj.initial_file_name:
                    obj.update({
                        'revenue_id': vals['non_revenue_id'],
                        'non_revenue_id': False
                        })
        return res

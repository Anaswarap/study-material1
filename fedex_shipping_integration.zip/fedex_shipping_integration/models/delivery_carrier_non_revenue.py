import binascii
import time
import datetime
from datetime import datetime
from requests import request
import base64
import requests
import shutil
import json
import pprint
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

import logging
_logger = logging.getLogger("BTL Fedex API Request: ")


class DeliveryCarrier(models.Model):
    _inherit = "delivery.carrier"

    
    def add_fedex_package_non_revenue(self, ship_request, weight, package_count, number=1, master_tracking_id=False,
                          package_id=False, picking_obj=False, return_pack=False):
        
        package = {
            "weight": {
                "value": weight,
                "units": self.fedex_weight_uom
                }
            }
        
        Length = Width = Height = 0
        if picking_obj.non_revenue_id and not picking_obj.non_revenue_id.is_pack_calc_needed and package_id:
            Length = int(package_id.length) 
            Width = int(package_id.width)
            Height = int(package_id.height)
            Units = 'IN' if self.fedex_weight_uom == 'LB' else 'CM'
        
        elif self.fedex_default_product_packaging_id.shipper_package_code == 'YOUR_PACKAGING':
            Length = package_id and package_id.packaging_id.packaging_length if package_id and package_id.packaging_id.packaging_length else self.fedex_default_product_packaging_id.packaging_length
            Width = package_id and package_id.packaging_id.width if package_id and package_id.packaging_id.width else self.fedex_default_product_packaging_id.width
            Height = package_id and package_id.packaging_id.height if package_id and package_id.packaging_id.height else self.fedex_default_product_packaging_id.height
            Units = 'IN' if self.fedex_weight_uom == 'LB' else 'CM'
        PhysicalPackaging = 'BOX'
        
        package.update({
            "dimensions":{
                "length": Length,
                "width": Width,
                "height": Height,
                "units": Units,
                },
            "physicalPackaging": 'BOX',
            })
        package_level = False
        if package_id:
            package_level = self.env['stock.package_level'].search([('package_id', '=', package_id.id)], limit=1)
        else:
            package_level = self.env['stock.package_level']
        main_lot_number = []
        if picking_obj:
            for move_obj in picking_obj.move_ids_without_package:
                if move_obj.move_line_ids:
                    for line in move_obj.move_line_ids:
                        if line.lot_id and not line.lot_id.lot_id and line.default_shipping_type in ('fedex', 'fedex_ground') and not line.override_fedex_flow:
                            if package_id:
                                if line.result_package_id.id == package_id.id:
                                    main_lot_number.append(line.lot_id.name)
                                elif package_level and package_level.pack_move_line_ids and line.id in package_level.pack_move_line_ids.ids:
                                    main_lot_number.append(line.lot_id.name)
                            else:
                                main_lot_number.append(line.lot_id.name)
                                
        INVOICE_NUMBER = ''
        CUSTOMER_REFERENCE = ''
        if main_lot_number:
            half = len(main_lot_number)//2
            CUSTOMER_REFERENCE = main_lot_number[:half]
            INVOICE_NUMBER = main_lot_number[half:]
        
        
        if not return_pack:
            CustomerReference2_Value = "%s"%(",".join(INVOICE_NUMBER)[:29])
        else:
            CustomerReference2_Value = "%s"%("SO Return")
        package.update({
            "customerReferences": [{
                    "customerReferenceType": "P_O_NUMBER",  # customer reference 1,
                    "value": "%s"%(picking_obj.origin),
                    },
                {
                    "customerReferenceType": "INVOICE_NUMBER",  # customer reference 2,
                    "value": CustomerReference2_Value,
                    },
                {
                    "customerReferenceType": "CUSTOMER_REFERENCE",  # customer reference 3,
                    "value": "%s"%(",".join(CUSTOMER_REFERENCE)[:29]),
                    },
                {
                    "customerReferenceType": "DEPARTMENT_NUMBER",  # customer reference 4,
                    "value": "Sales",
                    },
            ]
            
            })

        if number:
            package.update({"sequenceNumber": number})
        
        if picking_obj.non_revenue_id:
            if return_pack:
                if picking_obj.non_revenue_id.return_signature_type:
                    package.update({"packageSpecialServices" : {
                        "specialServiceTypes": [
                            "SIGNATURE_OPTION"
                            ],
                        "signatureOptionType":  picking_obj.non_revenue_id.return_signature_type
                        }})
                    
            else:
                if picking_obj.non_revenue_id.signature_type:
                    
                    package.update({"packageSpecialServices" : {
                        "specialServiceTypes": [
                            "SIGNATURE_OPTION"
                            ],
                        "signatureOptionType":  picking_obj.non_revenue_id.signature_type
                        }})
        
        
        ship_request["requestedShipment"].update({
            "requestedPackageLineItems": [package],
            "totalWeight": weight,
            "packageCount": package_count
            })
        # add saturday delivery service
        saturday_service = picking_obj and picking_obj.fedex_saturday_service or False
        if saturday_service:
            ship_request["requestedShipment"].update({
                "specialServicesRequested": {
                    "specialServiceTypes": ["SATURDAY_DELIVERY"]
                    }
                 })
            
        # add signatre
        if master_tracking_id:
            
            ship_request["requestedShipment"].update({
                "masterTrackingId": {
                    "trackingIdType": "FEDEX",
                    "trackingNumber": master_tracking_id
                    }
                 })
            
                    
        return ship_request
   
    
    
    def fedex_shipping_provider_rate_shipment_non_revenue(self, orders):
        res = []
        shipping_charge = 0.0
        delivery_date = ''
        PAYOR_ACCOUNT_PACKAGE = 0.0
        PAYOR_LIST_PACKAGE = 0.0
        index = 0
        for order in orders:
            
            if not order.is_pack_calc_needed:
                # order.calculate_package()
                if not order.pack_info_ids:
                    order.calculate_package()
                return self.fedex_shipping_provider_rate_shipment_3dbin(order)
            else:
                order_line1s_without_weight = order.order_line1.filtered(
                    lambda line_item: not line_item.product_id.type in ['service', 'digital'] and not line_item.product_id.weight and \
                    not line_item.is_delivery and line_item.default_shipping_type in ('fedex', 'jetmail', 'fedex_ground') and not line_item.override_fedex_flow)
                for order_line1 in order_line1s_without_weight:
                    raise ValidationError("Please define weight in product : \n %s" % (order_line1.product_id.name))
    
                # Shipper and Recipient Address
                shipper_address = order.warehouse_id.partner_id
                recipient_address = order.partner_shipping_id
                shipping_credential = self.company_id
    
                # check sender Address
                if not shipper_address.zip or not shipper_address.city or not shipper_address.country_id:
                    raise ValidationError("Please Define Proper Sender Address!")
    
                # check Receiver Address
                if not recipient_address.zip or not recipient_address.city or not recipient_address.country_id:
                    raise ValidationError("Please Define Proper Recipient Address!")
    
                
                max_weight = self.company_id.weight_convertion(self.fedex_weight_uom,
                                                               self.fedex_default_product_packaging_id.max_weight)
                
                    
                api_url = "{0}/rate/v1/rates/quotes".format(self.company_id.fedex_api_url)
                headers = {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'Authorization': 'Bearer {0}'.format(self.company_id.fedex_access_token)
                }
                rate_request = {
                    "accountNumber": {"value": "{0}".format(self.company_id.fedex_account_number)},
                    "requestedShipment": {
                        "shipper": self.get_fedex_address_dict(shipper_address),
                        "recipient": self.get_fedex_address_dict(recipient_address),
                        "pickupType": self.fedex_pickup_type,
                        "serviceType": self.fedex_service_type,
                        "packagingType": self.fedex_default_product_packaging_id.shipper_package_code,
                        "rateRequestType": ["{0}".format(self.fedex_request_type)],
                        "shipDateStamp": datetime.now().strftime('%Y-%m-%d'),
                        # "totalWeight": ((total_weight) or 0),
                        "preferredCurrency": order.currency_id.name,
                        "requestedPackageLineItems": [],
                        "rateRequestType": ["ACCOUNT", "LIST"],
                        "specialServicesRequested": {}
                    }
                }
                
                if not self.company_id.disable_future_day:
                    rate_request['requestedShipment']['shipDateStamp'] = order.future_day.strftime('%Y-%m-%d')
                
                
                        
                package_type = self.fedex_default_product_packaging_id.shipper_package_code
                
                self.prepare_shipment_request(shipping_credential, rate_request, shipper_address, recipient_address, package_type, order)
    
              
                
                own_packing_order_line1_ids = order.order_line1.filtered(lambda o: o.default_shipping_type in ('fedex', 'fedex_ground') and o.product_id.own_packing and o.product_id.fedex_package_id and not o.override_fedex_flow)
                for own_line in own_packing_order_line1_ids:
                    index += 1
                    line_weight = own_line.product_id.weight * own_line.product_uom_qty
                    line_weight = self.company_id.weight_convertion(self.fedex_weight_uom, line_weight)
                    self.manage_fedex_packages(rate_request, line_weight, index, order, own_line.product_id)
                    
                    
                        
                own_packing_jetmail_line_ids = order.order_line1.filtered(lambda o: o.default_shipping_type == 'jetmail' and o.product_id.own_packing and o.product_id.fedex_package_id and not o.override_fedex_flow)
                for own_line in own_packing_jetmail_line_ids:
                    index += 1
                    line_weight = own_line.product_id.weight * own_line.product_uom_qty
                    line_weight = self.company_id.weight_convertion(self.fedex_weight_uom, line_weight)
                    self.manage_fedex_packages(rate_request, line_weight, index, order, own_line.product_id)
                    
                
                
                
                fedex_total_weight_not_packing = sum([(line.product_id.weight * line.product_uom_qty) for line in order.order_line1 if line.default_shipping_type in ('fedex', 'fedex_ground') and not line.product_id.own_packing and not line.override_fedex_flow]) or 0.0
                fedex_total_weight_not_packing = self.company_id.weight_convertion(self.fedex_weight_uom, fedex_total_weight_not_packing)
                if fedex_total_weight_not_packing > 0.0:
                    index += 1
                    self.manage_fedex_packages(rate_request, fedex_total_weight_not_packing, index, order)
                    
                
                jetmail_total_weight_not_packing = sum([(line.product_id.weight * line.product_uom_qty) for line in order.order_line1 if line.default_shipping_type == 'jetmail' and not line.product_id.own_packing and not line.override_fedex_flow]) or 0.0
                jetmail_total_weight_not_packing = self.company_id.weight_convertion(self.fedex_weight_uom, jetmail_total_weight_not_packing)
                if jetmail_total_weight_not_packing > 0.0:
                    index += 1
                    self.manage_fedex_packages(rate_request, jetmail_total_weight_not_packing, index, order)
                    
    
                rate_request['requestedShipment']['packageCount'] = index
                
                
                
                
                if self.fedex_onerate:
                
                    rate_request['requestedShipment']['specialServicesRequested'].update({'specialServiceTypes': ['FEDEX_ONE_RATE']})
                
                if self.is_cod and not order.fedex_third_party_account_number_sale_order:
                    if 'specialServiceTypes' in rate_request['requestedShipment']['specialServicesRequested']:
                        rate_request['requestedShipment']['specialServicesRequested']['specialServiceTypes'].append('COD')
                        rate_request['requestedShipment']['specialServicesRequested']['codDetail'] = {
                            "codCollectionAmount": {
                                "currency": order.company_id.currency_id.name,
                                "amount": order.amount_total,
                                },
                            "collectionType": {"value": "%s" % (self.fedex_collection_type)},
                            }
                
                    rate_request['requestedShipment']['specialServicesRequested']['specialServiceTypes']['codDetail']['codRecipient'] = {
                        "personName": shipper_address.name if not shipper_address.is_company else '',
                        "companyName": shipper_address.name if shipper_address.is_company else '',
                        "phoneNumber": shipper_address.phone,
                        "address": {
                            "streetLines":  shipper_address.street and shipper_address.street2 and [shipper_address.street, shipper_address.street2] or [shipper_address.street],
                            "city": shipper_address.city or None,
                            "stateOrProvinceCode": shipper_address.state_id and shipper_address.state_id.code or None,
                            "postalCode": shipper_address.zip,
                            "countryCode": shipper_address.country_id.code,
                            },
                
                        }
                
                if order.fedex_saturday_service:
                
                    if 'specialServiceTypes' in rate_request['requestedShipment']['specialServicesRequested']:
                        rate_request['requestedShipment']['specialServicesRequested']['specialServiceTypes'].append('SATURDAY_DELIVERY')
                
    
    
                rate_request['requestedShipment'].update({'rateRequestTypes': ['LIST', 'ACCOUNT']})
                
                _logger.info("Rate Fedex API Request %s" % pprint.pformat(rate_request, indent=1))
                response_data = requests.request("POST", api_url, headers=headers, data=json.dumps(rate_request))
                if response_data.status_code in [200, 201]:
                    response_data = response_data.json()
                    _logger.info("Rate Fedex API Response %s" % pprint.pformat(response_data, indent=1))
                    delivery_date = False
                    if response_data.get('output') and response_data.get('output').get('rateReplyDetails'):
                        for rateReplyDetail in response_data.get('output').get('rateReplyDetails'):
                            if self.fedex_service_type == rateReplyDetail.get("serviceType"):
                                for rate_info in rateReplyDetail.get('ratedShipmentDetails'):
                                    if rate_info['rateType'] == 'ACCOUNT':
                                        PAYOR_ACCOUNT_PACKAGE = float(rate_info['totalNetFedExCharge'])
                                    elif rate_info['rateType'] == 'LIST':
                                        PAYOR_LIST_PACKAGE = float(rate_info['totalNetFedExCharge'])
                                    else:
                                        shipping_charge = float(rate_info['totalNetFedExCharge'])
            
                                    shipping_charge_currency = rate_info['currency']
                                    if order.currency_id.name != shipping_charge_currency:
                                        rate_currency = self.env['res.currency'].search([('name', '=', shipping_charge_currency)],
                                                                                        limit=1)
                                        if rate_currency:
                                            shipping_charge = rate_currency.compute(float(shipping_charge), order.currency_id)
            
                                            PAYOR_ACCOUNT_PACKAGE = rate_currency.compute(float(PAYOR_ACCOUNT_PACKAGE), order.currency_id)
                                            PAYOR_LIST_PACKAGE = rate_currency.compute(float(PAYOR_LIST_PACKAGE), order.currency_id)
                                    
                                    
                                    
                                   
                    else:
                        return {'success': False, 'price': 0.0, 'error_message': response_data,
                                'warning_message': False}
                else:
                    return {'success': False, 'price': 0.0, 'error_message': response_data.text,
                                'warning_message': False}
        return {
            'success': True, 
            'price': float(PAYOR_LIST_PACKAGE) + self.add_custom_margin,
            'account_price': float(PAYOR_ACCOUNT_PACKAGE) + self.add_custom_margin,
            'delivery_date': delivery_date,
            'package_count': index,
            'error_message': False,
            'warning_message': False}

    
    
    def fedex_shipping_provider_send_shipping_non_revenue(self, pickings):
        res = []
        fedex_master_tracking_id = False
        for picking in pickings:
#             if not (picking.non_revenue_id and picking.non_revenue_id.fedex_bill_by_third_party_sale_order):
#                 picking.get_fedex_rate()
            exact_price = 0.0
            tracking_number = []
            attachments = []
            pdf_attachments = []
            move_products = []
            if picking.non_revenue_id:
                move_products = [order_line1.product_id.id for order_line1 in picking.non_revenue_id.order_line1 if order_line1.default_shipping_type in ('fedex', 'fedex_ground') and not order_line1.override_fedex_flow]
                        
#             total_bulk_weight = sum([(line.product_id.weight * line.product_uom_qty) for line in picking.move_ids_without_package if line.default_shipping_type in ('fedex', 'jetmail')]) or 0.0
            total_bulk_weight = 0.0
            for move_line in picking.move_line_ids:
                if move_line.product_id and not move_line.result_package_id and  move_line.default_shipping_type in ('fedex', 'fedex_ground') and not move_line.override_fedex_flow:
                    total_bulk_weight += move_line.product_uom_id._compute_quantity(move_line.qty_done, move_line.product_id.uom_id) * move_line.product_id.weight
            
#             total_bulk_weight = self.company_id.weight_convertion(self.fedex_weight_uom, picking.weight_bulk)
            total_bulk_weight = self.company_id.weight_convertion(self.fedex_weight_uom, total_bulk_weight)
#             package_count = len(picking.package_ids)
            packs = []
            for package in picking.package_ids:
                package_level_ids = self.env['stock.package_level'].search([('package_id', '=', package.id)])
                for move_line in picking.move_line_ids:
                    for package_level in package_level_ids:
                        if move_line.product_id.own_packing and package_level and package_level.pack_move_line_ids and move_line.id in package_level.pack_move_line_ids.ids and move_line.product_id.id in move_products:
                            packs.append(package.id)
                        elif package.id == move_line.result_package_id.id and move_line.default_shipping_type in ('fedex', 'fedex_ground') and move_line.product_id.id in move_products and not  move_line.override_fedex_flow:
                            packs.append(package.id)

            package_count = len(list(set(packs)))
            if total_bulk_weight:
                package_count += 1
            
            shipping_credential = self.company_id

            if not self._context.get('use_fedex_return', False) and picking.picking_type_code == "incoming":
                shipping_data = {
                    'exact_price': picking.carrier_price,
                    'tracking_number': picking.carrier_tracking_ref}
                return [shipping_data]

            if picking.picking_type_code == "incoming":
                shipper_address = picking.partner_id
                recipient_address = picking.picking_type_id.warehouse_id.partner_id
            else:
                recipient_address = picking.partner_id
                shipper_address = picking.picking_type_id.warehouse_id.partner_id
            # try:
            
            
            api_url = "{0}/ship/v1/shipments".format(self.company_id.fedex_api_url)
            headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'Authorization': 'Bearer {0}'.format(self.company_id.fedex_access_token)
            }
            ship_request = {
                "mergeLabelDocOption": "LABELS_AND_DOCS",
                "labelResponseOptions": "LABEL",
                "shipAction": "CONFIRM",
                "accountNumber": {"value": "{0}".format(self.company_id.fedex_account_number)},
                "requestedShipment": {
                    # "shipper": self.get_fedex_address_dict(shipper_address),
                    # "recipient": self.get_fedex_address_dict(recipient_address),
                    "pickupType": self.fedex_pickup_type,
                    "serviceType": self.fedex_service_type,
                    "packagingType": self.fedex_default_product_packaging_id.shipper_package_code,
                    "rateRequestType": ["{0}".format(self.fedex_request_type)],
                    "shipTimestamp": datetime.now().strftime('%Y-%m-%d'),
                    # "totalWeight": ((total_weight) or 0),
                    # "preferredCurrency": order.currency_id.name,
                    "requestedPackageLineItems": [],
                    "specialServicesRequested": {},
                    # "rateRequestType": ["ACCOUNT", "LIST"],
                    
                    "labelSpecification": {
                        "labelFormatType": "COMMON2D",
                        "imageType": self.fedex_shipping_label_file_type,
                        "labelStockType": self.fedex_shipping_label_stock_type,
                        "labelPrintingOrientation": "BOTTOM_EDGE_OF_TEXT_FIRST",
                        "labelOrder": "SHIPPING_LABEL_FIRST"
                        }
                    
                }
            }
            
            if picking.non_revenue_id and picking.non_revenue_id.future_day and not picking.non_revenue_id.company_id.disable_future_day:
                ship_request['requestedShipment'].update({
                    'shipDatestamp': picking.non_revenue_id.future_day.strftime('%Y-%m-%d'),
                    })
            package_type = self.fedex_default_product_packaging_id.shipper_package_code
                
            self.prepare_shipment_request(shipping_credential, ship_request, shipper_address, recipient_address, package_type, picking.non_revenue_id, True)
            
            sequence = 0
            for seq, package in enumerate(picking.package_ids, start=1):
                
                # A multiple-package shipment (MPS) consists of two or more packages shipped to the same recipient.
                # The first package in the shipment request is considered the master package.

                # Note: The maximum number of packages in an MPS request is 200.
                if package.id in packs:
                    sequence += 1
                    shipping_weight = 0.0
                    if package.override_weight:
                        shipping_weight = package.shipping_weight
                    else:
                       for move_line in picking.move_line_ids:
                            if package.id == move_line.result_package_id.id and move_line.default_shipping_type in ('fedex', 'fedex_ground') and move_line.product_id.id in move_products and not  move_line.override_fedex_flow:
                                shipping_weight += move_line.qty_done * move_line.product_id.weight
                    package_weight = self.company_id.weight_convertion(self.fedex_weight_uom, shipping_weight)
                    if package_weight > 0.0:
                        
                        
                        if self.fedex_service_type in ['INTERNATIONAL_ECONOMY', 'INTERNATIONAL_FIRST','INTERNATIONAL_PRIORITY']:
                            order = picking.non_revenue_id
                            
                            company = order.company_id or picking.company_id or self.env.user.company_id
                            order_currency = picking.non_revenue_id.currency_id or picking.company_id.currency_id
                            commodity_country_of_manufacture = picking.picking_type_id.warehouse_id.partner_id.country_id.code
                            commodity_weight_units = self.fedex_weight_uom
                            total_commodities_amount = 0.0
                            comodities_packages = []
                            for operation in picking.move_line_ids:
                                if package.id == operation.result_package_id.id and operation.default_shipping_type in ('fedex', 'fedex_ground') and operation.product_id.id in move_products and not  operation.override_fedex_flow:
                                    commodity_amount = order_currency._convert(operation.product_id.list_price, order_currency,
                                                                               company, order.date_order or fields.Date.today())
                                    total_commodities_amount += (commodity_amount * operation.qty_done)
                                    
                                    comodities_packages.append({
                                        "unitPrice" : {
                                            "currency": order_currency.name,
                                            "amount": commodity_amount,
                                            },
                                        "numberOfPieces": 1,
                                        "countryOfManufacture": commodity_country_of_manufacture,
                                        "weight" : {
                                            "units": commodity_weight_units,
                                            "value": self.company_id.weight_convertion(self.fedex_weight_uom,
                                                                                   operation.product_id.weight * operation.qty_done),
                                            },
                                        "description": operation.product_id.name,
                                        "quantity": operation.qty_done,
                                        "quantityUnits": 'EA'
                                        })
                                    
                            
                            ship_request['requestedShipment'].update({
                                "customsClearanceDetail": {
                                    "exportDetail": {
                                        "exportComplianceStatement":'30.37(f)'
                                        },
                                    "dutiesPayment": {
                                        "paymentType": "THIRD_PARTY" if order.fedex_bill_by_third_party_sale_order else "SENDER",
                                        },
                                    "customsValue": {
                                        "amount": total_commodities_amount,
                                        "currency": picking.non_revenue_id.currency_id.name or picking.company_id.currency_id.name,
                                        },
                                    "isDocumentOnly": True,
                                    "commodities": comodities_packages
                                    }
                                    
                                })
                        
                        ship_request = self.add_fedex_package_non_revenue(ship_request, package_weight, package_count, number=sequence,
                                                              master_tracking_id=fedex_master_tracking_id,
                                                              package_id=package, picking_obj=picking)
                        
                        if self.fedex_onerate:
                            if 'specialServiceTypes' in ship_request['requestedShipment']['specialServicesRequested']:
                                rate_request['requestedShipment']['specialServicesRequested']['specialServiceTypes'].append('SATURDAY_DELIVERY')
                        
                        
                            
                            
                        _logger.info("Shipment Fedex API Request %s" % pprint.pformat(ship_request, indent=1))
                        response_data = self.send_fedex_api_request(api_url, headers, ship_request)
                        
                        if response_data.status_code in [200, 201]:
                            response_data = response_data.json()
                            _logger.info("Shipment Response Data %s" % pprint.pformat(response_data, indent=1))
                            if response_data.get('output') and response_data.get('output').get('transactionShipments'):
                                for transaction_shipment in response_data.get('output').get('transactionShipments'):
                                    carrier_tracking_ref = transaction_shipment.get('masterTrackingNumber')
                                    tracking_number.append(carrier_tracking_ref)
                                    for piece_respone in transaction_shipment.get('pieceResponses'):
                                        for package_document in piece_respone.get('packageDocuments'):
                                            if package_document.get('contentType') == 'ACCEPTANCE_LABEL':
                                                label_type = 'Fedex_Return'
                                            else:
                                                label_type = 'Fedex'
                                            label_binary_data = binascii.a2b_base64(package_document.get('encodedLabel'))
                                            attachments.append(
                                                ('%s.%s.%s' % (label_type,
                                                               piece_respone.get('packageSequenceNumber') or carrier_tracking_ref,
                                                               self.fedex_shipping_label_file_type),
                                                 label_binary_data))
                                            
                                            self.convert_fedex_zpl_to_pdf_label(label_type, piece_respone.get('packageSequenceNumber') or carrier_tracking_ref, 'pdf', package_document.get('encodedLabel'), pdf_attachments)
                                        exact_price += piece_respone.get('baseRateAmount')
                                    if shipper_address.country_id.code != recipient_address.country_id.code:
                                        commercial_label = binascii.a2b_base64(
                                            response_data.get('output').get('transactionShipments')[0].get('shipmentDocuments')[
                                                0].get(
                                                'encodedLabel'))
                                        if commercial_label:
                                            attachments.append(
                                                ('commercial invoice -%s.%s' % (
                                                    carrier_tracking_ref,
                                                    self.fedex_shipping_label_file_type),
                                                 commercial_label))
                                    
                                    package.custom_tracking_number = tracking_number
                                    if sequence == 1 and package_count > 1:
                                        fedex_master_tracking_id = carrier_tracking_ref
                            else:
                                
                                raise ValidationError(response_data)
                        else:
                            error_description = response_data.text
                            response_data = response_data.json()
                            if 'errors' in response_data:
                                error_description = response_data['errors']
                                
                                # if error_description and isinstance(error_description, list) and 'message' in error_description[0]:
                                #     error_description = error_description[0]['message']
                            raise ValidationError(str(error_description))
                                    
            
            if total_bulk_weight:
                order = picking.non_revenue_id
                if self.fedex_service_type in ['INTERNATIONAL_ECONOMY', 'INTERNATIONAL_FIRST',
                                               'INTERNATIONAL_PRIORITY'] or (
                        picking.partner_id.country_id.code == 'IN' and picking.picking_type_id.warehouse_id.partner_id.country_id.code == 'IN'):
                    company = order.company_id or picking.company_id or self.env.user.company_id
                    order_currency = picking.non_revenue_id.currency_id or picking.company_id.currency_id
                    commodity_country_of_manufacture = picking.picking_type_id.warehouse_id.partner_id.country_id.code
                    commodity_weight_units = self.fedex_weight_uom
                    total_commodities_amount = 0.0
                    comodities_packages = [] 
                    for operation in picking.move_line_ids:
                        commodity_amount = order_currency._convert(operation.product_id.list_price, order_currency,
                                                                   company, order.date_order or fields.Date.today())
                        total_commodities_amount += (commodity_amount * operation.qty_done)
                        
                        comodities_packages.append({
                            "unitPrice" : {
                                "currency": order_currency.name,
                                "amount": total_commodities_amount,
                                },
                            "numberOfPieces": 1,
                            "countryOfManufacture": commodity_country_of_manufacture,
                            "weight" : {
                                "units": commodity_weight_units,
                                "value": self.company_id.weight_convertion(self.fedex_weight_uom,
                                                                       operation.product_id.weight * operation.qty_done),
                                },
                            "description": operation.product_id.name,
                            "quantity": operation.qty_done,
                            "quantityUnits": 'EA' 
                            })
                        
                    ship_request['requestedShipment'].update({
                                "customsClearanceDetail": {
                                    "dutiesPayment": {
                                        "paymentType": "THIRD_PARTY" if order.fedex_bill_by_third_party_sale_order else "SENDER",
                                        },
                                    "customsValue": {
                                        "amount": total_commodities_amount,
                                        "currency": picking.non_revenue_id.currency_id.name or picking.company_id.currency_id.name,
                                        },
                                    "isDocumentOnly": True,
                                    "commodities": comodities_packages
                                    }
                                    
                                })
                    
                
                ship_request = self.add_fedex_package_non_revenue(ship_request, total_bulk_weight, 1,
                                                      number=1,
                                                      master_tracking_id=fedex_master_tracking_id, package_id=False, picking_obj=picking)
                if self.fedex_onerate:
                    if 'specialServiceTypes' in ship_request['requestedShipment']['specialServicesRequested']:
                        rate_request['requestedShipment']['specialServicesRequested']['specialServiceTypes'].append('FEDEX_ONE_RATE')
                
                _logger.info("Shipment Fedex API Request %s" % pprint.pformat(ship_request, indent=1))
                
                response_data = self.send_fedex_api_request(api_url, headers, ship_request)
                
                if response_data.status_code in [200, 201]:
                    response_data = response_data.json()
                    _logger.info("Shipment Response Data %s" % pprint.pformat(response_data, indent=1))
                    if response_data.get('output') and response_data.get('output').get('transactionShipments'):
                        for transaction_shipment in response_data.get('output').get('transactionShipments'):
                            carrier_tracking_ref = transaction_shipment.get('masterTrackingNumber')
                            tracking_number.append(carrier_tracking_ref)
                            for piece_respone in transaction_shipment.get('pieceResponses'):
                                for package_document in piece_respone.get('packageDocuments'):
                                    if package_document.get('contentType') == 'ACCEPTANCE_LABEL':
                                        label_type = 'Fedex_Return'
                                    else:
                                        label_type = 'Fedex'
                                    label_binary_data = binascii.a2b_base64(package_document.get('encodedLabel'))
                                    attachments.append(
                                        ('%s.%s.%s' % (label_type,
                                                       piece_respone.get('packageSequenceNumber') or carrier_tracking_ref,
                                                       self.fedex_shipping_label_file_type),
                                         label_binary_data))
                                    self.convert_fedex_zpl_to_pdf_label(label_type, piece_respone.get('packageSequenceNumber') or carrier_tracking_ref, 'pdf', package_document.get('encodedLabel'), pdf_attachments)
                                        
                                exact_price += piece_respone.get('baseRateAmount')
                            if shipper_address.country_id.code != recipient_address.country_id.code:
                                commercial_label = binascii.a2b_base64(
                                    response_data.get('output').get('transactionShipments')[0].get('shipmentDocuments')[
                                        0].get(
                                        'encodedLabel'))
                                if commercial_label:
                                    attachments.append(
                                        ('commercial invoice -%s.%s' % (
                                            carrier_tracking_ref,
                                            self.fedex_shipping_label_file_type),
                                         commercial_label))
                    else:
                        raise ValidationError(response_data)
                else:
                    if response_data.status_code != 204:
                        error_description = response_data.text
                        response_data = response_data.json()
                        if 'errors' in response_data:
                            error_description = response_data['errors']
                        raise ValidationError(str(error_description))
                                    
              
                
            if tracking_number:
                msg = _("Shipment sent to carrier %s for expedition with tracking number <b>%s</b>") % (picking.carrier_id.name, ",".join(tracking_number))
                picking.message_post(body=msg, attachments=pdf_attachments)
                picking.message_post(body=msg, attachments=attachments)
                
                if picking.non_revenue_id:
                    # picking.non_revenue_id.message_post(body=msg, attachments=attachments)
                    picking.non_revenue_id.message_post(body=msg, attachments=pdf_attachments)
                    picking.non_revenue_id.carrier_tracking_ref = ",".join(tracking_number)
            res = res + [{
                'exact_price': exact_price,
                'tracking_number':  ",".join(tracking_number)}
            ]
        return res
    
    
    def fedex_return_shipping_non_revenue(self, picking_obj):
        res = []
        fedex_master_tracking_id = False
        for picking in picking_obj:
            generate_return_label = False
            if picking.non_revenue_id:
                generate_return_label = [order_line1.product_id.id for order_line1 in picking.non_revenue_id.order_line1 if order_line1.default_shipping_type in ('fedex', 'fedex_ground') and not order_line1.override_fedex_flow and order_line1.generate_return_label]
            if generate_return_label:
#                 if not (picking.non_revenue_id and picking.non_revenue_id.fedex_bill_by_third_party_sale_order):
#                     picking.get_fedex_rate()
                exact_price = 0.0
                tracking_number = []
                attachments = []
                pdf_attachments = []
                move_products = []
                if picking.non_revenue_id:
                    move_products = [order_line1.product_id.id for order_line1 in picking.non_revenue_id.order_line1 if order_line1.default_shipping_type in ('fedex', 'fedex_ground') and not order_line1.override_fedex_flow and order_line1.generate_return_label]
                            
    #             total_bulk_weight = sum([(line.product_id.weight * line.product_uom_qty) for line in picking.move_ids_without_package if line.default_shipping_type in ('fedex', 'jetmail')]) or 0.0
                total_bulk_weight = 0.0
                for move_line in picking.move_line_ids:
                    if move_line.product_id and not move_line.result_package_id and  move_line.default_shipping_type in ('fedex', 'fedex_ground') and not move_line.override_fedex_flow and move_line.generate_return_label:
                        total_bulk_weight += move_line.product_uom_id._compute_quantity(move_line.qty_done, move_line.product_id.uom_id) * move_line.product_id.weight
                
    #             total_bulk_weight = self.company_id.weight_convertion(self.fedex_weight_uom, picking.weight_bulk)
                total_bulk_weight = self.company_id.weight_convertion(self.fedex_weight_uom, total_bulk_weight)
    #             package_count = len(picking.package_ids)
                packs = []
                for package in picking.package_ids:
                    package_level = self.env['stock.package_level'].search([('package_id', '=', package.id)])
                    for move_line in picking.move_line_ids:
                        if move_line.product_id.own_packing and package_level and package_level.pack_move_line_ids and move_line.id in package_level.pack_move_line_ids.ids and move_line.product_id.id in move_products:
                            packs.append(package.id)
                        elif package.id == move_line.result_package_id.id and move_line.default_shipping_type in ('fedex', 'fedex_ground') and move_line.product_id.id in move_products and not  move_line.override_fedex_flow and move_line.generate_return_label:
                            packs.append(package.id)
                
                package_count = 1
                if total_bulk_weight:
                    package_count += 1
                shipping_credential = self.company_id
    
                
                
                shipper_address = picking.non_revenue_id.source_address_id
                recipient_address = picking.non_revenue_id.dest_address_id
                
                if not recipient_address:
                    recipient_address = picking.picking_type_id.warehouse_id.partner_id
                    
                if not shipper_address:
                    shipper_address = picking.partner_id
                    
                
                api_url = "{0}/ship/v1/shipments".format(self.company_id.fedex_api_url)
                headers = {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'Authorization': 'Bearer {0}'.format(self.company_id.fedex_access_token)
                }
                ship_request = {
                    "mergeLabelDocOption": "LABELS_AND_DOCS",
                    "labelResponseOptions": "LABEL",
                    "shipAction": "CONFIRM",
                    "accountNumber": {"value": "{0}".format(self.company_id.fedex_account_number)},
                    "requestedShipment": {
                        # "shipper": self.get_fedex_address_dict(shipper_address),
                        # "recipient": self.get_fedex_address_dict(recipient_address),
                        "pickupType": self.fedex_pickup_type,
                        "serviceType": self.fedex_service_type,
                        "packagingType": self.fedex_default_product_packaging_id.shipper_package_code,
                        "rateRequestType": ["{0}".format(self.fedex_request_type)],
                        "shipTimestamp": datetime.now().strftime('%Y-%m-%d'),
                        # "totalWeight": ((total_weight) or 0),
                        # "preferredCurrency": order.currency_id.name,
                        "requestedPackageLineItems": [],
                        "specialServicesRequested": {},
                        # "rateRequestType": ["ACCOUNT", "LIST"],
                        
                        "labelSpecification": {
                            "labelFormatType": "COMMON2D",
                            "imageType": self.fedex_shipping_label_file_type,
                            "labelStockType": self.fedex_shipping_label_stock_type,
                            "labelPrintingOrientation": "BOTTOM_EDGE_OF_TEXT_FIRST",
                            "labelOrder": "SHIPPING_LABEL_FIRST"
                            },
                        "specialServicesRequested": {
                            "specialServiceTypes": ['RETURN_SHIPMENT'],
                            "returnShipmentDetail": {
                                "returnType": 'PRINT_RETURN_LABEL'
                                }
                            }
                        
                    }
                }
                
                package_type = self.fedex_default_product_packaging_id.shipper_package_code
                    
                self.prepare_shipment_request(shipping_credential, ship_request, shipper_address, recipient_address, package_type, picking.non_revenue_id, True)
            
                
                

                # ship_request.RequestedShipment.SpecialServicesRequested.SpecialServiceTypes = ['RETURN_SHIPMENT']
                # ship_request.RequestedShipment.SpecialServicesRequested.ReturnShipmentDetail.ReturnType = 'PRINT_RETURN_LABEL'
                
                for sequence, package in enumerate(picking.package_ids, start=1):
                    # A multiple-package shipment (MPS) consists of two or more packages shipped to the same recipient.
                    # The first package in the shipment request is considered the master package.

                    # Note: The maximum number of packages in an MPS request is 200.
                    if package.id in packs:
                        shipping_weight = 0.0
                        if package.override_weight:
                            shipping_weight = package.shipping_weight
                        else:
                           for move_line in picking.move_line_ids:
                                if package.id == move_line.result_package_id.id and move_line.default_shipping_type in ('fedex', 'fedex_ground') and move_line.product_id.id in move_products and not  move_line.override_fedex_flow and move_line.generate_return_label:
                                    shipping_weight += move_line.qty_done * move_line.product_id.weight
                        
                        package_weight = self.company_id.weight_convertion(self.fedex_weight_uom, shipping_weight)
                        if package_weight > 0.0:
                            
                            
                            
                            order = picking.non_revenue_id
                            if self.fedex_service_type in ['INTERNATIONAL_ECONOMY', 'INTERNATIONAL_FIRST', 'INTERNATIONAL_PRIORITY']:
                                company = order.company_id or picking.company_id or self.env.user.company_id
                                order_currency = picking.non_revenue_id.currency_id or picking.company_id.currency_id
                                commodity_country_of_manufacture = picking.picking_type_id.warehouse_id.partner_id.country_id.code
                                commodity_weight_units = self.fedex_weight_uom
                                total_commodities_amount = 0.0
                                for operation in picking.move_line_ids:
                                    if package.id == operation.result_package_id.id and operation.default_shipping_type in ('fedex', 'fedex_ground') and operation.product_id.id in move_products and not  operation.override_fedex_flow and operation.generate_return_label:
                                    
                                        commodity_amount = order_currency._convert(operation.product_id.list_price, order_currency,
                                                                                   company, order.date_order or fields.Date.today())
                                        total_commodities_amount += (commodity_amount * operation.qty_done)
                                        comodities_packages.append({
                                            "unitPrice" : {
                                                "currency": order_currency.name,
                                                "amount": total_commodities_amount,
                                                },
                                            "numberOfPieces": 1,
                                            "countryOfManufacture": commodity_country_of_manufacture,
                                            "weight" : {
                                                "units": commodity_weight_units,
                                                "value": self.company_id.weight_convertion(self.fedex_weight_uom,
                                                                                       operation.product_id.weight * operation.qty_done),
                                                },
                                            "description": operation.product_id.name,
                                            "quantity": operation.qty_done,
                                            "quantityUnits": 'EA' 
                                            })
                                        
                                ship_request['requestedShipment'].update({
                                            "customsClearanceDetail": {
                                                "dutiesPayment": {
                                                    "paymentType": "THIRD_PARTY" if order.fedex_bill_by_third_party_sale_order else "SENDER",
                                                    },
                                                "customsValue": {
                                                    "amount": total_commodities_amount,
                                                    "currency": picking.non_revenue_id.currency_id.name or picking.company_id.currency_id.name,
                                                    },
                                                "isDocumentOnly": True,
                                                "commodities": comodities_packages
                                                }
                                                
                                            })
                                
                            
                            if self.fedex_onerate:
                                if 'specialServiceTypes' in ship_request['requestedShipment']['specialServicesRequested']:
                                    rate_request['requestedShipment']['specialServicesRequested']['specialServiceTypes'].append('FEDEX_ONE_RATE')
                                        
                        
                            ship_request = self.add_fedex_package_non_revenue(ship_request, package_weight, 1, number=1,
                                                                  master_tracking_id=False,
                                                                  package_id=package, picking_obj=picking, return_pack=True)
                        
                            
                            
                            _logger.info("Return Shipment Fedex API Request %s" %  pprint.pformat(ship_request, indent=1))
                            response_data = self.send_fedex_api_request(api_url, headers, ship_request)
                            
                            if response_data.status_code in [200, 201]:
                                response_data = response_data.json()
                                _logger.info("Return Shipment Response Data %s" %  pprint.pformat(response_data, indent=1))
                                if response_data.get('output') and response_data.get('output').get('transactionShipments'):
                                    for transaction_shipment in response_data.get('output').get('transactionShipments'):
                                        carrier_tracking_ref = transaction_shipment.get('masterTrackingNumber')
                                        tracking_number.append(carrier_tracking_ref)
                                        for piece_respone in transaction_shipment.get('pieceResponses'):
                                            for package_document in piece_respone.get('packageDocuments'):
                                                if package_document.get('contentType') == 'ACCEPTANCE_LABEL':
                                                    label_type = 'Fedex_Return'
                                                else:
                                                    label_type = 'Fedex'
                                                label_binary_data = binascii.a2b_base64(package_document.get('encodedLabel'))
                                                attachments.append(
                                                    ('%s.%s.%s' % (label_type,
                                                                   piece_respone.get('packageSequenceNumber') or carrier_tracking_ref,
                                                                   self.fedex_shipping_label_file_type),
                                                     label_binary_data))
                                                self.convert_fedex_zpl_to_pdf_label(label_type, piece_respone.get('packageSequenceNumber') or carrier_tracking_ref, 'pdf', package_document.get('encodedLabel'), pdf_attachments)
    
                                            exact_price += piece_respone.get('baseRateAmount')
                                        if shipper_address.country_id.code != recipient_address.country_id.code:
                                            commercial_label = binascii.a2b_base64(
                                                response_data.get('output').get('transactionShipments')[0].get('shipmentDocuments')[
                                                    0].get(
                                                    'encodedLabel'))
                                            if commercial_label:
                                                attachments.append(
                                                    ('commercial invoice -%s.%s' % (
                                                        carrier_tracking_ref,
                                                        self.fedex_shipping_label_file_type),
                                                     commercial_label))
                                        
                                        package.custom_tracking_number = tracking_number
                                        if sequence == 1 and package_count > 1:
                                            fedex_master_tracking_id = carrier_tracking_ref
                                else:
                                    raise ValidationError(response_data)
                            else:
                                error_description = response_data.text
                                response_data = response_data.json()
                                if 'errors' in response_data:
                                    error_description = response_data['errors']
                                raise ValidationError(str(error_description))
                            
                            
                            
                           
                            
                if total_bulk_weight:
                    order = picking.non_revenue_id
                    if self.fedex_service_type in ['INTERNATIONAL_ECONOMY', 'INTERNATIONAL_FIRST',
                                                   'INTERNATIONAL_PRIORITY'] or (
                            picking.partner_id.country_id.code == 'IN' and picking.picking_type_id.warehouse_id.partner_id.country_id.code == 'IN'):
                        company = order.company_id or picking.company_id or self.env.user.company_id
                        order_currency = picking.non_revenue_id.currency_id or picking.company_id.currency_id
                        commodity_country_of_manufacture = picking.picking_type_id.warehouse_id.partner_id.country_id.code
                        commodity_weight_units = self.fedex_weight_uom
                        total_commodities_amount = 0.0
                        for operation in picking.move_line_ids:
                            commodity_amount = order_currency._convert(operation.product_id.list_price, order_currency,
                                                                       company, order.date_order or fields.Date.today())
                            total_commodities_amount += (commodity_amount * operation.qty_done)
                    
                    
                            comodities_packages.append({
                                    "unitPrice" : {
                                        "currency": order_currency.name,
                                        "amount": total_commodities_amount,
                                        },
                                    "numberOfPieces": 1,
                                    "countryOfManufacture": commodity_country_of_manufacture,
                                    "weight" : {
                                        "units": commodity_weight_units,
                                        "value": self.company_id.weight_convertion(self.fedex_weight_uom,
                                                                               operation.product_id.weight * operation.qty_done),
                                        },
                                    "description": operation.product_id.name,
                                    "quantity": operation.qty_done,
                                    "quantityUnits": 'EA' 
                                    })
                                
                        ship_request['requestedShipment'].update({
                                    "customsClearanceDetail": {
                                        "dutiesPayment": {
                                            "paymentType": "THIRD_PARTY" if order.fedex_bill_by_third_party_sale_order else "SENDER",
                                            },
                                        "customsValue": {
                                            "amount": total_commodities_amount,
                                            "currency": picking.non_revenue_id.currency_id.name or picking.company_id.currency_id.name,
                                            },
                                        "isDocumentOnly": True,
                                        "commodities": comodities_packages
                                        }
                                        
                                    })
                        
                    
                    ship_request = self.add_fedex_package_non_revenue(ship_request, total_bulk_weight, 1,
                                                          number=1,
                                                          master_tracking_id=fedex_master_tracking_id, package_id=False, picking_obj=picking, return_pack=True)
                    
                    
                    if self.fedex_onerate:
                        if 'specialServiceTypes' in ship_request['requestedShipment']['specialServicesRequested']:
                            rate_request['requestedShipment']['specialServicesRequested']['specialServiceTypes'].append('FEDEX_ONE_RATE')
                    
                    _logger.info("Return Shipment Fedex API Request %s" % pprint.pformat(ship_request, indent=1))
                    
                    response_data = self.send_fedex_api_request(api_url, headers, ship_request)
                    
                    if response_data.status_code in [200, 201]:
                        response_data = response_data.json()
                        _logger.info("Return Shipment Response Data %s" % pprint.pformat(response_data, indent=1))
                        if response_data.get('output') and response_data.get('output').get('transactionShipments'):
                            for transaction_shipment in response_data.get('output').get('transactionShipments'):
                                carrier_tracking_ref = transaction_shipment.get('masterTrackingNumber')
                                tracking_number.append(carrier_tracking_ref)
                                for piece_respone in transaction_shipment.get('pieceResponses'):
                                    for package_document in piece_respone.get('packageDocuments'):
                                        if package_document.get('contentType') == 'ACCEPTANCE_LABEL':
                                            label_type = 'Fedex_Return'
                                        else:
                                            label_type = 'Fedex'
                                        label_binary_data = binascii.a2b_base64(package_document.get('encodedLabel'))
                                        attachments.append(
                                            ('%s.%s.%s' % (label_type,
                                                           piece_respone.get('packageSequenceNumber') or carrier_tracking_ref,
                                                           self.fedex_shipping_label_file_type),
                                             label_binary_data))
                                        self.convert_fedex_zpl_to_pdf_label(label_type, piece_respone.get('packageSequenceNumber') or carrier_tracking_ref, 'pdf', package_document.get('encodedLabel'), pdf_attachments)
    
                                    exact_price += piece_respone.get('baseRateAmount')
                                if shipper_address.country_id.code != recipient_address.country_id.code:
                                    commercial_label = binascii.a2b_base64(
                                        response_data.get('output').get('transactionShipments')[0].get('shipmentDocuments')[
                                            0].get(
                                            'encodedLabel'))
                                    if commercial_label:
                                        attachments.append(
                                            ('commercial invoice -%s.%s' % (
                                                carrier_tracking_ref,
                                                self.fedex_shipping_label_file_type),
                                             commercial_label))
                        else:
                            raise ValidationError(response_data)
                    else:
                        error_description = response_data.text
                        response_data = response_data.json()
                        if 'errors' in response_data:
                            error_description = response_data['errors']
                        raise ValidationError(str(error_description))
                
                    
                    ship_request = self.add_fedex_package_non_revenue(ship_request, total_bulk_weight, 1,
                                                          number=1,
                                                          master_tracking_id=fedex_master_tracking_id, package_id=False, picking_obj=picking, return_pack=True)
                    if self.fedex_onerate:
                        ship_request.RequestedShipment.SpecialServicesRequested.SpecialServiceTypes = ['FEDEX_ONE_RATE']

                    
                    
                if tracking_number:
                    carrier_name = picking.carrier_id.name
                    if picking.non_revenue_id and picking.non_revenue_id.return_carrier_id:
                        carrier_name = picking.non_revenue_id.return_carrier_id.name
                    msg = _("Return Shipment sent to carrier %s for expedition with tracking number <b>%s</b>") % (carrier_name, ",".join(tracking_number))
    
                    picking.message_post(body=msg, attachments=attachments)
                    picking.message_post(body=msg, attachments=pdf_attachments)
                    if picking.non_revenue_id:
                        picking.non_revenue_id.message_post(body=msg, attachments=attachments)
                        picking.non_revenue_id.message_post(body=msg, attachments=pdf_attachments)
                        picking.non_revenue_id.return_carrier_tracking_ref = ",".join(tracking_number)
                
                res = res + [{
                    'exact_price': exact_price,
                    'tracking_number':  ",".join(tracking_number)}
                ]
            else:
                res = [{
                    'exact_price': 0.0,
                    'tracking_number':  ''}
                ]
        return res





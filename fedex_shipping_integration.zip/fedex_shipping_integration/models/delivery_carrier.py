import binascii
import time
import datetime
from datetime import datetime
from requests import request
import base64
import requests
import shutil
import json
import pprint
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

import logging
_logger = logging.getLogger("BTL Fedex API Request: ")


class DeliveryCarrier(models.Model):
    _inherit = "delivery.carrier"

    delivery_type = fields.Selection([('fedex_shipping_provider', 'Fedex'),('fixed','Fixed Price'),('base_on_rule','Based on Rules')])
    # fedex fields
    add_custom_margin = fields.Float(string="Margin", help="Add This Margin In Rate When Rate Comes From FedEx.",
                                     default=0.0)
    
    fedex_request_type = fields.Selection([('LIST', 'LIST'),
                                           ('INCENTIVE', 'INCENTIVE'),
                                           ('ACCOUNT', 'ACCOUNT'),
                                           ('PREFERRED', 'PREFERRED')],
                                          string="FedEx Request Type",
                                          default='ACCOUNT',
                                          help="LIST - Returns FedEx published list rates in addition to account-specific rates (if applicable). PREFERRED - Returns rates in the preferred currency specified in the element preferredCurrency. ACCOUNT - Returns account specific rates (Default). INCENTIVE - This is one-time discount for incentivising the customer. For more information, contact your FedEx representative.")
    
    fedex_service_type = fields.Selection(
        [('EUROPE_FIRST_INTERNATIONAL_PRIORITY', 'Europe First International Priority'),
         ('SMART_POST', 'Smart Post'),  # When Call the service given the error "Customer not eligible for service"
         ('FEDEX_GROUND', 'Fedex Ground'),  # When Call the service given the error "Customer not eligible for service"
         ('FEDEX_DISTANCE_DEFERRED', 'Fedex Distance Deferred'),
         # for domestic UK pickup  Error : Customer is eligible.
         ('FEDEX_NEXT_DAY_AFTERNOON', 'Fedex Next Day Afternoon'),  # for domestic UK pickup
         ('FEDEX_NEXT_DAY_EARLY_MORNING', 'Fedex Next Day Early Morning'),  # for domestic UK pickup
         ('FEDEX_NEXT_DAY_END_OF_DAY', 'Fedex Next Day End of Day'),  # for domestic UK pickup
         ('FEDEX_NEXT_DAY_FREIGHT', 'Fedex Next Day Freight'),  # for domestic UK pickup
         ('FEDEX_NEXT_DAY_MID_MORNING', 'Fedex Next Day Mid Morning'),  # for domestic UK pickup
         ('GROUND_HOME_DELIVERY', 'Ground Home Delivery'),
         # To Address Use: 33122 Florida Doral US. From Add use: 33122 Florida Doral US and Package type box is your_packaging.
         ('INTERNATIONAL_ECONOMY', 'International Economy'),
         # To Address Use: 33122 Florida Doral US. From Add use: 12277 Germany Berlin Penna.
         ('INTERNATIONAL_FIRST', 'International First'),
         # To Address Use: 33122 Florida Doral US. From Add use: 12277 Germany Berlin Penna.
         ('INTERNATIONAL_PRIORITY', 'International Priority'),
         # To Address Use: 33122 Florida Doral US. From Add use: 73377 "Le Bourget du Lac" France
         ('FIRST_OVERNIGHT', 'First Overnight'),  # for US
         ('PRIORITY_OVERNIGHT', 'Priority Overnight'),  # for US
         ('FEDEX_2_DAY', 'Fedex 2 Day'),  # for US Use: 33122 Florida Doral
         ('FEDEX_2_DAY_AM', 'Fedex 2 Day AM'),  # for US Use: 33122 Florida Doral
         ('FEDEX_EXPRESS_SAVER', 'Fedex Express Saver'),  # for US Use: 33122 Florida Doral
         ('STANDARD_OVERNIGHT', 'Standard Overnight')  # for US Use: 33122 Florida Doral
         ], string="Service Type", help="Shipping Services those are accepted by Fedex")
    
    
    fedex_pickup_type = fields.Selection([('CONTACT_FEDEX_TO_SCHEDULE', 'CONTACT_FEDEX_TO_SCHEDULE'),
                                          ('DROPOFF_AT_FEDEX_LOCATION', 'DROPOFF_AT_FEDEX_LOCATION'),
                                          ('USE_SCHEDULED_PICKUP', 'USE_SCHEDULED_PICKUP')],
                                         string="Pickup Type",
                                         default='USE_SCHEDULED_PICKUP',
                                         help="Identifies the method by which the package is to be tendered to FedEx.")
    
    fedex_droppoff_type = fields.Selection([('BUSINESS_SERVICE_CENTER', 'Business Service Center'),
                                            ('DROP_BOX', 'Drop Box'),
                                            ('REGULAR_PICKUP', 'Regular Pickup'),
                                            ('REQUEST_COURIER', 'Request Courier'),
                                            ('STATION', 'Station')],
                                           string="Drop-off Type",
                                           default='REGULAR_PICKUP',
                                           help="Identifies the method by which the package is to be tendered to FedEx.")
    fedex_default_product_packaging_id = fields.Many2one('stock.package.type', string="Default Package Type")
    fedex_weight_uom = fields.Selection([('LB', 'LB'),
                                         ('KG', 'KG')], default='LB', string="Weight UoM",
                                        help="Weight UoM of the Shipment")
    fedex_collection_type = fields.Selection([('ANY', 'ANY'),
                                              ('CASH', 'CASH'),
                                              ('COMPANY_CHECK', 'COMPANY_CHECK'),
                                              ('GUARANTEED_FUNDS', 'GUARANTEED_FUNDS'),
                                              ('PERSONAL_CHECK', 'PERSONAL_CHECK'),
                                              ], default='ANY', string="FedEx Collection Type",
                                             help="FedEx Collection Type")

    fedex_shipping_label_stock_type = fields.Selection([
        # These values display a thermal format label
        ('PAPER_4X6', 'Paper 4X6 '),
        ('PAPER_4X8', 'Paper 4X8'),
        ('PAPER_4X9', 'Paper 4X9'),

        # These values display a plain paper format shipping label
        ('PAPER_7X4.75', 'Paper 7X4.75'),
        ('PAPER_8.5X11_BOTTOM_HALF_LABEL', 'Paper 8.5X11 Bottom Half Label'),
        ('PAPER_8.5X11_TOP_HALF_LABEL', 'Paper 8.5X11 Top Half Label'),
        ('PAPER_LETTER', 'Paper Letter'),

        # These values for Stock Type label
        ('STOCK_4X6', 'Stock 4X6'),
        ('STOCK_4X6.75_LEADING_DOC_TAB', 'Stock 4X6.75 Leading Doc Tab'),
        ('STOCK_4X6.75_TRAILING_DOC_TAB', 'Stock 4X6.75 Trailing Doc Tab'),
        ('STOCK_4X8', 'Stock 4X8'),
        ('STOCK_4X9_LEADING_DOC_TAB', 'Stock 4X9 Leading Doc Tab'),
        ('STOCK_4X9_TRAILING_DOC_TAB', 'Stock 4X9 Trailing Doc Tab')], string="Label Stock Type",
        help="Specifies the type of paper (stock) on which a document will be printed.")
    fedex_shipping_label_file_type = fields.Selection([('DPL', 'DPL'),
                                                       ('EPL2', 'EPL2'),
                                                       ('PDF', 'PDF'),
                                                       ('PNG', 'PNG'),
                                                       ('ZPLII', 'ZPLII')], string="Label File Type")
    fedex_onerate = fields.Boolean("Want To Use FedEx OneRate Service?", default=False)
    fedex_third_party_account_number = fields.Char(copy=False, string='FexEx Third-Party Account Number',
                                                   help="Please Enter the Third Party account number")
    is_cod = fields.Boolean('COD')
    default_shipping_type = fields.Selection([
        ('fedex','Fedex Express'), 
        ('fedex_ground','Fedex Ground'), 
        ], string="Ship Type")

    
    
    
    def rate_shipment(self, order):
        ''' Compute the price of the order shipment

        :param order: record of sale.order
        :return dict: {'success': boolean,
                       'price': a float,
                       'error_message': a string containing an error message,
                       'warning_message': a string containing a warning message}
                       # TODO maybe the currency code?
        '''
        self.ensure_one()
        delivery_lines = order.mapped('order_line').filtered(lambda line: line.is_delivery == True)
        if not delivery_lines:
            return super(DeliveryCarrier, self).rate_shipment(order)

        if hasattr(self, '%s_rate_shipment' % self.delivery_type):
            try:
                fedex_excluded_state_ids = order.company_id.fedex_excluded_state_ids.ids

                if order.partner_shipping_id.state_id and order.partner_shipping_id.state_id.id not in fedex_excluded_state_ids:

                    res = getattr(self, '%s_rate_shipment' % self.delivery_type)(order)

                else:

                    res = {
                        'price': 0.0,
                        'success': False,
                        'warning_message': '',
                        'error_message': '',
                        }
            except Exception as error:

                res = {
                    'price': 0.0,
                    'success': False,
                    'warning_message': error,
                    'error_message': error,
                    }
            # apply margin on computed price
            if order.website_order and order.company_id.eshop_fedex_price == 'account':
                if 'account_price' in res:
                    res['price'] = res['account_price']
                else:
                    res['price'] = 0.0
                    
            res['price'] = float(res['price']) * (1.0 + (float(self.margin) / 100.0))
            # free when order is large enough
            if res['success'] and self.free_over and order._compute_amount_total_without_delivery() >= self.amount:
                res['warning_message'] = _('Info:\nThe shipping is free because the order amount exceeds %.2f.\n(The actual shipping cost is: %.2f)') % (self.amount, res['price'])
                res['price'] = 0.0
            return res

    # Fedex method code
    @api.onchange('fedex_default_product_packaging_id', 'fedex_service_type')
    def fedex_onchange_service_and_package(self):
        self.fedex_onerate = False

    def do_address_validation(self, address):
        """
        Call to get the validated address from Fedex or Classification : Can be used to determine the address classification to figure out if Residential fee should apply.
        values are return in classification : MIXED, RESIDENTIAL, UNKNOWN, BUSINESS
        use address validation services, client need to request fedex to enable this service for his account.
        By default, The service is disable and you will receive authentication failed.
        """
            
        api_url = "{0}/address/v1/addresses/resolve".format(self.company_id.fedex_api_url)
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': 'Bearer {0}'.format(self.company_id.fedex_access_token)
        }
        request_data = {
          "inEffectAsOfTimestamp": datetime.now().strftime('%Y-%m-%d'),
          "validateAddressControlParameters": {
            "includeResolutionTokens": true
          },
          "addressesToValidate": [
            {
              "address": {
                "streetLines": [
                  address.street,
                  address.street2
                ],
                "city": address.city,
                "stateOrProvinceCode": address.state_id.code,
                "postalCode": address.zip,
                "countryCode": address.country_id.code
              },
              "contact": {
                "personName": address.name,
                "parsedPersonName": {
                  "firstName": address.name,
                  "lastName": address.name,
                },
                "phoneNumber": address.phone,
                "emailAddress": address.email,
              },
              "clientReferenceId": "None"
            }
          ]
        }
        
        response_data = requests.request("POST", api_url, headers=headers, data=json.dumps(request_data))
        if response_data.status_code in [200, 201]:
            response_data = response_data.json()
            if response_data.get('output') and response_data.get('output').get('resolvedAddresses'):
                return response_data.get('output').get('resolvedAddresses')[0]
            else:
                return {}
        else:
            return {}
           

    def prepare_shipment_request(self, instance, rate_request, shipper, recipient, package_type, order, shipping=False):
        self.ensure_one()
        # If you wish to have transit data returned with your request you
        
        rate_request['requestedShipment'].update({
            "dropoffType": self.fedex_droppoff_type,
            "serviceType": self.fedex_service_type,  # Update to your desired service type
            "packagingType": package_type,  # Update to your desired packaging type
            "returnTransitAndCommit": True,
            # "shipTimestamp": datetime.now().replace(microsecond=0).isoformat(),
            })
        
        paymentType = "SENDER"
        if order and order.fedex_third_party_account_number_sale_order:
            paymentType = "THIRD_PARTY"
        
        
        rate_request['requestedShipment'].update({"shippingChargesPayment": {
                "paymentType": paymentType
                }})
        
        
        # Shipper's address
        residential = True
        if instance.use_address_validation_service:
            validated_address = self.do_address_validation(shipper)
            residential = validated_address.get('Classification') != 'BUSINESS'

        

        shipper_name =  shipper.name
        if  shipper_name and len(shipper_name) > 70:
             shipper_name =  shipper_name[:70]

        shipper_street =  shipper.street
        if  shipper_street and len( shipper_street) > 35:
             shipper_street =  shipper_street[:35]
        
        shipper_street2 =  shipper.street2
        if  shipper_street2 and len( shipper_street2) > 35:
             shipper_street2 =  shipper_street2[:35]
            
        
        shipper_phone =  shipper.phone
        if  shipper_phone:
            if len( shipper_phone) > 14:
                shipper_phone =  shipper_phone[:14]
            elif len(shipper_phone) < 10:
                shipper_phone = shipper_phone.zfill(10)
        
        
            
        rate_request['requestedShipment']['shipper'] = {
           
            "address": {
                "streetLines":  shipper_street and shipper_street2 and [shipper_street, shipper_street2] or [shipper_street],
                "city": shipper.city or None,
                "stateOrProvinceCode": shipper.state_id and shipper.state_id.code or None,
                "postalCode": shipper.zip,
                "countryCode": shipper.country_id.code,
                "residential": residential,  # Set to True if shipper's address is residential
                },
            }
            
        if shipping:
            rate_request['requestedShipment']['shipper'].update({
                "contact": {
                    # "personName": shipper_name,
                    "personName": shipper_name,
                    "phoneNumber": shipper_phone,
                    "emailAddress": shipper.email,
                    }
                })
        else:
            rate_request['requestedShipment']['shipper'].update({
                # "personName": shipper_name if not shipper.is_company else '',
                # "companyName": shipper_name if shipper.is_company else '',
                "personName": shipper_name if not shipper.is_company else '',
                "companyName": shipper_name if shipper.is_company else '',
                "phoneNumber": shipper_phone,
                })
        
        # Recipient address
        residential = False
        if self.fedex_service_type == 'GROUND_HOME_DELIVERY':
            residential = True
        if instance.use_address_validation_service:
            validated_address = self.do_address_validation(recipient)
            residential = validated_address.get('Classification') != 'BUSINESS'
            
        
        recipient_name = recipient.name
        if recipient_name and len(recipient_name) > 70:
            recipient_name = recipient_name[:70]

        recipient_street = recipient.street
        if recipient_street and len(recipient_street) > 35:
            recipient_street = recipient_street[:35]
        
        recipient_street2 = recipient.street2
        if recipient_street2 and len(recipient_street2) > 35:
            recipient_street2 = recipient_street2[:35]
            
        
        recipient_phone = recipient.phone
        if recipient_phone:
            if len(recipient_phone) > 14:
                recipient_phone = recipient_phone[:14]
            elif len(recipient_phone) < 10:
                recipient_phone = recipient_phone.zfill(10)
        if shipping:
            
            rate_request['requestedShipment']['recipients'] = [{
                "address": {
                    "streetLines": recipient_street and recipient_street2 and [recipient_street, recipient_street2] or [recipient_street],
                    "city": recipient.city or None,
                    "stateOrProvinceCode": recipient.state_id and recipient.state_id.code or None,
                    "postalCode": recipient.zip,
                    "countryCode": recipient.country_id.code,
                    "residential": residential,  # Set to True if shipper's address is residential
                    },
                "contact": {
                    # "personName": recipient_name,
                    "personName": recipient_name,
                    "phoneNumber": recipient_phone,
                    "emailAddress": recipient.email,
                    }
                }]
        else:
            
            rate_request['requestedShipment']['recipient'] = {
                # "personName": recipient_name if not recipient.is_company else '',
                # "companyName": recipient_name if recipient.is_company else '',
                "personName": recipient_name if not recipient.is_company else '',
                "companyName": recipient_name if recipient.is_company else '',
                "phoneNumber": recipient.phone,
                "address": {
                    "streetLines": recipient_street and recipient_street2 and [recipient_street, recipient_street2] or [recipient_street],
                    "city": recipient.city or None,
                    "stateOrProvinceCode": recipient.state_id and recipient.state_id.code or None,
                    "postalCode": recipient.zip,
                    "countryCode": recipient.country_id.code,
                    "residential": residential,  # Set to True if shipper's address is residential
                    },
                "contact": {
                    # "personName": recipient_name if not recipient.is_company else '',
                    "personName": recipient_name if not recipient.is_company else '',
                    "phoneNumber": recipient_phone,
                    "emailAddress": recipient.email,
                    }
                }
        return rate_request

    def manage_fedex_packages(self, rate_request, weight, number=1, order=False, product_id=False):
        Length = Width = Height = 0
        if product_id:
            if not product_id.own_packing:
                Length = int(product_id.depth)
                Width = int(product_id.width)
                Height = int(product_id.height)
            else:
                Length = int(product_id.fedex_package_id.package_type_id and product_id.fedex_package_id.package_type_id.packaging_length or 0)
                Width = int(product_id.fedex_package_id.package_type_id and product_id.fedex_package_id.package_type_id.width or 0)
                Height = int(product_id.fedex_package_id.package_type_id and product_id.fedex_package_id.package_type_id.height or 0)
                
        elif self.fedex_default_product_packaging_id.shipper_package_code == 'YOUR_PACKAGING':
            Length = self.fedex_default_product_packaging_id.packaging_length
            Width = self.fedex_default_product_packaging_id.width
            Height = self.fedex_default_product_packaging_id.height
            
            Length = 12
            Width = 8
            Height = 6
            
        Units = 'IN' if self.fedex_weight_uom == 'LB' else 'CM'
        PhysicalPackaging = 'BOX'
        GroupPackageCount = 1
        SequenceNumber = 0
        if number:
            SequenceNumber = number

            
        requestedPackageLineItems = {
            "weight": {
                "units": "{0}".format(self.fedex_weight_uom),
                "value": (weight)
                },
            "dimensions": {
                "length": Length,
                "width": Width,
                "height": Height,
                "units": Units,
                },
            "physicalPackaging": PhysicalPackaging,
            "groupPackageCount": GroupPackageCount,
            "sequenceNumber": SequenceNumber,
            }
        
        if order and order.signature_type:
            requestedPackageLineItems["packageSpecialServices"] = {
                "specialServiceTypes": [
                    "SIGNATURE_OPTION"
                    ],
                "signatureOptionType":  order.signature_type
                    
                }
        rate_request['requestedShipment']['requestedPackageLineItems'].append(requestedPackageLineItems)
        return rate_request
    
    def manage_fedex_packages_3dbin(self, rate_request, weight, number=1, order=False, pack=False):
        Length = Width = Height = 0
        if pack:
            Length = int(pack.d)
            Width = int(pack.w)
            Height = int(pack.h)
        Units = 'IN' if self.fedex_weight_uom == 'LB' else 'CM'
        PhysicalPackaging = 'BOX'
        GroupPackageCount = 1
        if number:
            SequenceNumber = number
            
            
        requestedPackageLineItems = {
            "weight": {
                "units": "{0}".format(self.fedex_weight_uom),
                "value": (weight)
                },
            "dimensions": {
                "length": Length,
                "width": Width,
                "height": Height,
                "units": Units,
                },
            "physicalPackaging": PhysicalPackaging,
            "groupPackageCount": GroupPackageCount,
            "sequenceNumber": SequenceNumber,
            }    
        
        
        if order and order.signature_type:
            requestedPackageLineItems["packageSpecialServices"] = {
                "specialServiceTypes": [
                    "SIGNATURE_OPTION"
                    ],
                "signatureOptionType":  order.signature_type
                    
                }
        
        rate_request['requestedShipment']['requestedPackageLineItems'].append(requestedPackageLineItems)
        return rate_request

    def add_fedex_package(self, ship_request, weight, package_count, number=1, master_tracking_id=False,
                          package_id=False, picking_obj=False, return_pack=False):
        package = {
            "weight": {
                "value": weight,
                "units": self.fedex_weight_uom
                }
            }
        
        Length = Width = Height = 0
        if picking_obj.sale_id and not picking_obj.sale_id.is_pack_calc_needed and package_id:
            Length = int(package_id.length) 
            Width = int(package_id.width)
            Height = int(package_id.height)
            Units = 'IN' if self.fedex_weight_uom == 'LB' else 'CM'
        
        elif self.fedex_default_product_packaging_id.shipper_package_code == 'YOUR_PACKAGING':
            Length = package_id and package_id.packaging_id.packaging_length if package_id and package_id.packaging_id.packaging_length else self.fedex_default_product_packaging_id.packaging_length
            Width = package_id and package_id.packaging_id.width if package_id and package_id.packaging_id.width else self.fedex_default_product_packaging_id.width
            Height = package_id and package_id.packaging_id.height if package_id and package_id.packaging_id.height else self.fedex_default_product_packaging_id.height
            Units = 'IN' if self.fedex_weight_uom == 'LB' else 'CM'
        PhysicalPackaging = 'BOX'
        
        package.update({
            "dimensions":{
                "length": Length,
                "width": Width,
                "height": Height,
                "units": Units,
                },
            "physicalPackaging": 'BOX',
            })
        package_level = False
        if package_id:
            package_level = self.env['stock.package_level'].search([('package_id', '=', package_id.id)], limit=1)
        else:
            package_level = self.env['stock.package_level']
        main_lot_number = []
        if picking_obj:
            for move_obj in picking_obj.move_ids_without_package:
                if move_obj.move_line_ids:
                    for line in move_obj.move_line_ids:
                        if line.lot_id and not line.lot_id.lot_id and line.default_shipping_type in ('fedex', 'fedex_ground') and not line.override_fedex_flow:
                            if package_id:
                                if line.result_package_id.id == package_id.id:
                                    main_lot_number.append(line.lot_id.name)
                                elif package_level and package_level.pack_move_line_ids and line.id in package_level.pack_move_line_ids.ids:
                                    main_lot_number.append(line.lot_id.name)
                            else:
                                main_lot_number.append(line.lot_id.name)
                                
        INVOICE_NUMBER = ''
        CUSTOMER_REFERENCE = ''
        if main_lot_number:
            half = len(main_lot_number)//2
            CUSTOMER_REFERENCE = main_lot_number[:half]
            INVOICE_NUMBER = main_lot_number[half:]
        
        
        if not return_pack:
            CustomerReference2_Value = "%s"%(",".join(INVOICE_NUMBER)[:29])
        else:
            CustomerReference2_Value = "%s"%("SO Return")
        package.update({
            "customerReferences": [{
                    "customerReferenceType": "P_O_NUMBER",  # customer reference 1,
                    "value": "%s"%(picking_obj.origin),
                    },
                {
                    "customerReferenceType": "INVOICE_NUMBER",  # customer reference 2,
                    "value": CustomerReference2_Value,
                    },
                {
                    "customerReferenceType": "CUSTOMER_REFERENCE",  # customer reference 3,
                    "value": "%s"%(",".join(CUSTOMER_REFERENCE)[:29]),
                    },
                {
                    "customerReferenceType": "DEPARTMENT_NUMBER",  # customer reference 4,
                    "value": "Sales",
                    },
            ]
            
            })

        if number:
            package.update({"sequenceNumber": number})
        
        if picking_obj.sale_id:
            if return_pack:
                if picking_obj.sale_id.return_signature_type:
                    package.update({"packageSpecialServices" : {
                        "specialServiceTypes": [
                            "SIGNATURE_OPTION"
                            ],
                        "signatureOptionType":  picking_obj.sale_id.return_signature_type
                        }})
                    
            else:
                if picking_obj.sale_id.signature_type:
                    
                    package.update({"packageSpecialServices" : {
                        "specialServiceTypes": [
                            "SIGNATURE_OPTION"
                            ],
                        "signatureOptionType":  picking_obj.sale_id.signature_type
                        }})
        
        
        ship_request["requestedShipment"].update({
            "requestedPackageLineItems": [package],
            "totalWeight": weight,
            "packageCount": package_count
            })
        # add saturday delivery service
        saturday_service = picking_obj and picking_obj.fedex_saturday_service or False
        if saturday_service:
            ship_request["requestedShipment"].update({
                "specialServicesRequested": {
                    "specialServiceTypes": ["SATURDAY_DELIVERY"]
                    }
                 })
            
        # add signatre
        if master_tracking_id:
            
            ship_request["requestedShipment"].update({
                "masterTrackingId": {
                    "trackingIdType": "FEDEX",
                    "trackingNumber": master_tracking_id
                    }
                 })
            
                    
        return ship_request
    
    
    
    
    
    def get_fedex_address_dict(self, address_id):
        return {
            "address": {
                "city": address_id.city or "",
                "stateOrProvinceCode": address_id.state_id and address_id.state_id.code or "",
                "postalCode": "{0}".format(address_id.zip or ""),
                "countryCode": address_id.country_id and address_id.country_id.code or ""
            }
        }


    def fedex_shipping_provider_rate_shipment(self, orders):
        res = []
        shipping_charge = 0.0
        delivery_date = ''
        PAYOR_ACCOUNT_PACKAGE = 0.0
        PAYOR_LIST_PACKAGE = 0.0
        index = 0
        jetmail_pack = 0
        for order in orders:
            if not order.is_pack_calc_needed:
                # order.calculate_package()
                if not order.pack_info_ids:
                    order.calculate_package()
                return self.fedex_shipping_provider_rate_shipment_3dbin(order)
            else:
                order_lines_without_weight = order.order_line.filtered(
                    lambda line_item: not line_item.product_id.type in ['service', 'digital'] and not line_item.product_id.weight and \
                    not line_item.is_delivery and line_item.default_shipping_type in ('fedex', 'jetmail', 'fedex_ground') and not line_item.override_fedex_flow)
                for order_line in order_lines_without_weight:
                    raise ValidationError("Please define weight in product : \n %s" % (order_line.product_id.name))

                # Shipper and Recipient Address
                shipper_address = order.warehouse_id.partner_id
                recipient_address = order.partner_shipping_id
                shipping_credential = self.company_id

                # check sender Address
                if not shipper_address.zip or not shipper_address.city or not shipper_address.country_id:
                    raise ValidationError("Please Define Proper Sender Address!")

                # check Receiver Address
                if not recipient_address.zip or not recipient_address.city or not recipient_address.country_id:
                    raise ValidationError("Please Define Proper Recipient Address!")


                max_weight = self.company_id.weight_convertion(self.fedex_weight_uom,
                                                               self.fedex_default_product_packaging_id.max_weight)



                api_url = "{0}/rate/v1/rates/quotes".format(self.company_id.fedex_api_url)
                headers = {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'Authorization': 'Bearer {0}'.format(self.company_id.fedex_access_token)
                }
                rate_request = {
                    "accountNumber": {"value": "{0}".format(self.company_id.fedex_account_number)},
                    "rateRequestControlParameters": {
                        "returnTransitTimes": True,
                        },
                    "requestedShipment": {
                        "shipper": self.get_fedex_address_dict(shipper_address),
                        "recipient": self.get_fedex_address_dict(recipient_address),
                        "pickupType": self.fedex_pickup_type,
                        "serviceType": self.fedex_service_type,
                        "packagingType": self.fedex_default_product_packaging_id.shipper_package_code,
                        "rateRequestType": ["{0}".format(self.fedex_request_type)],
                        "shipDateStamp": datetime.now().strftime('%Y-%m-%d'),
                        # "totalWeight": ((total_weight) or 0),
                        "preferredCurrency": order.currency_id.name,
                        "requestedPackageLineItems": [],
                        "rateRequestType": ["ACCOUNT", "LIST"],
                        "specialServicesRequested": {},
                        # "shipmentSpecialServices": {}
                    }
                }

                if not self.company_id.disable_future_day:
                    rate_request['requestedShipment']['shipDateStamp'] = order.future_day.strftime('%Y-%m-%d')

                package_type = self.fedex_default_product_packaging_id.shipper_package_code

                self.prepare_shipment_request(shipping_credential, rate_request, shipper_address, recipient_address, package_type, order, False)



                own_packing_order_line_ids = order.order_line.filtered(lambda o: o.default_shipping_type in ('fedex', 'fedex_ground') and o.product_id.own_packing and o.product_id.fedex_package_id and not o.override_fedex_flow)
                for own_line in own_packing_order_line_ids:
                    index += 1
                    line_weight = own_line.product_id.weight * own_line.product_uom_qty
                    line_weight = self.company_id.weight_convertion(self.fedex_weight_uom, line_weight)
                    self.manage_fedex_packages(rate_request, line_weight, index, order, own_line.product_id)

                own_packing_jetmail_line_ids = order.order_line.filtered(lambda o: o.default_shipping_type == 'jetmail' and o.product_id.own_packing and o.product_id.fedex_package_id and not o.override_fedex_flow)
                for own_line in own_packing_jetmail_line_ids:
                    index += 1
                    jetmail_pack += 1
                    line_weight = own_line.product_id.weight * own_line.product_uom_qty
                    line_weight = self.company_id.weight_convertion(self.fedex_weight_uom, line_weight)
                    self.manage_fedex_packages(rate_request, line_weight, index, order, own_line.product_id)


                if order.website_order:
                    own_packing_fedex_suggested_product_ids = []
                    own_packing_jetmail_suggested_product_ids = []
                    for line in order.order_line:
                        for suggest in line.product_id.suggested_product_ids:
                            if suggest.default_shipping_type in ('fedex', 'fedex_ground') and suggest.product_id.own_packing and suggest.product_id.fedex_package_id and not line.override_fedex_flow:
                                own_packing_fedex_suggested_product_ids.append(suggest)
                            if suggest.default_shipping_type == 'jetmail' and suggest.product_id.own_packing and suggest.product_id.fedex_package_id and not line.override_fedex_flow:
                                own_packing_jetmail_suggested_product_ids.append(suggest)
                    for own_line in own_packing_fedex_suggested_product_ids:
                        index += 1
                        line_weight = own_line.product_id.weight * own_line.quantity
                        line_weight = self.company_id.weight_convertion(self.fedex_weight_uom, line_weight)
                        self.manage_fedex_packages(rate_request, line_weight, index, order, own_line.product_id)


                    for own_line in own_packing_jetmail_suggested_product_ids:
                        index += 1
                        line_weight = own_line.product_id.weight * own_line.quantity
                        line_weight = self.company_id.weight_convertion(self.fedex_weight_uom, line_weight)
                        self.manage_fedex_packages(rate_request, line_weight, index, order, own_line.product_id)



                fedex_total_weight_not_packing = sum([(line.product_id.weight * line.product_uom_qty) for line in order.order_line if line.default_shipping_type in ('fedex', 'fedex_ground') and not line.product_id.own_packing and not line.override_fedex_flow]) or 0.0
                jetmail_total_weight_not_packing = sum([(line.product_id.weight * line.product_uom_qty) for line in order.order_line if line.default_shipping_type == 'jetmail' and not line.product_id.own_packing and not line.override_fedex_flow]) or 0.0

                if order.website_order:
                    for line in order.order_line:
                        for suggest in line.product_id.suggested_product_ids:
                            if suggest.default_shipping_type in ('fedex', 'fedex_ground') and not suggest.product_id.own_packing and not line.override_fedex_flow:
                                fedex_total_weight_not_packing += suggest.product_id.weight * suggest.quantity
                            if line.default_shipping_type == 'jetmail' and not line.product_id.own_packing and not line.override_fedex_flow:
                                jetmail_total_weight_not_packing += suggest.product_id.weight * suggest.quantity

                fedex_total_weight_not_packing = self.company_id.weight_convertion(self.fedex_weight_uom, fedex_total_weight_not_packing)
                if fedex_total_weight_not_packing > 0.0:
                    index += 1
                    self.manage_fedex_packages(rate_request, fedex_total_weight_not_packing, index, order)


                jetmail_total_weight_not_packing = self.company_id.weight_convertion(self.fedex_weight_uom, jetmail_total_weight_not_packing)
                if jetmail_total_weight_not_packing > 0.0:
                    index += 1
                    jetmail_pack += 1
                    self.manage_fedex_packages(rate_request, jetmail_total_weight_not_packing, index, order)



                rate_request['requestedShipment']['packageCount'] = index


                if self.fedex_onerate:

                    rate_request['requestedShipment']['specialServicesRequested'].update({'specialServiceTypes': ['FEDEX_ONE_RATE']})

                if self.is_cod and not order.fedex_third_party_account_number_sale_order:
                    if 'specialServiceTypes' in rate_request['requestedShipment']['specialServicesRequested']:
                        rate_request['requestedShipment']['specialServicesRequested']['specialServiceTypes'].append('COD')
                        rate_request['requestedShipment']['specialServicesRequested']['codDetail'] = {
                            "codCollectionAmount": {
                                "currency": order.company_id.currency_id.name,
                                "amount": order.amount_total,
                                },
                            "collectionType": {"value": "%s" % (self.fedex_collection_type)},
                            }

                    rate_request['requestedShipment']['specialServicesRequested']['codDetail']['codRecipient'] = {
                        "personName": shipper_address.name if not shipper_address.is_company else '',
                        "companyName": shipper_address.name if shipper_address.is_company else '',
                        "phoneNumber": shipper_address.phone,
                        "address": {
                            "streetLines":  shipper_address.street and shipper_address.street2 and [shipper_address.street, shipper_address.street2] or [shipper_address.street],
                            "city": shipper_address.city or None,
                            "stateOrProvinceCode": shipper_address.state_id and shipper_address.state_id.code or None,
                            "postalCode": shipper_address.zip,
                            "countryCode": shipper_address.country_id.code,
                            },

                        }

                if order.fedex_saturday_service:

                    if 'specialServiceTypes' in rate_request['requestedShipment']['specialServicesRequested']:
                        rate_request['requestedShipment']['specialServicesRequested']['specialServiceTypes'].append('SATURDAY_DELIVERY')



                rate_request['requestedShipment'].update({'rateRequestTypes': ['LIST', 'ACCOUNT']})

                _logger.info("Rate Fedex API Request: %s" % pprint.pformat(rate_request, indent=1))
                response_data = requests.request("POST", api_url, headers=headers, data=json.dumps(rate_request))
                _logger.info("Rate Fedex API Request Response: %s" % pprint.pformat(response_data.json(), indent=1))
                if response_data.status_code in [200, 201]:
                    response_data = response_data.json()

                    delivery_date = False
                    if response_data.get('output') and response_data.get('output').get('rateReplyDetails'):
                        for rateReplyDetail in response_data.get('output').get('rateReplyDetails'):
                            if self.fedex_service_type == rateReplyDetail.get("serviceType"):
                                for rate_info in rateReplyDetail.get('ratedShipmentDetails'):
                                    if rate_info['rateType'] == 'ACCOUNT':
                                        PAYOR_ACCOUNT_PACKAGE = float(rate_info['totalNetCharge'])
                                    elif rate_info['rateType'] == 'LIST':
                                        PAYOR_LIST_PACKAGE = float(rate_info['totalNetCharge'])
                                    else:
                                        shipping_charge = float(rate_info['totalNetCharge'])

                                    shipping_charge_currency = rate_info['currency']
                                    if order.currency_id.name != shipping_charge_currency:
                                        rate_currency = self.env['res.currency'].search([('name', '=', shipping_charge_currency)],
                                                                                        limit=1)
                                        if rate_currency:
                                            shipping_charge = rate_currency.compute(float(shipping_charge), order.currency_id)

                                            PAYOR_ACCOUNT_PACKAGE = rate_currency.compute(float(PAYOR_ACCOUNT_PACKAGE), order.currency_id)
                                            PAYOR_LIST_PACKAGE = rate_currency.compute(float(PAYOR_LIST_PACKAGE), order.currency_id)

                            if rateReplyDetail.get('operationalDetail', False) and rateReplyDetail['operationalDetail'].get('deliveryDate', False):
                                delivery_date = rateReplyDetail['operationalDetail'].get('deliveryDate', False)
                                delivery_date = datetime.strptime(delivery_date, "%Y-%m-%dT%H:%M:%S").strftime("%Y-%m-%d %H:%M:%S")

                    else:
                        return {'success': False, 'price': 0.0, 'error_message': response_data['error_description'],
                                'warning_message': False}
                else:
                    if response_data.status_code != 204:
                        error_message = response_data.json()['errors']
                        if error_message:
                            error_message = error_message[0]
                            if error_message and 'message' in error_message:
                                error_message = error_message['error_message']


                        return {'success': False, 'price': 0.0, 'error_message': error_message,
                            'warning_message': False}


            return {
                'success': True,
                'price': float(PAYOR_LIST_PACKAGE) + self.add_custom_margin,
                'account_price': float(PAYOR_ACCOUNT_PACKAGE) + self.add_custom_margin,
                'delivery_date': delivery_date,
                'package_count': index,
                'jetmail_pack': jetmail_pack,
                'error_message': False,
                'warning_message': False}

    def fedex_shipping_provider_rate_shipment_3dbin(self, orders, selected_rate_type='LIST'):
        PAYOR_ACCOUNT_PACKAGE = 0.0
        PAYOR_LIST_PACKAGE = 0.0
        jetmail_pack = 0
        delivery_date = False
        index = 0

        # Convert wizard value to API rate type
        selected_rate_type = 'ACCOUNT' if selected_rate_type == 'account' else 'LIST'

        account_base_charge = 0.0
        account_fuel_charge = 0.0
        account_signature_charge = 0.0
        account_tax = 0.0
        account_discount = 0.0
        account_total_shipping_cost = 0.0
        account_rural = 0.0
        account_oda = 0.0

        list_base_charge = 0.0
        list_fuel_charge = 0.0
        list_signature_charge = 0.0
        list_tax = 0.0
        list_discount = 0.0
        list_total_shipping_cost = 0.0
        list_rural = 0.0
        list_oda = 0.0

        for order in orders:

            shipper_address = order.warehouse_id.partner_id
            recipient_address = order.partner_shipping_id

            if not shipper_address.zip or not shipper_address.city or not shipper_address.country_id:
                raise ValidationError("Please Define Proper Sender Address!")

            if not recipient_address.zip or not recipient_address.city or not recipient_address.country_id:
                raise ValidationError("Please Define Proper Recipient Address!")

            api_url = "{0}/rate/v1/rates/quotes".format(self.company_id.fedex_api_url)
            headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'Authorization': f'Bearer {self.company_id.fedex_access_token}'
            }

            rate_request = {
                "accountNumber": {"value": self.company_id.fedex_account_number},
                "rateRequestControlParameters": {"returnTransitTimes": True},
                "requestedShipment": {
                    "shipper": self.get_fedex_address_dict(shipper_address),
                    "recipient": self.get_fedex_address_dict(recipient_address),
                    "pickupType": self.fedex_pickup_type,
                    "serviceType": self.fedex_service_type,
                    "packagingType": self.fedex_default_product_packaging_id.shipper_package_code,
                    "shipDateStamp": datetime.now().strftime('%Y-%m-%d'),
                    "preferredCurrency": order.currency_id.name,
                    "requestedPackageLineItems": [],
                    "rateRequestType": ["ACCOUNT", "LIST"],
                }
            }

            # Future day support
            if not self.company_id.disable_future_day:
                if not order.future_day:
                    order.future_day = datetime.now().date()
                rate_request['requestedShipment']['shipDateStamp'] = order.future_day.strftime('%Y-%m-%d')

            # Prepare shipment packages
            self.prepare_shipment_request(
                self.company_id, rate_request, shipper_address, recipient_address,
                self.fedex_default_product_packaging_id.shipper_package_code, order
            )

            for pack in order.pack_info_ids:
                index += 1
                self.manage_fedex_packages_3dbin(rate_request, pack.weight, index, order, pack)

            rate_request['requestedShipment']['packageCount'] = index
            rate_request['requestedShipment'].update({'rateRequestTypes': ['LIST', 'ACCOUNT']})

            _logger.info("FEDEX 3DBIN REQUEST ==== %s", pprint.pformat(rate_request, indent=1))

            response = requests.post(api_url, headers=headers, data=json.dumps(rate_request))
            _logger.info("FEDEX RESPONSE STATUS ==== %s", response.status_code)

            if response.status_code not in [200, 201]:
                return {
                    'success': False,
                    'price': 0.0,
                    'account_price': 0.0,
                    'error_message': response.text,
                    'warning_message': False
                }

            response = response.json()
            _logger.info("FEDEX 3DBIN RESPONSE ==== %s", pprint.pformat(response, indent=1))

            if response.get('output') and response.get('output').get('rateReplyDetails'):

                for rateReplyDetail in response.get('output').get('rateReplyDetails'):

                    if self.fedex_service_type != rateReplyDetail.get("serviceType"):
                        continue

                    for rate_info in rateReplyDetail.get('ratedShipmentDetails'):

                        rate_type = rate_info.get('rateType')

                        # Store net charges for display
                        if rate_type == 'ACCOUNT':
                            PAYOR_ACCOUNT_PACKAGE = float(rate_info.get('totalNetCharge', 0.0))
                        elif rate_type == 'LIST':
                            PAYOR_LIST_PACKAGE = float(rate_info.get('totalNetCharge', 0.0))

                        # Only process selected rate type for split
                        if rate_type == 'ACCOUNT':
                            account_base_charge = rate_info.get('totalBaseCharge', 0.0)
                            shipment_detail = rate_info.get('shipmentRateDetail', {})

                            account_discount = sum([fd.get('amount', 0.0) for fd in shipment_detail.get('freightDiscount', [])])
                            account_total_shipping_cost = rate_info.get('totalNetCharge', 0.0)


                            account_tax = sum(
                                [tax_line.get('amount', 0.0) for tax_line in shipment_detail.get('taxes', [])])
                            account_fuel_charge = sum(
                                [s.get('amount', 0.0) for s in shipment_detail.get('surCharges', []) if
                                 s.get('type') == 'FUEL'])
                            account_signature_charge = sum(
                                [s.get('amount', 0.0) for s in shipment_detail.get('surCharges', []) if
                                 s.get('type') == 'SIGNATURE_OPTION'])

                            account_rural = sum(
                                [s.get('amount', 0.0) for s in shipment_detail.get('surCharges', [])
                                 if s.get('type') in ['CANADIAN_DESTINATION', 'RURAL_AREA_DELIVERY']]
                            )

                            account_oda = sum([
                                s.get('amount', 0.0)
                                for s in shipment_detail.get('surCharges', [])
                                if s.get('type') == 'OUT_OF_DELIVERY_AREA'
                            ])

                        elif rate_type == 'LIST':
                            list_base_charge = rate_info.get('totalBaseCharge', 0.0)
                            shipment_detail = rate_info.get('shipmentRateDetail', {})

                            list_discount = sum([fd.get('amount', 0.0) for fd in shipment_detail.get('freightDiscount', [])])
                            list_total_shipping_cost = rate_info.get('totalNetCharge', 0.0)


                            list_tax = sum(
                                [tax_line.get('amount', 0.0) for tax_line in shipment_detail.get('taxes', [])])
                            list_fuel_charge = sum(
                                [s.get('amount', 0.0) for s in shipment_detail.get('surCharges', []) if
                                 s.get('type') == 'FUEL'])
                            list_signature_charge = sum(
                                [s.get('amount', 0.0) for s in shipment_detail.get('surCharges', []) if
                                 s.get('type') == 'SIGNATURE_OPTION'])

                            list_rural = sum(
                                [s.get('amount', 0.0) for s in shipment_detail.get('surCharges', [])
                                 if s.get('type') in ['CANADIAN_DESTINATION', 'RURAL_AREA_DELIVERY']]
                            )

                            list_oda = sum([
                                s.get('amount', 0.0)
                                for s in shipment_detail.get('surCharges', [])
                                if s.get('type') == 'OUT_OF_DELIVERY_AREA'
                            ])

                        # Delivery date
                        if rateReplyDetail.get('operationalDetail') and rateReplyDetail['operationalDetail'].get(
                                'deliveryDate'):
                            delivery_date = datetime.strptime(
                                rateReplyDetail['operationalDetail']['deliveryDate'], "%Y-%m-%dT%H:%M:%S"
                            ).strftime("%Y-%m-%d %H:%M:%S")


        return {
            'success': True,
            'price': float(PAYOR_LIST_PACKAGE),
            'account_price': float(PAYOR_ACCOUNT_PACKAGE),
            'delivery_date': delivery_date,
            'package_count': index,
            'jetmail_pack': jetmail_pack,

            # Split for  LIST
            'list_base_charge': list_base_charge,
            'list_fuel_charge': list_fuel_charge,
            'list_signature_charge': list_signature_charge,
            'list_tax': list_tax,
            'list_discount': list_discount,
            'list_total_shipping_cost': list_total_shipping_cost,
            'list_rural': list_rural,
            'list_oda': list_oda,

            # Split for ACCOUNT
            'account_base_charge': account_base_charge,
            'account_fuel_charge': account_fuel_charge,
            'account_signature_charge': account_signature_charge,
            'account_tax': account_tax,
            'account_discount': account_discount,
            'account_total_shipping_cost': account_total_shipping_cost,
            'account_rural': account_rural,
            'account_oda': account_oda,


            'error_message': False,
            'warning_message': False,
        }


    
    def send_fedex_api_request(self, api_url, headers, ship_request):
        response_data = requests.request("POST", api_url, headers=headers, data=json.dumps(ship_request))
        return response_data
        
    
    
    def convert_fedex_zpl_to_pdf_label(self, label_type, carrier_tracking_ref, fedex_shipping_label_file_type, label_binary_data, pdf_attachments):
        # adjust print density (8dpmm), label width (4 inches), label height (6 inches), and label index (0) as necessary
        
        if self.fedex_shipping_label_file_type == 'ZPLII':
            url = 'http://api.labelary.com/v1/printers/8dpmm/labels/4x6/0/'
            
            zpl = base64.b64decode(label_binary_data)
            files = {'file' : zpl}
            headers = {'Accept' : 'application/pdf'} 
            response = requests.post(url, headers=headers, files=files, stream=True)
            
            if response.status_code == 200:
                response.raw.decode_content = True
                label_binary_data = response.content
                
                pdf_attachments.append(
                    ('%s.%s.%s' % (label_type,
                                   carrier_tracking_ref,
                                   fedex_shipping_label_file_type),
                     label_binary_data))
            else:
                _logger.info("Error:  %s" % response.text)
        
    def fedex_shipping_provider_send_shipping(self, pickings):
        res = []
        fedex_master_tracking_id = False
        for picking in pickings:
#             if not (picking.sale_id and picking.sale_id.fedex_bill_by_third_party_sale_order):
#                 picking.get_fedex_rate()
            if picking.non_revenue_id:
                res = self.fedex_shipping_provider_send_shipping_non_revenue(picking)
            else:
                exact_price = 0.0
                tracking_number = []
                attachments = []
                pdf_attachments = []
                move_products = []
                if picking.sale_id:
                    move_products = [order_line.product_id.id for order_line in picking.sale_id.order_line if order_line.default_shipping_type in ('fedex', 'fedex_ground') and not order_line.override_fedex_flow]

    #             total_bulk_weight = sum([(line.product_id.weight * line.product_uom_qty) for line in picking.move_ids_without_package if line.default_shipping_type in ('fedex', 'jetmail')]) or 0.0
                total_bulk_weight = 0.0
                for move_line in picking.move_line_ids:
                    if move_line.product_id and not move_line.result_package_id and  move_line.default_shipping_type in ('fedex', 'fedex_ground') and not move_line.override_fedex_flow:
                        total_bulk_weight += move_line.product_uom_id._compute_quantity(move_line.qty_done, move_line.product_id.uom_id) * move_line.product_id.weight

    #             total_bulk_weight = self.company_id.weight_convertion(self.fedex_weight_uom, picking.weight_bulk)
                total_bulk_weight = self.company_id.weight_convertion(self.fedex_weight_uom, total_bulk_weight)
    #             package_count = len(picking.package_ids)
                packs = []
                for package in picking.package_ids:
                    package_level_ids = self.env['stock.package_level'].search([('package_id', '=', package.id)])
                    for move_line in picking.move_line_ids:
                        for package_level in package_level_ids:
                            if move_line.product_id.own_packing and package_level and package_level.pack_move_line_ids and move_line.id in package_level.pack_move_line_ids.ids and move_line.product_id.id in move_products:
                                packs.append(package.id)
                            elif package.id == move_line.result_package_id.id and move_line.default_shipping_type in ('fedex', 'fedex_ground') and move_line.product_id.id in move_products and not  move_line.override_fedex_flow:
                                packs.append(package.id)

                package_count = len(list(set(packs)))
                if total_bulk_weight:
                    package_count += 1

                shipping_credential = self.company_id

                if not self._context.get('use_fedex_return', False) and picking.picking_type_code == "incoming":
                    shipping_data = {
                        'exact_price': picking.carrier_price,
                        'tracking_number': picking.carrier_tracking_ref}
                    return [shipping_data]

                if picking.picking_type_code == "incoming":
                    shipper_address = picking.partner_id
                    recipient_address = picking.picking_type_id.warehouse_id.partner_id
                else:
                    recipient_address = picking.partner_id
                    shipper_address = picking.picking_type_id.warehouse_id.partner_id
                # try:


                api_url = "{0}/ship/v1/shipments".format(self.company_id.fedex_api_url)
                headers = {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'Authorization': 'Bearer {0}'.format(self.company_id.fedex_access_token)
                }
                ship_request = {
                    "mergeLabelDocOption": "LABELS_AND_DOCS",
                    "labelResponseOptions": "LABEL",
                    "shipAction": "CONFIRM",
                    "accountNumber": {"value": "{0}".format(self.company_id.fedex_account_number)},
                    "requestedShipment": {
                        # "shipper": self.get_fedex_address_dict(shipper_address),
                        # "recipient": self.get_fedex_address_dict(recipient_address),
                        "pickupType": self.fedex_pickup_type,
                        "serviceType": self.fedex_service_type,
                        "packagingType": self.fedex_default_product_packaging_id.shipper_package_code,
                        "rateRequestType": ["{0}".format(self.fedex_request_type)],
                        "shipTimestamp": datetime.now().strftime('%Y-%m-%d'),
                        # "totalWeight": ((total_weight) or 0),
                        # "preferredCurrency": order.currency_id.name,
                        "requestedPackageLineItems": [],
                        "specialServicesRequested": {},
                        # "rateRequestType": ["ACCOUNT", "LIST"],

                        "labelSpecification": {
                            "labelFormatType": "COMMON2D",
                            "imageType": self.fedex_shipping_label_file_type,
                            "labelStockType": self.fedex_shipping_label_stock_type,
                            "labelPrintingOrientation": "BOTTOM_EDGE_OF_TEXT_FIRST",
                            "labelOrder": "SHIPPING_LABEL_FIRST"
                            }

                    }
                }


                if picking.sale_id and picking.sale_id.future_day and not picking.sale_id.company_id.disable_future_day:
                    ship_request['requestedShipment'].update({
                        'shipDatestamp': picking.sale_id.future_day.strftime('%Y-%m-%d'),
                        })

                package_type = self.fedex_default_product_packaging_id.shipper_package_code

                self.prepare_shipment_request(shipping_credential, ship_request, shipper_address, recipient_address, package_type, picking.sale_id, True)

                sequence = 0
                for seq, package in enumerate(picking.package_ids, start=1):

                    # A multiple-package shipment (MPS) consists of two or more packages shipped to the same recipient.
                    # The first package in the shipment request is considered the master package.

                    # Note: The maximum number of packages in an MPS request is 200.
                    if package.id in packs:
                        sequence += 1
                        shipping_weight = 0.0
                        if package.override_weight:
                            shipping_weight = package.shipping_weight
                        else:
                           for move_line in picking.move_line_ids:
                                if package.id == move_line.result_package_id.id and move_line.default_shipping_type in ('fedex', 'fedex_ground') and move_line.product_id.id in move_products and not  move_line.override_fedex_flow:
                                    shipping_weight += move_line.qty_done * move_line.product_id.weight
                        package_weight = self.company_id.weight_convertion(self.fedex_weight_uom, shipping_weight)
                        if package_weight > 0.0:


                            if self.fedex_service_type in ['INTERNATIONAL_ECONOMY', 'INTERNATIONAL_FIRST','INTERNATIONAL_PRIORITY']:
                                order = picking.sale_id

                                company = order.company_id or picking.company_id or self.env.user.company_id
                                order_currency = picking.sale_id.currency_id or picking.company_id.currency_id
                                commodity_country_of_manufacture = picking.picking_type_id.warehouse_id.partner_id.country_id.code
                                commodity_weight_units = self.fedex_weight_uom
                                total_commodities_amount = 0.0
                                comodities_packages = []
                                for operation in picking.move_line_ids:
                                    if package.id == operation.result_package_id.id and operation.default_shipping_type in ('fedex', 'fedex_ground') and operation.product_id.id in move_products and not  operation.override_fedex_flow:
                                        commodity_amount = order_currency._convert(operation.product_id.list_price, order_currency,
                                                                                   company, order.date_order or fields.Date.today())
                                        total_commodities_amount += (commodity_amount * operation.qty_done)

                                        comodities_packages.append({
                                            "unitPrice" : {
                                                "currency": order_currency.name,
                                                "amount": commodity_amount,
                                                },
                                            "numberOfPieces": 1,
                                            "countryOfManufacture": commodity_country_of_manufacture,
                                            "weight" : {
                                                "units": commodity_weight_units,
                                                "value": self.company_id.weight_convertion(self.fedex_weight_uom,
                                                                                       operation.product_id.weight * operation.qty_done),
                                                },
                                            "description": operation.product_id.name,
                                            "quantity": operation.qty_done,
                                            "quantityUnits": 'EA'
                                            })


                                ship_request['requestedShipment'].update({
                                    "customsClearanceDetail": {
                                        "exportDetail": {
                                            "exportComplianceStatement":'30.37(f)'
                                            },
                                        "dutiesPayment": {
                                            "paymentType": "THIRD_PARTY" if order.fedex_bill_by_third_party_sale_order else "SENDER",
                                            },
                                        "customsValue": {
                                            "amount": total_commodities_amount,
                                            "currency": picking.sale_id.currency_id.name or picking.company_id.currency_id.name,
                                            },
                                        "isDocumentOnly": True,
                                        "commodities": comodities_packages
                                        }

                                    })

                            ship_request = self.add_fedex_package(ship_request, package_weight, package_count, number=sequence,
                                                                  master_tracking_id=fedex_master_tracking_id,
                                                                  package_id=package, picking_obj=picking)

                            if self.fedex_onerate:
                                if 'specialServiceTypes' in ship_request['requestedShipment']['specialServicesRequested']:
                                    rate_request['requestedShipment']['specialServicesRequested']['specialServiceTypes'].append('SATURDAY_DELIVERY')




                            _logger.info("Shipment Fedex API Request %s" % pprint.pformat(ship_request, indent=1))
                            response_data = self.send_fedex_api_request(api_url, headers, ship_request)

                            if response_data.status_code in [200, 201]:
                                response_data = response_data.json()
                                _logger.info("Shipment Response Data %s" % pprint.pformat(response_data, indent=1))
                                if response_data.get('output') and response_data.get('output').get('transactionShipments'):
                                    for transaction_shipment in response_data.get('output').get('transactionShipments'):
                                        carrier_tracking_ref = transaction_shipment.get('masterTrackingNumber')
                                        tracking_number.append(carrier_tracking_ref)
                                        for piece_respone in transaction_shipment.get('pieceResponses'):
                                            for package_document in piece_respone.get('packageDocuments'):
                                                if package_document.get('contentType') == 'ACCEPTANCE_LABEL':
                                                    label_type = 'Fedex_Return'
                                                else:
                                                    label_type = 'Fedex'
                                                label_binary_data = binascii.a2b_base64(package_document.get('encodedLabel'))


                                                if self.fedex_shipping_label_file_type == 'ZPLII':
                                                    self.convert_fedex_zpl_to_pdf_label(label_type, piece_respone.get('packageSequenceNumber') or carrier_tracking_ref, 'pdf', package_document.get('encodedLabel'), pdf_attachments)
                                                    attachments.append(
                                                    ('%s.%s.%s' % (label_type,
                                                                   piece_respone.get('packageSequenceNumber') or carrier_tracking_ref,
                                                                   self.fedex_shipping_label_file_type),
                                                     label_binary_data))
                                                else:
                                                    pdf_attachments.append(
                                                    ('%s.%s.%s' % (label_type,
                                                                   piece_respone.get('packageSequenceNumber') or carrier_tracking_ref,
                                                                   self.fedex_shipping_label_file_type),
                                                     label_binary_data))
                                            exact_price += piece_respone.get('baseRateAmount')
                                        if shipper_address.country_id.code != recipient_address.country_id.code:
                                            commercial_label = binascii.a2b_base64(
                                                response_data.get('output').get('transactionShipments')[0].get('shipmentDocuments')[
                                                    0].get(
                                                    'encodedLabel'))
                                            if commercial_label:
                                                attachments.append(
                                                    ('commercial invoice -%s.%s' % (
                                                        carrier_tracking_ref,
                                                        self.fedex_shipping_label_file_type),
                                                     commercial_label))

                                        package.custom_tracking_number = tracking_number
                                        if sequence == 1 and package_count > 1:
                                            fedex_master_tracking_id = carrier_tracking_ref
                                else:

                                    raise ValidationError(response_data)
                            else:
                                error_description = response_data.text
                                response_data = response_data.json()
                                if 'errors' in response_data:
                                    error_description = response_data['errors']

                                    # if error_description and isinstance(error_description, list) and 'message' in error_description[0]:
                                    #     error_description = error_description[0]['message']
                                raise ValidationError(str(error_description))


                if total_bulk_weight:
                    order = picking.sale_id
                    if self.fedex_service_type in ['INTERNATIONAL_ECONOMY', 'INTERNATIONAL_FIRST',
                                                   'INTERNATIONAL_PRIORITY'] or (
                            picking.partner_id.country_id.code == 'IN' and picking.picking_type_id.warehouse_id.partner_id.country_id.code == 'IN'):
                        company = order.company_id or picking.company_id or self.env.user.company_id
                        order_currency = picking.sale_id.currency_id or picking.company_id.currency_id
                        commodity_country_of_manufacture = picking.picking_type_id.warehouse_id.partner_id.country_id.code
                        commodity_weight_units = self.fedex_weight_uom
                        total_commodities_amount = 0.0
                        comodities_packages = []
                        for operation in picking.move_line_ids:
                            commodity_amount = order_currency._convert(operation.product_id.list_price, order_currency,
                                                                       company, order.date_order or fields.Date.today())
                            total_commodities_amount += (commodity_amount * operation.qty_done)

                            comodities_packages.append({
                                "unitPrice" : {
                                    "currency": order_currency.name,
                                    "amount": total_commodities_amount,
                                    },
                                "numberOfPieces": 1,
                                "countryOfManufacture": commodity_country_of_manufacture,
                                "weight" : {
                                    "units": commodity_weight_units,
                                    "value": self.company_id.weight_convertion(self.fedex_weight_uom,
                                                                           operation.product_id.weight * operation.qty_done),
                                    },
                                "description": operation.product_id.name,
                                "quantity": operation.qty_done,
                                "quantityUnits": 'EA'
                                })

                        ship_request['requestedShipment'].update({
                                    "customsClearanceDetail": {
                                        "dutiesPayment": {
                                            "paymentType": "THIRD_PARTY" if order.fedex_bill_by_third_party_sale_order else "SENDER",
                                            },
                                        "customsValue": {
                                            "amount": total_commodities_amount,
                                            "currency": picking.sale_id.currency_id.name or picking.company_id.currency_id.name,
                                            },
                                        "isDocumentOnly": True,
                                        "commodities": comodities_packages
                                        }

                                    })


                    ship_request = self.add_fedex_package(ship_request, total_bulk_weight, 1,
                                                          number=1,
                                                          master_tracking_id=fedex_master_tracking_id, package_id=False, picking_obj=picking)
                    if self.fedex_onerate:
                        if 'specialServiceTypes' in ship_request['requestedShipment']['specialServicesRequested']:
                            rate_request['requestedShipment']['specialServicesRequested']['specialServiceTypes'].append('FEDEX_ONE_RATE')

                    _logger.info("Shipment Fedex API Request %s" % pprint.pformat(ship_request, indent=1))

                    response_data = self.send_fedex_api_request(api_url, headers, ship_request)

                    if response_data.status_code in [200, 201]:
                        response_data = response_data.json()
                        _logger.info("Shipment Response Data %s" % pprint.pformat(response_data, indent=1))
                        if response_data.get('output') and response_data.get('output').get('transactionShipments'):
                            for transaction_shipment in response_data.get('output').get('transactionShipments'):
                                carrier_tracking_ref = transaction_shipment.get('masterTrackingNumber')
                                tracking_number.append(carrier_tracking_ref)
                                for piece_respone in transaction_shipment.get('pieceResponses'):
                                    for package_document in piece_respone.get('packageDocuments'):
                                        if package_document.get('contentType') == 'ACCEPTANCE_LABEL':
                                            label_type = 'Fedex_Return'
                                        else:
                                            label_type = 'Fedex'
                                        label_binary_data = binascii.a2b_base64(package_document.get('encodedLabel'))

                                        if self.fedex_shipping_label_file_type == 'ZPLII':
                                            self.convert_fedex_zpl_to_pdf_label(label_type, piece_respone.get('packageSequenceNumber') or carrier_tracking_ref, 'pdf', package_document.get('encodedLabel'), pdf_attachments)
                                            attachments.append(
                                            ('%s.%s.%s' % (label_type,
                                                           piece_respone.get('packageSequenceNumber') or carrier_tracking_ref,
                                                           self.fedex_shipping_label_file_type),
                                             label_binary_data))
                                        else:
                                            pdf_attachments.append(
                                            ('%s.%s.%s' % (label_type,
                                                           piece_respone.get('packageSequenceNumber') or carrier_tracking_ref,
                                                           self.fedex_shipping_label_file_type),
                                             label_binary_data))
                                    exact_price += piece_respone.get('baseRateAmount')
                                if shipper_address.country_id.code != recipient_address.country_id.code:
                                    commercial_label = binascii.a2b_base64(
                                        response_data.get('output').get('transactionShipments')[0].get('shipmentDocuments')[
                                            0].get(
                                            'encodedLabel'))
                                    if commercial_label:
                                        attachments.append(
                                            ('commercial invoice -%s.%s' % (
                                                carrier_tracking_ref,
                                                self.fedex_shipping_label_file_type),
                                             commercial_label))
                        else:
                            raise ValidationError(response_data)
                    else:
                        if response_data.status_code != 204:
                            error_description = response_data.text
                            response_data = response_data.json()
                            if 'errors' in response_data:
                                error_description = response_data['errors']
                            raise ValidationError(str(error_description))



                if tracking_number:
                    msg = _("Shipment sent to carrier %s for expedition with tracking number <b>%s</b>") % (picking.carrier_id.name, ",".join(tracking_number))
                    picking.message_post(body=msg, attachments=pdf_attachments)
                    picking.message_post(body=msg, attachments=attachments)

                    if picking.sale_id:
                        # picking.sale_id.message_post(body=msg, attachments=attachments)
                        picking.sale_id.message_post(body=msg, attachments=pdf_attachments)
                        picking.sale_id.carrier_tracking_ref = ",".join(tracking_number)
                res = res + [{
                    'exact_price': exact_price,
                    'tracking_number':  ",".join(tracking_number)}
                ]
        return res
    
    
    def fedex_return_shipping(self, picking_obj):
        res = []
        fedex_master_tracking_id = False
        for picking in picking_obj:
            generate_return_label = False
            if picking.sale_id:
                generate_return_label = [order_line.product_id.id for order_line in picking.sale_id.order_line if order_line.default_shipping_type in ('fedex', 'fedex_ground') and not order_line.override_fedex_flow and order_line.generate_return_label]
            if generate_return_label:
#                 if not (picking.sale_id and picking.sale_id.fedex_bill_by_third_party_sale_order):
#                     picking.get_fedex_rate()
                exact_price = 0.0
                tracking_number = []
                attachments = []
                pdf_attachments = []
                move_products = []
                if picking.sale_id:
                    move_products = [order_line.product_id.id for order_line in picking.sale_id.order_line if order_line.default_shipping_type in ('fedex', 'fedex_ground') and not order_line.override_fedex_flow and order_line.generate_return_label]
                            
    #             total_bulk_weight = sum([(line.product_id.weight * line.product_uom_qty) for line in picking.move_ids_without_package if line.default_shipping_type in ('fedex', 'jetmail')]) or 0.0
                total_bulk_weight = 0.0
                for move_line in picking.move_line_ids:
                    if move_line.product_id and not move_line.result_package_id and  move_line.default_shipping_type in ('fedex', 'fedex_ground') and not move_line.override_fedex_flow and move_line.generate_return_label:
                        total_bulk_weight += move_line.product_uom_id._compute_quantity(move_line.qty_done, move_line.product_id.uom_id) * move_line.product_id.weight
                
    #             total_bulk_weight = self.company_id.weight_convertion(self.fedex_weight_uom, picking.weight_bulk)
                total_bulk_weight = self.company_id.weight_convertion(self.fedex_weight_uom, total_bulk_weight)
    #             package_count = len(picking.package_ids)
                packs = []
                for package in picking.package_ids:
                    package_level = self.env['stock.package_level'].search([('package_id', '=', package.id)])
                    for move_line in picking.move_line_ids:
                        if move_line.product_id.own_packing and package_level and package_level.pack_move_line_ids and move_line.id in package_level.pack_move_line_ids.ids and move_line.product_id.id in move_products:
                            packs.append(package.id)
                        elif package.id == move_line.result_package_id.id and move_line.default_shipping_type in ('fedex', 'fedex_ground') and move_line.product_id.id in move_products and not  move_line.override_fedex_flow and move_line.generate_return_label:
                            packs.append(package.id)
                
                package_count = 1
                if total_bulk_weight:
                    package_count += 1
                shipping_credential = self.company_id
    
                
                
                shipper_address = picking.sale_id.source_address_id
                recipient_address = picking.sale_id.dest_address_id
                
                if not recipient_address:
                    recipient_address = picking.picking_type_id.warehouse_id.partner_id
                    
                if not shipper_address:
                    shipper_address = picking.partner_id
                    
                
                api_url = "{0}/ship/v1/shipments".format(self.company_id.fedex_api_url)
                headers = {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'Authorization': 'Bearer {0}'.format(self.company_id.fedex_access_token)
                }
                ship_request = {
                    "mergeLabelDocOption": "LABELS_AND_DOCS",
                    "labelResponseOptions": "LABEL",
                    "shipAction": "CONFIRM",
                    "accountNumber": {"value": "{0}".format(self.company_id.fedex_account_number)},
                    "requestedShipment": {
                        # "shipper": self.get_fedex_address_dict(shipper_address),
                        # "recipient": self.get_fedex_address_dict(recipient_address),
                        "pickupType": self.fedex_pickup_type,
                        "serviceType": self.fedex_service_type,
                        "packagingType": self.fedex_default_product_packaging_id.shipper_package_code,
                        "rateRequestType": ["{0}".format(self.fedex_request_type)],
                        "shipTimestamp": datetime.now().strftime('%Y-%m-%d'),
                        # "totalWeight": ((total_weight) or 0),
                        # "preferredCurrency": order.currency_id.name,
                        "requestedPackageLineItems": [],
                        "specialServicesRequested": {},
                        # "rateRequestType": ["ACCOUNT", "LIST"],
                        
                        "labelSpecification": {
                            "labelFormatType": "COMMON2D",
                            "imageType": self.fedex_shipping_label_file_type,
                            "labelStockType": self.fedex_shipping_label_stock_type,
                            "labelPrintingOrientation": "BOTTOM_EDGE_OF_TEXT_FIRST",
                            "labelOrder": "SHIPPING_LABEL_FIRST"
                            },
                        "specialServicesRequested": {
                            "specialServiceTypes": ['RETURN_SHIPMENT'],
                            "returnShipmentDetail": {
                                "returnType": 'PRINT_RETURN_LABEL'
                                }
                            }
                        
                    }
                }
                
                package_type = self.fedex_default_product_packaging_id.shipper_package_code
                    
                self.prepare_shipment_request(shipping_credential, ship_request, shipper_address, recipient_address, package_type, picking.sale_id, True)
            
                
                

                # ship_request.RequestedShipment.SpecialServicesRequested.SpecialServiceTypes = ['RETURN_SHIPMENT']
                # ship_request.RequestedShipment.SpecialServicesRequested.ReturnShipmentDetail.ReturnType = 'PRINT_RETURN_LABEL'
                
                for sequence, package in enumerate(picking.package_ids, start=1):
                    # A multiple-package shipment (MPS) consists of two or more packages shipped to the same recipient.
                    # The first package in the shipment request is considered the master package.

                    # Note: The maximum number of packages in an MPS request is 200.
                    if package.id in packs:
                        shipping_weight = 0.0
                        if package.override_weight:
                            shipping_weight = package.shipping_weight
                        else:
                           for move_line in picking.move_line_ids:
                                if package.id == move_line.result_package_id.id and move_line.default_shipping_type in ('fedex', 'fedex_ground') and move_line.product_id.id in move_products and not  move_line.override_fedex_flow and move_line.generate_return_label:
                                    shipping_weight += move_line.qty_done * move_line.product_id.weight
                        
                        package_weight = self.company_id.weight_convertion(self.fedex_weight_uom, shipping_weight)
                        if package_weight > 0.0:
                            
                            
                            
                            order = picking.sale_id
                            if self.fedex_service_type in ['INTERNATIONAL_ECONOMY', 'INTERNATIONAL_FIRST', 'INTERNATIONAL_PRIORITY']:
                                company = order.company_id or picking.company_id or self.env.user.company_id
                                order_currency = picking.sale_id.currency_id or picking.company_id.currency_id
                                commodity_country_of_manufacture = picking.picking_type_id.warehouse_id.partner_id.country_id.code
                                commodity_weight_units = self.fedex_weight_uom
                                total_commodities_amount = 0.0
                                for operation in picking.move_line_ids:
                                    if package.id == operation.result_package_id.id and operation.default_shipping_type in ('fedex', 'fedex_ground') and operation.product_id.id in move_products and not  operation.override_fedex_flow and operation.generate_return_label:
                                    
                                        commodity_amount = order_currency._convert(operation.product_id.list_price, order_currency,
                                                                                   company, order.date_order or fields.Date.today())
                                        total_commodities_amount += (commodity_amount * operation.qty_done)
                                        comodities_packages.append({
                                            "unitPrice" : {
                                                "currency": order_currency.name,
                                                "amount": total_commodities_amount,
                                                },
                                            "numberOfPieces": 1,
                                            "countryOfManufacture": commodity_country_of_manufacture,
                                            "weight" : {
                                                "units": commodity_weight_units,
                                                "value": self.company_id.weight_convertion(self.fedex_weight_uom,
                                                                                       operation.product_id.weight * operation.qty_done),
                                                },
                                            "description": operation.product_id.name,
                                            "quantity": operation.qty_done,
                                            "quantityUnits": 'EA' 
                                            })
                                        
                                ship_request['requestedShipment'].update({
                                            "customsClearanceDetail": {
                                                "dutiesPayment": {
                                                    "paymentType": "THIRD_PARTY" if order.fedex_bill_by_third_party_sale_order else "SENDER",
                                                    },
                                                "customsValue": {
                                                    "amount": total_commodities_amount,
                                                    "currency": picking.sale_id.currency_id.name or picking.company_id.currency_id.name,
                                                    },
                                                "isDocumentOnly": True,
                                                "commodities": comodities_packages
                                                }
                                                
                                            })
                                
                            
                            if self.fedex_onerate:
                                if 'specialServiceTypes' in ship_request['requestedShipment']['specialServicesRequested']:
                                    rate_request['requestedShipment']['specialServicesRequested']['specialServiceTypes'].append('FEDEX_ONE_RATE')
                                        
                        
                            ship_request = self.add_fedex_package(ship_request, package_weight, 1, number=1,
                                                                  master_tracking_id=False,
                                                                  package_id=package, picking_obj=picking, return_pack=True)
                        
                            
                            
                            _logger.info("Return Shipment Fedex API Request %s" %  pprint.pformat(ship_request, indent=1))
                            response_data = self.send_fedex_api_request(api_url, headers, ship_request)
                            
                            if response_data.status_code in [200, 201]:
                                response_data = response_data.json()
                                _logger.info("Return Shipment Response Data %s" %  pprint.pformat(response_data, indent=1))
                                if response_data.get('output') and response_data.get('output').get('transactionShipments'):
                                    for transaction_shipment in response_data.get('output').get('transactionShipments'):
                                        carrier_tracking_ref = transaction_shipment.get('masterTrackingNumber')
                                        tracking_number.append(carrier_tracking_ref)
                                        for piece_respone in transaction_shipment.get('pieceResponses'):
                                            for package_document in piece_respone.get('packageDocuments'):
                                                if package_document.get('contentType') == 'ACCEPTANCE_LABEL':
                                                    label_type = 'Fedex_Return'
                                                else:
                                                    label_type = 'Fedex'
                                                label_binary_data = binascii.a2b_base64(package_document.get('encodedLabel'))
                                                
                                                if self.fedex_shipping_label_file_type == 'ZPLII':
                                                    self.convert_fedex_zpl_to_pdf_label(label_type, piece_respone.get('packageSequenceNumber') or carrier_tracking_ref, 'pdf', package_document.get('encodedLabel'), pdf_attachments)
                                                    attachments.append(
                                                    ('%s.%s.%s' % (label_type,
                                                                   piece_respone.get('packageSequenceNumber') or carrier_tracking_ref,
                                                                   self.fedex_shipping_label_file_type),
                                                     label_binary_data))
                                                else:
                                                    pdf_attachments.append(
                                                    ('%s.%s.%s' % (label_type,
                                                                   piece_respone.get('packageSequenceNumber') or carrier_tracking_ref,
                                                                   self.fedex_shipping_label_file_type),
                                                     label_binary_data))
                                            exact_price += piece_respone.get('baseRateAmount')
                                        if shipper_address.country_id.code != recipient_address.country_id.code:
                                            commercial_label = binascii.a2b_base64(
                                                response_data.get('output').get('transactionShipments')[0].get('shipmentDocuments')[
                                                    0].get(
                                                    'encodedLabel'))
                                            if commercial_label:
                                                attachments.append(
                                                    ('commercial invoice -%s.%s' % (
                                                        carrier_tracking_ref,
                                                        self.fedex_shipping_label_file_type),
                                                     commercial_label))
                                        
                                        package.custom_tracking_number = tracking_number
                                        if sequence == 1 and package_count > 1:
                                            fedex_master_tracking_id = carrier_tracking_ref
                                else:
                                    raise ValidationError(response_data)
                            else:
                                error_description = response_data.text
                                response_data = response_data.json()
                                if 'errors' in response_data:
                                    error_description = response_data['errors']
                                raise ValidationError(str(error_description))
                            
                            
                            
                           
                            
                if total_bulk_weight:
                    order = picking.sale_id
                    if self.fedex_service_type in ['INTERNATIONAL_ECONOMY', 'INTERNATIONAL_FIRST',
                                                   'INTERNATIONAL_PRIORITY'] or (
                            picking.partner_id.country_id.code == 'IN' and picking.picking_type_id.warehouse_id.partner_id.country_id.code == 'IN'):
                        company = order.company_id or picking.company_id or self.env.user.company_id
                        order_currency = picking.sale_id.currency_id or picking.company_id.currency_id
                        commodity_country_of_manufacture = picking.picking_type_id.warehouse_id.partner_id.country_id.code
                        commodity_weight_units = self.fedex_weight_uom
                        total_commodities_amount = 0.0
                        for operation in picking.move_line_ids:
                            commodity_amount = order_currency._convert(operation.product_id.list_price, order_currency,
                                                                       company, order.date_order or fields.Date.today())
                            total_commodities_amount += (commodity_amount * operation.qty_done)
                    
                    
                            comodities_packages.append({
                                    "unitPrice" : {
                                        "currency": order_currency.name,
                                        "amount": total_commodities_amount,
                                        },
                                    "numberOfPieces": 1,
                                    "countryOfManufacture": commodity_country_of_manufacture,
                                    "weight" : {
                                        "units": commodity_weight_units,
                                        "value": self.company_id.weight_convertion(self.fedex_weight_uom,
                                                                               operation.product_id.weight * operation.qty_done),
                                        },
                                    "description": operation.product_id.name,
                                    "quantity": operation.qty_done,
                                    "quantityUnits": 'EA' 
                                    })
                                
                        ship_request['requestedShipment'].update({
                                    "customsClearanceDetail": {
                                        "dutiesPayment": {
                                            "paymentType": "THIRD_PARTY" if order.fedex_bill_by_third_party_sale_order else "SENDER",
                                            },
                                        "customsValue": {
                                            "amount": total_commodities_amount,
                                            "currency": picking.sale_id.currency_id.name or picking.company_id.currency_id.name,
                                            },
                                        "isDocumentOnly": True,
                                        "commodities": comodities_packages
                                        }
                                        
                                    })
                        
                    
                    ship_request = self.add_fedex_package(ship_request, total_bulk_weight, 1,
                                                          number=1,
                                                          master_tracking_id=fedex_master_tracking_id, package_id=False, picking_obj=picking, return_pack=True)
                    
                    
                    if self.fedex_onerate:
                        if 'specialServiceTypes' in ship_request['requestedShipment']['specialServicesRequested']:
                            rate_request['requestedShipment']['specialServicesRequested']['specialServiceTypes'].append('FEDEX_ONE_RATE')
                    
                    _logger.info("Return Shipment Fedex API Request %s" % pprint.pformat(ship_request, indent=1))
                    
                    response_data = self.send_fedex_api_request(api_url, headers, ship_request)
                    
                    if response_data.status_code in [200, 201]:
                        response_data = response_data.json()
                        _logger.info("Return Shipment Response Data %s" % pprint.pformat(response_data, indent=1))
                        if response_data.get('output') and response_data.get('output').get('transactionShipments'):
                            for transaction_shipment in response_data.get('output').get('transactionShipments'):
                                carrier_tracking_ref = transaction_shipment.get('masterTrackingNumber')
                                tracking_number.append(carrier_tracking_ref)
                                for piece_respone in transaction_shipment.get('pieceResponses'):
                                    for package_document in piece_respone.get('packageDocuments'):
                                        if package_document.get('contentType') == 'ACCEPTANCE_LABEL':
                                            label_type = 'Fedex_Return'
                                        else:
                                            label_type = 'Fedex'
                                        label_binary_data = binascii.a2b_base64(package_document.get('encodedLabel'))
                                        
                                        if self.fedex_shipping_label_file_type == 'ZPLII':
                                            self.convert_fedex_zpl_to_pdf_label(label_type, piece_respone.get('packageSequenceNumber') or carrier_tracking_ref, 'pdf', package_document.get('encodedLabel'), pdf_attachments)
                                            attachments.append(
                                            ('%s.%s.%s' % (label_type,
                                                           piece_respone.get('packageSequenceNumber') or carrier_tracking_ref,
                                                           self.fedex_shipping_label_file_type),
                                             label_binary_data))
                                        else:
                                            pdf_attachments.append(
                                            ('%s.%s.%s' % (label_type,
                                                           piece_respone.get('packageSequenceNumber') or carrier_tracking_ref,
                                                           self.fedex_shipping_label_file_type),
                                             label_binary_data))
                                    exact_price += piece_respone.get('baseRateAmount')
                                if shipper_address.country_id.code != recipient_address.country_id.code:
                                    commercial_label = binascii.a2b_base64(
                                        response_data.get('output').get('transactionShipments')[0].get('shipmentDocuments')[
                                            0].get(
                                            'encodedLabel'))
                                    if commercial_label:
                                        attachments.append(
                                            ('commercial invoice -%s.%s' % (
                                                carrier_tracking_ref,
                                                self.fedex_shipping_label_file_type),
                                             commercial_label))
                        else:
                            raise ValidationError(response_data)
                    else:
                        error_description = response_data.text
                        response_data = response_data.json()
                        if 'errors' in response_data:
                            error_description = response_data['errors']
                        raise ValidationError(str(error_description))
                
                    
                    ship_request = self.add_fedex_package(ship_request, total_bulk_weight, 1,
                                                          number=1,
                                                          master_tracking_id=fedex_master_tracking_id, package_id=False, picking_obj=picking, return_pack=True)
                    if self.fedex_onerate:
                        ship_request.RequestedShipment.SpecialServicesRequested.SpecialServiceTypes = ['FEDEX_ONE_RATE']

                    
                    
                if tracking_number:
                    carrier_name = picking.carrier_id.name
                    if picking.sale_id and picking.sale_id.return_carrier_id:
                        carrier_name = picking.sale_id.return_carrier_id.name
                    msg = _("Return Shipment sent to carrier %s for expedition with tracking number <b>%s</b>") % (carrier_name, ",".join(tracking_number))
    
                    picking.message_post(body=msg, attachments=attachments)
                    picking.message_post(body=msg, attachments=pdf_attachments)
                    if picking.sale_id:
                        # picking.sale_id.message_post(body=msg, attachments=attachments)
                        picking.sale_id.message_post(body=msg, attachments=pdf_attachments)
                        picking.sale_id.return_carrier_tracking_ref = ",".join(tracking_number)
                
                res = res + [{
                    'exact_price': exact_price,
                    'tracking_number':  ",".join(tracking_number)}
                ]
            else:
                res = [{
                    'exact_price': 0.0,
                    'tracking_number':  ''}
                ]
        return res

    
    
    def fedex_shipping_provider_get_tracking_link(self, pickings):
        res = ""
        for picking in pickings:
            link = "https://www.fedex.com/apps/fedextrack/?action=track&trackingnumber="
            res = '%s %s' % (link, picking.carrier_tracking_ref)
        return res


    def fedex_shipping_provider_cancel_shipment(self, picking):
        carrier_tracking_numbers = picking.carrier_tracking_ref.split(',')
        for carrier_tracking_ref in carrier_tracking_numbers:
            try:
                request_data = {"accountNumber": {
                    "value": self.company_id.fedex_account_number
                },
                    "senderCountryCode": "US",
                    "deletionControl": "DELETE_ALL_PACKAGES",
                    "trackingNumber": "%s" % (carrier_tracking_ref)
                }
                api_url = "{0}/ship/v1/shipments/cancel".format(self.company_id.fedex_api_url)
                headers = {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'Authorization': 'Bearer {0}'.format(self.company_id.fedex_access_token)
                }
                _logger.info("Cancel Fedex API Request %s" %  pprint.pformat(request_data, indent=1))
                response_data = requests.request("PUT", api_url, headers=headers, data=json.dumps(request_data))
                if response_data.status_code in [200, 201]:
                    response_data = response_data.json()
                    if response_data.get('output') and response_data.get('output').get('cancelledShipment'):
                        msg = _("Shipment with tracking number <b>%s</b> has been cancelled") % (carrier_tracking_ref)
                        picking.message_post(body=msg)
                        if picking.sale_id:
                            picking.sale_id.message_post(body=msg)
                        # return True
                    else:
                        if response_data.get('output') and response_data.get('output').get('message'):
                            response_data = response_data.get('output').get('message')
                        # raise ValidationError(response_data)
                else:
                    
                    error_description = response_data.text
                    response_data = response_data.json()
                    if 'errors' in response_data:
                        error_description = response_data['errors']
                    # raise ValidationError(str(error_description))
                    
            except Exception as e:
                pass
                # raise ValidationError(e)


from odoo import models, fields, api, _
import requests
from odoo.exceptions import ValidationError
import xml.etree.ElementTree as etree

import logging
_logger = logging.getLogger("BTL")



class ResCompany(models.Model):
    _inherit = 'res.company'

    fedex_track_api_url = fields.Char(string="FedEx Track API URL",default="https://apis-sandbox.fedex.com")
    fedex_track_client_id = fields.Char(string="FedEx Track Client ID")
    fedex_track_client_secret = fields.Char(string="FedEx Track Client Secret")
    fedex_track_account_number = fields.Char(copy=False, string='Account Number',
                                             help="The account number sent to you by Fedex after registering for Web Services.")
    fedex_track_access_token = fields.Char(string="FedEx Access Token", copy=False)


    #fedex
    use_fedex_shipping_provider = fields.Boolean(copy=False, string="Are You Use FedEx Shipping Provider.?",
                                                 help="If use fedEx shipping provider than value set TRUE.",
                                                 default=False)
    use_address_validation_service = fields.Boolean(copy=False, string="Use Address Validation Service",
                                                    help="Use Address Validation service to identify residential area or not.\nTo use address validation services, client need to request fedex to enable this service for his account.By default, The service is disable and you will receive authentication failed.")
    
    eshop_fedex_price = fields.Selection([('list', 'List Rate'), ('account', 'Account Rate')], 'Eshop Fedex Rate', default='list')
    
    two_step_picking_type_id = fields.Many2one('stock.picking.type', '2 Step Picking Type')
    disable_fedex = fields.Boolean('Disable FedEx Default Value') 
    disable_future_day = fields.Boolean('Disable Future Day') 
    fedex_excluded_state_ids = fields.Many2many('res.country.state', 'res_company_state_rel', 'company_id', 'state_id', 'Fedex Excluded States')
    fedex_shipping_warning = fields.Text('Fedex Shipping Warning')
    fedex_country_ids = fields.Many2many('res.country', 'res_company_country_rel', 'company_id', 'country_id', 'Fedex Supported Country')
    fedex_api_url = fields.Char(string="FedEx API URL", copy=False, default="https://apis-sandbox.fedex.com")
    fedex_client_id = fields.Char(string="FedEx Client ID", copy=False)
    fedex_client_secret = fields.Char(string="FedEx Client Secret", copy=False)
    fedex_account_number = fields.Char(copy=False, string='Account Number',
                                       help="The account number sent to you by Fedex after registering for Web Services.")
    fedex_access_token = fields.Char(string="FedEx Access Token", copy=False)
    fedex_express_specified_time = fields.Float('FedEx Express Pick Up')
    fedex_ground_specified_time = fields.Float('FedEx Ground Pick Up')

    # def auto_generate_fedex_access_token(self):
    #     for company_id in self.search([('use_fedex_shipping_provider', '!=', False)]):
    #         company_id.generate_fedex_access_token()

    def auto_generate_fedex_access_token(self):
        companies = self.search([('use_fedex_shipping_provider', '!=', False)])
        for company in companies:
            company._generate_fedex_token(
                company.fedex_api_url,
                company.fedex_client_id,
                company.fedex_client_secret,
                'fedex_access_token'
            )
            company._generate_fedex_token(
                company.fedex_track_api_url,
                company.fedex_track_client_id,
                company.fedex_track_client_secret,
                'fedex_track_access_token'
            )
    
    
    def _generate_fedex_token(self, base_url, client_id, client_secret, token_field):
        if not base_url:
            raise ValidationError("Please configure FedEx API URL")
    
        if not client_id or not client_secret:
            raise ValidationError("Please enter FedEx API credentials")
    
        api_url = f"{base_url}/oauth/token"
    
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }

        data = {
            'client_id': client_id,
            'client_secret': client_secret,
            'grant_type': 'client_credentials',
        }
    
        try:
            response = requests.post(api_url, headers=headers, data=data, timeout=30)
    
            if response.status_code not in (200, 201):
                raise ValidationError(response.text)
    
            result = response.json()
    
            access_token = result.get('access_token')
            if not access_token:
                raise ValidationError(result)
    
            self[token_field] = access_token
    
        except requests.exceptions.RequestException as e:
            raise ValidationError(f"FedEx API Connection Error: {str(e)}")
    
    
    def generate_fedex_access_token(self):
        self._generate_fedex_token(
            self.fedex_api_url,
            self.fedex_client_id,
            self.fedex_client_secret,
            'fedex_access_token'
        )
        return self._rainbow_message()
    
    
    def generate_fedex_tracking_access_token(self):
        self._generate_fedex_token(
            self.fedex_track_api_url,
            self.fedex_track_client_id,
            self.fedex_track_client_secret,
            'fedex_track_access_token'
        )
        return self._rainbow_message()
    
    
    def _rainbow_message(self):
        return {
            'effect': {
                'fadeout': 'slow',
                'message': "Yeah! Token has been retrieved.",
                'img_url': '/web/static/img/smile.svg',
                'type': 'rainbow_man',
            }
        }
    

        

    def weight_convertion(self, weight_unit, weight):
        uom_id = self.env['product.template']._get_weight_uom_id_from_ir_config_parameter()
        pound_for_kg = 2.20462
        ounce_for_lb = 16
        ounce_for_kg = 35.274
        if uom_id.name in ['lb', 'lbs', 'LB', 'LBS'] and weight_unit in ["LB", "LBS"]:
            return round(weight, 3)
        elif uom_id.name in ['kg', 'KG'] and weight_unit in ["LB", "LBS"]:
            return round(weight * pound_for_kg, 3)
        elif uom_id.name in ['lb', 'lbs', 'LB', 'LBS'] and weight_unit in ["OZ", "OZS"]:
            return round(weight * ounce_for_lb, 3)
        elif uom_id.name in ['kg', 'KG'] and weight_unit in ["OZ", "OZS"]:
            return round(weight * ounce_for_kg, 3)
        else:
            return round(weight, 3)


class ResPartner(models.Model):
    _inherit = 'res.partner'
    
    shipping_select = fields.Boolean('Select')
    
    # street = fields.Char(size=35)
    # street2 = fields.Char(size=35)
    # phone = fields.Char(size=15)

    
    
    # @api.model
    # def create(self, vals):
    #     partner = super(ResPartner, self).create(vals)
    #     street = partner.street
    #     if partner.street2:
    #         street += partner.street2
    #     if street and len(street) > 35:
    #         raise ValidationError("Street lines(Street, Street2) too long.Please limit to 35 characters")
    #
    #     return partner
    #
    # def write(self, vals):
    #     res = super(ResPartner, self).write(vals)
    #     for partner in self:
    #         street = partner.street
    #         if partner.street2:
    #             street += partner.street2
    #         if street and len(street) > 35:
    #             raise ValidationError("Street lines(Street, Street2) too long.Please limit to 35 characters")
    #
    #     return res


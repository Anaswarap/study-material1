import requests
import base64
import json
import xml.etree.ElementTree as etree
import logging
import pytz

import http.client
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime
import datetime as dt
from datetime import timedelta


from odoo.exceptions import ValidationError, UserError
from odoo import models, fields, api, _


_logger = logging.getLogger(__name__)



class NonRevenue(models.Model):
    _inherit = "ship.nonrevenue"

    def _get_disable_fedex(self):
        return self.env.user.company_id.disable_fedex

    fedex_third_party_account_number_sale_order = fields.Char(copy=False, string='FexEx Third-Party Account Number',
                                                              help="Please Enter the Third Party account number ")
    fedex_bill_by_third_party_sale_order = fields.Boolean(string="FedEx Third Party Payment", copy=False, default=False,
                                                          help="when this fields is true,then we can visible fedex_third party account number")

    fedex_saturday_service = fields.Boolean(string='FedEx Saturday Service', copy=False)
    signature_type = fields.Selection([('DIRECT', 'DIRECT'), ('ADULT', 'ADULT')],
                                      string="Signature Type", help="", default="DIRECT", copy=False, tracking=True)
    fedex_attribute_changed = fields.Boolean(string='FedEx Attribute', copy=False, store=True,
                                             compute='_fedex_attribute_changed', inverse='_set__fedex_attribute_changed')
    carrier_tracking_ref = fields.Char(string='Tracking Reference', copy=False)
    return_carrier_tracking_ref = fields.Char(string='Return Tracking Reference', copy=False)
    fedex_line = fields.Boolean(string='FedEx Line', copy=False, store=True, compute='_fedex_line', inverse='_set__fedex_line')
    return_carrier_id = fields.Many2one('delivery.carrier', string='Return Carrier', tracking=True)
    source_address_id = fields.Many2one('res.partner', 'Return Source Location', tracking=True)
    dest_address_id = fields.Many2one('res.partner', 'Return Destination Location', tracking=True)
    return_signature_type = fields.Selection([('DIRECT', 'DIRECT'), ('ADULT', 'ADULT')],
                                             string="Return Signature Type", help="", default="", tracking=True)
    carrier_id = fields.Many2one('delivery.carrier', string="Delivery Method",
                                 help="Fill this field if you plan to invoice the shipping based on picking.", tracking=True)
    disable_fedex = fields.Boolean('Disable FedEx', default=False)
    delivery_price = fields.Float(string='Estimated Delivery Price', readonly=True, copy=False)
    future_day = fields.Datetime('Future Day', copy=False,
                             default=fields.Datetime.now)

    pack_info_ids = fields.One2many('response.bin', 'non_revenue_order_id', 'Packages')
    is_pack_calc_needed = fields.Boolean(string='No Pack Calculation', help='Check if Pack calculation not needed.')
    
    
    @api.onchange('future_day')
    def _onchange_future_day(self):
        for order in self:
            future_day = datetime.now() + timedelta(days=10)
            if order.future_day and order.future_day > future_day:
                order.future_day = False
                return {"warning": {"title": _("Choose Future Date"), "message": "FedEx allows scheduling shipments up to 10 days from the actual ship date. Please choose a future date within that range."}}

    
    
    def create_so(self, revenue_lines):
        res = super(NonRevenue, self).create_so(revenue_lines)
        if res:
            for order in self:
                res.update({
                    'fedex_third_party_account_number_sale_order': order.fedex_third_party_account_number_sale_order,
                    'fedex_bill_by_third_party_sale_order': order.fedex_bill_by_third_party_sale_order,
                    'fedex_saturday_service': order.fedex_saturday_service,
                    'signature_type': order.signature_type,
                    'fedex_attribute_changed': order.fedex_attribute_changed,
                    'carrier_tracking_ref': order.carrier_tracking_ref,
                    'return_carrier_tracking_ref': order.return_carrier_tracking_ref,
                    'fedex_line': order.fedex_line,
                    'return_carrier_id': order.return_carrier_id and order.return_carrier_id.id or False,
                    'source_address_id': order.source_address_id and order.source_address_id.id or False,
                    'dest_address_id': order.dest_address_id and order.dest_address_id.id or False,
                    'return_signature_type': order.return_signature_type,
                    'carrier_id': order.carrier_id and order.carrier_id.id or False,
                    'disable_fedex': order.disable_fedex,
                    'future_day': order.future_day,

                })

                for line in order.order_line1:
                    if line.sale_line_id:
                        line.sale_line_id.update({
                            'fedex_attribute_changed': line.fedex_attribute_changed,
                            'override_fedex_flow': line.override_fedex_flow,
                            'generate_return_label': line.generate_return_label,
                            'return_address_id': line.return_address_id and line.return_address_id or False,
                            'default_shipping_type': line.default_shipping_type,
                            'is_delivery': line.is_delivery,
                        })
        return res

    def _remove_delivery_line(self):
        self.env['ship.revenue.line'].search([('order_id', 'in', self.ids), ('is_delivery', '=', True)]).unlink()

    def _create_delivery_line(self, carrier, price_unit):
        revenue_line = self.env['ship.revenue.line']
        if self.partner_id:
            # set delivery detail in the customer language
            carrier = carrier.with_context(lang=self.partner_id.lang)

        # Apply fiscal position
        taxes = carrier.product_id.taxes_id.filtered(lambda t: t.company_id.id == self.company_id.id)
        taxes_ids = taxes.ids

        # Create the sales order line
        carrier_with_partner_lang = carrier.with_context(lang=self.partner_id.lang)
        if carrier_with_partner_lang.product_id.description_sale:
            so_description = '%s: %s' % (carrier_with_partner_lang.name, carrier_with_partner_lang.product_id.description_sale)
        else:
            so_description = carrier_with_partner_lang.name
        values = {
            'order_id': self.id,
            'name': so_description,
            'product_uom_qty': 1,
            'product_uom': carrier.product_id.uom_id.id,
            'product_id': carrier.product_id.id,
            'price_unit': price_unit,
            # 'tax_id': [(6, 0, taxes_ids)],
            'is_delivery': True,
        }
        if self.order_line1:
            values['sequence'] = self.order_line1[-1].sequence + 1
        sol = revenue_line.sudo().create(values)
        return sol

    def order_disable_fedex(self, vals):
        if 'disable_fedex' in vals:
            if vals['disable_fedex']:
                for line in self.order_line1:
                    # line.default_shipping_type = ''
                    line.generate_return_label = False
                    line.override_fedex_flow = True
                    # self.carrier_id = False
                    # is_delivery_objs = self.env['sale.order.line'].search([('order_id', '=', self.id), ('is_delivery', '=', True)])
                    # if is_delivery_objs:
                    #     is_delivery_objs.unlink()
                self.fedex_attribute_changed = False

            else:
                for line in self.order_line1:
                    if line.product_id:
                        if line.product_id.fedex_return_label:
                            line.generate_return_label = True
                        if line.product_id.default_shipping_type:
                            line.default_shipping_type = line.product_id.default_shipping_type
                        line.override_fedex_flow = False
                if self.fedex_line:
                    self.fedex_attribute_changed = True

    @api.model
    def create(self, vals):
        order = super(NonRevenue, self).create(vals)
        order.order_disable_fedex(vals)
        return order

    def write(self, vals):
        res = super(NonRevenue, self).write(vals)
        self.order_disable_fedex(vals)
        return res

    @api.depends('order_line1', 'order_line1.fedex_attribute_changed')
    def _fedex_attribute_changed(self):
        for order in self:
            changed = order.mapped('order_line1').filtered(lambda line: line.fedex_attribute_changed == True and
                                                                        line.default_shipping_type in ('fedex', 'jetmail', 'fedex_ground'))
            fedex_line = order.mapped('order_line1').filtered(lambda line: line.default_shipping_type in ('fedex', 'jetmail', 'fedex_ground'))
            delivery_line = order.mapped('order_line1').filtered(lambda line: line.is_delivery == True)
            if changed or (fedex_line and not delivery_line) and not order.disable_fedex:
                order.fedex_attribute_changed = True
            else:
                order.fedex_attribute_changed = False

    def _set__fedex_attribute_changed(self):
        for order in self:
            pass

    @api.depends('order_line1', 'order_line1.fedex_attribute_changed')
    def _fedex_line(self):
        for order in self:
            fedex_line = order.mapped('order_line1').filtered(lambda line: line.default_shipping_type in ('fedex', 'jetmail', 'fedex_ground'))
            if fedex_line:
                order.fedex_line = True
            else:
                order.fedex_line = False

    def _set__fedex_line(self):
        for order in self:
            pass

    @api.onchange('disable_fedex')
    def _onchange_disable_fedex(self):
        for order in self:
            if order.disable_fedex:
                for line in order.order_line1:
                    # line.default_shipping_type = ''
                    line.generate_return_label = False
            else:
                for line in order.order_line1:
                    if line.product_id:
                        if line.product_id.fedex_return_label:
                            line.generate_return_label = True
                        if line.product_id.default_shipping_type:
                            line.default_shipping_type = line.product_id.default_shipping_type

    @api.onchange('partner_shipping_id')
    def _onchange_fedex_attribute_changed(self):
        for order in self:
            order.fedex_attribute_changed = True
            order.source_address_id = order.partner_shipping_id
            order.dest_address_id = order.company_id.partner_id

            fedex_service_type = self.env['delivery.carrier'].search([('fedex_service_type', '=', 'FEDEX_GROUND')], limit=1)
            if fedex_service_type:
                order.return_carrier_id = fedex_service_type.id

    
    
    def compare_order_confirm_time(self, order_date):
        
        time_float = 0
        if self.carrier_id.default_shipping_type == 'fedex' and self.company_id.fedex_express_specified_time:
            time_float = self.company_id.fedex_express_specified_time
        elif self.carrier_id.default_shipping_type == 'fedex_ground' and self.company_id.fedex_ground_specified_time:
            time_float = self.company_id.fedex_ground_specified_time
        elif not self.carrier_id and self.company_id.fedex_ground_specified_time:
            time_float = self.company_id.fedex_ground_specified_time

        time_float = 16
        # Extract hours and minutes from the float time
        hours = int(time_float)
        minutes = int((time_float - hours) * 60)

        # Create a time object for the FedEx specified time
        fedex_specified_time = dt.time(hour=hours, minute=minutes)

        user_timezone = 'US/Eastern'
        # Define the timezone in US/Eastern
        if self.env.user.tz:
            user_timezone = self.env.user.tz

        eastern = pytz.timezone(user_timezone)
        utc = pytz.utc

        # Create a datetime object with a dummy date (e.g., today) and the time
        today_date = datetime.now().date()
        local_datetime = datetime.combine(today_date, fedex_specified_time)

        # Localize the datetime to Eastern Time
        localized_time = eastern.localize(local_datetime)

        # Convert to UTC
        utc_time = localized_time.astimezone(utc)

        fedex_specified_time = utc_time.time()
        # order_date = self.date_order

        # date_string = "2024-11-26 22:57:09"
        # order_date = datetime.strptime(date_string, "%Y-%m-%d %H:%M:%S")

        order_time = order_date.time()
        # Check if today is Friday and the order is processed after the FedEx specified time
        if order_date.weekday() == 4 and order_time > fedex_specified_time:  # 4 represents Friday
            future_day = order_date + timedelta(days=3)  # Assume Monday as next working day
        elif order_time > fedex_specified_time:
            future_day = order_date + timedelta(days=1)
        else:
            future_day = order_date  # Order processed before the specified time, same day
        # Exclude holidays and weekends from the future day
        self.future_day = self.get_next_working_day(future_day)
        return True

    def get_next_working_day(self, date):
        # Define your holiday list or use an external holiday library if available
        holiday_list = [holiday.date.strftime('%Y-%m-%d') for holiday in  self.env['btl.holidays.list'].search([])]
        while date.weekday() >= 5 or date.strftime('%Y-%m-%d') in holiday_list:  # Check if weekend or holiday
            date += timedelta(days=1)  # Move to the next day
        return date
    
    
    def action_confirm(self):
        for order in self:
            if not order.disable_fedex and order.fedex_attribute_changed:
                raise UserError(_("You have modified the Fedex Lines. Please apply new shipping rate before proceeding"))
            
            if order.disable_fedex:
                is_delivery_objs = order.mapped('order_line1').filtered(lambda line: line.is_delivery == True)
                if is_delivery_objs:
                    raise UserError(_("Please remove the fedex line because the Disable Fedex feature enabled for the order"))

            if not order.disable_fedex:
                fedex_line = order.mapped('order_line1').filtered(lambda line: line.default_shipping_type in ('fedex', 'jetmail', 'fedex_ground'))
                is_delivery_objs = order.mapped('order_line1').filtered(lambda line: line.is_delivery == True)
                if fedex_line and not is_delivery_objs:
                    raise UserError(_("Please added shipping method before proceeding"))

        res = super(NonRevenue, self).action_confirm()
        for order in self:
            if order.picking_ids and order.carrier_id:
                if order.disable_fedex:
                    for pick in order.picking_ids:
                        pick.carrier_id = False
                else:
                    if not order.company_id.disable_future_day:
                        if order.future_day:
                            self.compare_order_confirm_time(order.future_day)
                        else:
                            self.compare_order_confirm_time(order.date_order)
                        
                    for picking in order.picking_ids:
                        if picking.picking_type_id.id != picking.picking_type_id.warehouse_id.out_type_id.id and picking.carrier_id:
                            picking.carrier_id = False
                        elif picking.picking_type_id.id ==  picking.picking_type_id.warehouse_id.out_type_id.id and not picking.carrier_id:
                            picking.carrier_id = order.carrier_id.id
                
            for pick in order.picking_ids:
                if pick.state in ['draft', 'waiting', 'confirmed', 'assigned']:
                    firmware_product_ids = [data.product_id for data in
                                    pick.move_ids_without_package.filtered(lambda o: 'FirmwareUpdate' in o.product_id.categ_id.name and o.product_id.onetime_sale)]
                    if firmware_product_ids:
                        pick.with_context(manual_click=True).action_assign()
        return res


    def get_shipping_charge(self):
        shipping_price_obj = self.env['btl.nonrevenue.combo.shipping.rate']
        for revenue_obj in self:

            if revenue_obj.fedex_attribute_changed:
                revenue_obj.calculate_package()

            if not revenue_obj.company_id.disable_future_day:
                revenue_obj.compare_order_confirm_time(dt.datetime.now())

            shiping_vals = {
                'signature_type': revenue_obj.signature_type or 'DIRECT',
                'fedex_saturday_service': revenue_obj.fedex_saturday_service,
                'signature_type_changed': revenue_obj.signature_type or 'DIRECT',
                'fedex_saturday_service_changed': revenue_obj.fedex_saturday_service,
                'revenue_id': revenue_obj.id,
                'future_day': revenue_obj.future_day,
                'disable_future_day': revenue_obj.company_id.disable_future_day
            }

            shipping_price_id = shipping_price_obj.create(shiping_vals)
            res = shipping_price_id.get_shipping_charge()
            return res



    def calculate_package(self):
        for order in self:
            if order.pack_info_ids:
                order.pack_info_ids.unlink()
            order.calculate_3db_package(['fedex', 'fedex_ground'])
            jetmail_line = order.mapped('order_line1').filtered(lambda line: line.default_shipping_type in ('jetmail',))
            if jetmail_line:
                order.calculate_3db_package(['jetmail'], True)


    def calculate_3db_package(self, default_shipping_type, jetmail=False):
        for so in self:
            if not so.is_pack_calc_needed:
                try:
                    bin_config = self.env['pack.config'].search([])[0]
                except IndexError:
                    raise UserError('You need to configure 3DBN API details first.')
                username = bin_config.name
                api_key = bin_config.api_key

                packBin = self.env['stock.package.type'].search([('disable', '!=', True)])
                if not packBin:
                    raise UserError('No Delivery Packages to pack. ')


                bins = []
                for bin in packBin:
                    bin_param = {"w": bin.width, "h": bin.height, "d": bin.packaging_length, "max_wg": bin.max_wg, "id": str(bin.name), "q": bin.q}
                    bins.append(bin_param)
                items = []
                # Delete previous packages if calculated

                for line in so.order_line1:
                    if line.product_id.type not in ['service', 'digital'] and  not line.is_delivery and \
                        line.default_shipping_type in default_shipping_type and \
                        not line.override_fedex_flow:
                        if not line.product_id.own_packing:
                            item_vals = {
                                'id': line.lot_id and line.lot_id.name or line.product_id.name,
                                'q': line.product_uom_qty,
                                'w': line.product_id.width,
                                'h': line.product_id.height,
                                'd': line.product_id.depth,
                                'wg': line.product_id.weight,
                                'vr': 1
                            }
                            items.append(item_vals)

                        elif line.product_id.own_packing:
                            for i in range(int(line.product_uom_qty)):
                                container_id = line.product_id.fedex_package_id.name + '(' + line.product_id.name + ')'
                                vals = {
                                    'd': line.product_id.fedex_package_id.package_type_id and line.product_id.fedex_package_id.package_type_id.packaging_length or 0,
                                    'h': line.product_id.fedex_package_id.package_type_id and line.product_id.fedex_package_id.package_type_id.height or 0,
                                    'container_id': container_id,
                                    'non_revenue_order_id': so.id,
                                    'w': line.product_id.fedex_package_id.package_type_id and line.product_id.fedex_package_id.package_type_id.width or 0,
                                    'weight': line.product_id.weight,
                                    'item_data':line.lot_id and line.lot_id.name or line.product_id.name,
                                    'jetmail': jetmail,
                                }
                                packBin_id = self.env['response.bin'].create(vals)

                conn = http.client.HTTPConnection(host='global-api.3dbinpacking.com', port=80)
                data = {"bins": bins, "items": items, "username": username, "api_key": api_key}


                if items:
                    params = urllib.parse.urlencode({'query': json.dumps(data)})
                    conn.request("POST", "/packer/packIntoMany", params, {"Content-type": "application/x-www-form-urlencoded", "Accept": "text/plain"})

                    content1 = conn.getresponse().read()
                    conn.close()
                    # GET THE PACK BIN IDS
                    content = json.loads(content1.decode('utf-8'))
                    total_packs = len(content['response']['bins_packed'])
                    for i in range(total_packs):
                        bin_data = content['response']['bins_packed'][i]['bin_data']

                        prdcts = []
                        for item in content['response']['bins_packed'][i]['items']:
                            prdcts.append(item['id'])
                        vals = {
                            'd': bin_data['d'],
                            'h': bin_data['h'],
                            'container_id': bin_data['id'],
                            'non_revenue_order_id': so.id,
                            'used_space': bin_data['used_space'],
                            'used_weight': bin_data['used_weight'],
                            'w': bin_data['w'],
                            'weight': bin_data['weight'],
                            'item_data': {x: prdcts.count(x) for x in prdcts},
                            'jetmail': jetmail,
                        }
                        packBin_id = self.env['response.bin'].create(vals)
                    # response_file = base64.encodestring(str(content['response']).encode())
                    response_file = base64.b64encode(str(content['response']).encode('utf8'))
                    self.env['packconfig.data.fetch.history'].create({
                        'packConfig_id': bin_config.id,
                        'response_file': response_file,
                        'file_name': datetime.now().strftime('%m-%d-%Y-%H-%M-%S') + '.json',
                        'partner_id': so.partner_id.id,
                        'non_revenue_order_id': so.id
                    })
                    # GET THE NOT PACKED ITEM ID
                    if len(content['response']['not_packed_items']) != 0:
                        msg = content['response']['errors'][0]['message']
                        raise UserError(_(msg))
            return True

    def open_website_url_stock_picking(self):
        self.ensure_one()
        for so in self:
            picking_ids = so.picking_ids.filtered(lambda o: o.carrier_tracking_url)
            if picking_ids:
                for picking in picking_ids:
                    if picking.state == 'done':
                        if not picking.carrier_tracking_url or not picking.carrier_id or not picking.delivery_type:
                            raise UserError(
                                _(
                                    "No Shipment Found."))
                        if not picking.carrier_tracking_url:
                            raise UserError(
                                _(
                                    "Your delivery method has no redirect on courier provider's website to track this order."))

                        carrier_trackers = []
                        try:
                            carrier_trackers = json.loads(picking.carrier_tracking_url)
                        except ValueError:
                            carrier_trackers = picking.carrier_tracking_url
                        else:
                            msg = "Tracking links for shipment: <br/>"
                            for tracker in carrier_trackers:
                                msg += '<a href=' + tracker[1] + '>' + tracker[0] + '</a><br/>'
                            self.message_post(body=msg)
                            return self.env.ref('delivery.act_delivery_trackers_url').read()[0]

                        client_action = {
                            'type': 'ir.actions.act_url',
                            'name': "Shipment Tracking Page",
                            'target': 'new',
                            'url': picking.carrier_tracking_url,
                        }
                        return client_action
            else:
                raise UserError(
                    _(
                        "No Shipment Found."))

    def action_cancel(self):
        res = super(NonRevenue, self).action_cancel()
        for order in self:
            if order and order.carrier_tracking_ref:
                for picking in order.picking_ids:
                    if picking.carrier_tracking_ref and picking.carrier_id:
                        cancel_tracking = picking.carrier_id.fedex_shipping_provider_cancel_shipment(picking)
                        picking.carrier_tracking_ref = ''
                        order.carrier_tracking_ref = ''
            
        return res


class RevenueLine(models.Model):
    _inherit = "ship.revenue.line"

    fedex_attribute_changed = fields.Boolean(string='FedEx Attribute', copy=False)
    override_fedex_flow = fields.Boolean(string='Manual FedEx', copy=False)
    generate_return_label = fields.Boolean(string='Return Label')
    return_address_id = fields.Many2one('res.partner', 'Return Address')
    default_shipping_type = fields.Selection(selection=[
        ('freight', 'Freight'),
        ('fedex', 'Fedex Express'),
        ('fedex_ground', 'Fedex Ground'),
        ('no_box', 'No Box'),
	('virtual', 'Virtual')
    ], string="Ship Type")

    is_delivery = fields.Boolean(string='Is Delivery')

    @api.model
    def create(self, vals):
        line = super(RevenueLine, self).create(vals)
        if line.product_id:
            if not line.order_id.disable_fedex:
                if line.product_id.fedex_return_label:
                    line.generate_return_label = True
                if not line.default_shipping_type:
                    line.default_shipping_type = line.product_id.default_shipping_type
            else:
                line.generate_return_label = False
                line.override_fedex_flow = True
                
        if line.default_shipping_type == 'freight':
            raise ValidationError(_("Please add Freight lines in Freight section"))
        return line
    
    def write(self, vals):
        res = super(RevenueLine, self).write(vals)
        if self.default_shipping_type == 'freight':
            raise ValidationError(_("Please add Freight lines in Freight section"))
        return res

    @api.onchange('product_id')
    def product_id_change(self):
        res = super(RevenueLine, self).product_id_change()
        if self.product_id:
            self.default_shipping_type = self.product_id.default_shipping_type
            self.generate_return_label = self.product_id.fedex_return_label
        return res

    @api.onchange('product_id', 'product_uom_qty', 'default_shipping_type')
    def _onchange_fedex_attribute_changed(self):
        for line in self:
            if not line.order_id.disable_fedex:
                if line.default_shipping_type in ('fedex', 'jetmail', 'fedex_ground'):
                    line.fedex_attribute_changed = True
                if line.product_id:
                    if line.product_id.fedex_return_label:
                        line.generate_return_label = True
                    else:
                        line.generate_return_label = False
            else:
                line.generate_return_label = False
                line.override_fedex_flow = True

    def unlink(self):
        for line in self:
            if not line.is_delivery and line.default_shipping_type in ('fedex', 'jetmail', 'fedex_ground'):
                is_delivery_objs = self.env['ship.revenue.line'].search([('order_id', '=', line.order_id.id), ('is_delivery', '=', True)])
                if is_delivery_objs:
                    fedex_line = line.order_id.mapped('order_line1').filtered(
                        lambda revenue_line: revenue_line.id != line.id and
                                             revenue_line.default_shipping_type in ('fedex', 'jetmail', 'fedex_ground'))
                    if fedex_line:
                        line.order_id.fedex_attribute_changed = True
                    is_delivery_objs.unlink()
        return super(RevenueLine, self).unlink()
    
    
class NonRevenueLine(models.Model):
    _inherit = "ship.nonrevenue.line"
    
    @api.model
    def create(self, vals):
        line = super(NonRevenueLine, self).create(vals)
        if line.product_id and line.product_id.default_shipping_type in ('fedex', 'jetmail', 'fedex_ground'):
            raise ValidationError(_("Please add FedEx lines in FedEx section"))
        return line
    
    def write(self, vals):
        res = super(NonRevenueLine, self).write(vals)
        if self.product_id and self.product_id.default_shipping_type in ('fedex', 'jetmail', 'fedex_ground'):
            raise ValidationError(_("Please add FedEx lines in FedEx section"))
        return res
    
    
    

import requests
import base64
import json
import logging

import http.client
import urllib.error
import urllib.parse
import urllib.request
import json
import ast
from datetime import datetime


from odoo.exceptions import ValidationError,ValidationError,UserError
from odoo import models, fields, api, _
from odoo.tools.float_utils import float_compare, float_is_zero, float_round
from odoo.addons import decimal_precision as dp


_logger = logging.getLogger(__name__)


class StockPicking(models.Model):
    _inherit = "stock.picking"
    

    
    pack_info_ids = fields.One2many('response.bin', 'picking_id', 'Packages')
            
    def fedex_return_shipping_non_revenue(self):
        for picking in self:
            if picking.non_revenue_id and picking.non_revenue_id.return_carrier_id:
                res = picking.non_revenue_id.return_carrier_id.fedex_return_shipping(picking)
            else:  
                res = picking.carrier_id.fedex_return_shipping(picking)
            tracking_ref = res[0].get('tracking_number', '')
            picking.update({
                'return_carrier_tracking_ref': tracking_ref
                })
            
            
            if not tracking_ref:
                return
            
            message_domain = [
                ('model', '=', 'stock.picking'),
                ('res_id', '=', picking.id),
                ('message_type', '=', 'notification'),
                ('attachment_ids', '!=', False),
                ('body', 'ilike', tracking_ref),
                ]
            if picking.carrier_id.fedex_shipping_label_file_type == 'ZPLII':
                message_domain.append(('attachment_ids.mimetype', '!=', 'application/pdf'))
            else:
                message_domain.append(('attachment_ids.mimetype', '=', 'application/pdf'))
            
            messages_to_parse = self.env['mail.message'].search(message_domain)
            
            
            
            for message in messages_to_parse:
                self._create_return_shipping_label(message)
            messages_to_parse.unlink()
            document_ids = picking.document_ids.filtered(lambda l: l.filename and '.ZPLII' in l.filename)
            if document_ids:
                document_ids.unlink()
            sale_document_ids = picking.non_revenue_id.document_ids.filtered(lambda l: l.filename and '.ZPLII' in l.filename)
            if sale_document_ids:
                sale_document_ids.unlink()
            
    def calculate_package_non_revenue(self):
        for picking in self:
            order = picking.non_revenue_id
            pack_data = ''
            for pack in order.pack_info_ids:
                if pack.item_data.find('{') == -1:
                    pack_data +=  ' ' + pack.item_data
                else:
                    pack_data += ' ' + pack.item_data
            calculate_package = False
            if pack_data:
                for line in picking.move_lines:
                    if line.default_shipping_type in ['fedex', 'fedex_ground', 'jetmail'] and line.move_line_ids:
                        for move_line in line.move_line_ids:
                            if move_line.lot_id:
                                if move_line.lot_id.name not in pack_data:
                                    calculate_package = True
                            elif line.product_id.name not in pack_data:
                                calculate_package = True
            else:
                calculate_package = True
            
            if not picking.pack_info_ids:
                calculate_package = True
            
            if calculate_package:
                picking.pack_info_ids.unlink()
                picking.calculate_package_picking_non_revenue()
                if self._context.get('do_validation', False):
                    self._cr.commit()
    
    def calculate_package_picking_non_revenue(self):
        for picking in self:
            if picking.pack_info_ids:
                picking.pack_info_ids.unlink()
            picking.calculate_3db_package_non_revenue(['fedex', 'fedex_ground'])
            jetmail_line = picking.mapped('move_ids_without_package').filtered(lambda line: line.default_shipping_type in ('jetmail',))
            if jetmail_line:
                picking.calculate_3db_package_non_revenue(['jetmail'], True)
    
    
    def calculate_3db_package_non_revenue(self, default_shipping_type, jetmail=False):
        for picking in self:
            if not picking.non_revenue_id.is_pack_calc_needed:
                try:
                    bin_config = self.env['pack.config'].search([])[0]
                except IndexError:
                    raise UserError('You need to configure 3DBN API details first.')
                username = bin_config.name
                api_key = bin_config.api_key

                packBin = self.env['stock.package.type'].search([('disable', '!=', True)])
                if not packBin:
                    raise UserError('No Delivery Packages to pack. ')
                
                
                bins = []
                for bin in packBin:
                    bin_param = {"w": bin.width, "h": bin.height, "d": bin.packaging_length, "max_wg": bin.max_wg, "id": str(bin.name), "q": bin.q}
                    bins.append(bin_param)
                items = []
                # Delete previous packages if calculated
                for move in picking.move_ids_without_package:
                    move_product_qty = move.product_uom_qty
                    for line in move.move_line_ids:
                        if line.default_shipping_type in default_shipping_type:
                            if not line.product_id.own_packing:
                                lot_name = line.lot_id and line.lot_id.name or line.product_id.name
                                if not line.qty_done and not line.product_uom_qty:
                                    raise UserError(_('Please enter the quantity to be allocated for the %s') % (lot_name))
                                item_vals = {
                                    'id': lot_name,
                                    'q': line.qty_done or line.product_uom_qty or 0.0,
                                    'w': line.product_id.width,
                                    'h': line.product_id.height,
                                    'd': line.product_id.depth,
                                    'wg': line.product_id.weight,
                                    'vr': 1
                                    }
                                
                                items.append(item_vals)
                                
                            elif line.product_id.own_packing:
                                for i in range(int(line.product_uom_qty)):
                                    container_id = line.product_id.fedex_package_id.name + '(' + line.product_id.name + ')'
                                    lot_name = line.lot_id and line.lot_id.name or line.product_id.name
                                    vals = {
                                        'd': line.product_id.fedex_package_id.package_type_id and line.product_id.fedex_package_id.package_type_id.packaging_length or 0,
                                        'h': line.product_id.fedex_package_id.package_type_id and line.product_id.fedex_package_id.package_type_id.height or 0,
                                        'container_id': container_id,
                                        'w': line.product_id.fedex_package_id.package_type_id and line.product_id.fedex_package_id.package_type_id.width or 0,
                                        'weight': line.product_id.weight,
                                        'item_data': lot_name,
                                        'jetmail': jetmail,
                                        'picking_id': picking.id
                                    }
                                    packBin_id = self.env['response.bin'].create(vals)
                        

                conn = http.client.HTTPConnection(host='global-api.3dbinpacking.com', port=80)
                data = {"bins": bins, "items": items, "username": username, "api_key": api_key}
                
                
                if items:
                    params = urllib.parse.urlencode({'query': json.dumps(data)})
                    conn.request("POST", "/packer/packIntoMany", params, {"Content-type": "application/x-www-form-urlencoded", "Accept": "text/plain"})
    
                    content1 = conn.getresponse().read()
                    conn.close()
                    # GET THE PACK BIN IDS
                    content = json.loads(content1.decode('utf-8'))
                    total_packs = len(content['response']['bins_packed'])
                    for i in range(total_packs):
                        bin_data = content['response']['bins_packed'][i]['bin_data']
    
                        prdcts = []
                        for item in content['response']['bins_packed'][i]['items']:
                            prdcts.append(item['id'])
                        vals = {
                            'd': bin_data['d'],
                            'h': bin_data['h'],
                            'container_id': bin_data['id'],
                            'picking_id': picking.id,
                            'used_space': bin_data['used_space'],
                            'used_weight': bin_data['used_weight'],
                            'w': bin_data['w'],
                            'weight': bin_data['weight'],
                            'item_data': {x: prdcts.count(x) for x in prdcts},
                            'jetmail': jetmail,
                        }
                        packBin_id = self.env['response.bin'].create(vals)
                    # response_file = base64.encodestring(str(content['response']).encode())
                    response_file = base64.b64encode(str(content['response']).encode('utf8'))
                    self.env['packconfig.data.fetch.history'].create({
                        'packConfig_id': bin_config.id,
                        'response_file': response_file,
                        'file_name': datetime.now().strftime('%m-%d-%Y-%H-%M-%S') + '.json',
                        'partner_id': picking.partner_id.id,
                        'order_id': picking.sale_id.id
                    })
                    # GET THE NOT PACKED ITEM ID
                    if len(content['response']['not_packed_items']) != 0:
                        msg = content['response']['errors'][0]['message']
                        raise UserError(_(msg))
            return True
    
    def send_to_shipper_non_revenue(self):
        self.ensure_one()
        if self.carrier_id:
            self.manage_packages_non_revenue()
        user = self.env.user
        auto_print = user.company_id.auto_send_slp and \
            user.company_id.printnode_enabled and user.printnode_enabled

        if auto_print and user.company_id.print_package_with_label:
            if self.picking_type_id == self.picking_type_id.warehouse_id.out_type_id:
                move_lines_without_package = self.move_line_ids_without_package.filtered(
                    lambda l: not l.result_package_id)
                if move_lines_without_package:
                    raise UserError(_('Some products on Delivery Order are not in Package. For '
                                      'printing Package Slips + Shipping Labels, please, put in '
                                      'pack remaining products. If you want to print only Shipping '
                                      'Label, please, deactivate "Print Package just after Shipping'
                                      ' Label" checkbox in PrintNode/Configuration/Settings'))

        if auto_print:
            # Expected UserError if there is no shipping label printer is available.
            user.get_shipping_label_printer()

        res = self.carrier_id.send_shipping(self)[0]
        if self.carrier_id.free_over and self.non_revenue_id and self.non_revenue_id._compute_amount_total_without_delivery() >= self.carrier_id.amount:
            res['exact_price'] = 0.0
        self.carrier_price = res['exact_price']
        if res['tracking_number']:
            self.carrier_tracking_ref = res['tracking_number']
            order_currency = self.non_revenue_id.currency_id or self.company_id.currency_id
            msg = _("Shipment sent to carrier %s for shipping with tracking number %s<br/>Cost: %.2f %s") % (self.carrier_id.name, self.carrier_tracking_ref, self.carrier_price, order_currency.name)
            self.message_post(body=msg)

        tracking_ref = self.carrier_tracking_ref
        if not tracking_ref:
            return
        
        message_domain = [
            ('model', '=', 'stock.picking'),
            ('res_id', '=', self.id),
            ('message_type', '=', 'notification'),
            ('attachment_ids', '!=', False),
            ('body', 'ilike', tracking_ref),
            ]
        if self.carrier_id.fedex_shipping_label_file_type == 'ZPLII':
            message_domain.append(('attachment_ids.mimetype', '!=', 'application/pdf'))
        else:
            message_domain.append(('attachment_ids.mimetype', '=', 'application/pdf'))
            
        messages_to_parse = self.env['mail.message'].search(message_domain)
        for message in messages_to_parse:
            self._create_shipping_label(message)
        messages_to_parse.unlink()
        
        document_ids = self.document_ids.filtered(lambda l: l.filename and '.ZPLII' in l.filename)
        if document_ids:
            document_ids.unlink()
        sale_document_ids = self.non_revenue_id.document_ids.filtered(lambda l: l.filename and '.ZPLII' in l.filename)
        if sale_document_ids:
            sale_document_ids.unlink()

        self.fedex_return_shipping()
        
        if auto_print and (self.shipping_label_ids or user.company_id.print_sl_from_attachment):
            self.with_context(raise_exception_slp=False).print_last_shipping_label()
    
    
    def _3dbn_create_move_lines_non_revenue(self, non_revenue_lines, quantity, pack, pack_data, own_packing=False, lot_search=False):
        for sale_line in non_revenue_lines:
            if own_packing:
                quantity = sale_line.product_uom_qty
            moves = self.env['stock.move'].search([('revenue_line_id', '=', sale_line.id), ('picking_id', '=', self.id)])
            for move in moves:
                update_qty = 0.0
                if quantity == move.availability:
                    update_qty = move.availability
                elif quantity < move.availability:
                    update_qty = quantity
                elif quantity > move.availability:
                    update_qty = move.availability
                    
                if move.reserved_availability < move.product_uom_qty:
                    lot_id = False
                    if lot_search:
                        lot_id = lot_search
                    else:
                        lot_id = move.prodlot_id
                    self.unreserve_stock_quant(move.product_id, move.location_id, update_qty, lot_id)
                    
                    quants = self.env['stock.quant']._update_reserved_quantity(move.product_id, move.location_id,
                                                                               update_qty, lot_id=lot_id, strict=True)
                    
                    if quants:
                        move_line_vals =  move._prepare_move_line_vals(quantity=update_qty, reserved_quant=quants[0][0])
                    else:
                        move_line_vals =  move._prepare_move_line_vals(quantity=update_qty)
                    move_line_vals['qty_done'] = update_qty
                    move_line_vals['lot_id'] = lot_id.id
                    move_line = self.env['stock.move.line'].create(move_line_vals)
                    move.write({'move_line_ids': [(4, move_line.id)]})
                    
                    quantity -= update_qty
                    if pack.id not in pack_data:
                        pack_data[pack.id] = [move_line.id]
                    if move_line.id not in pack_data[pack.id]:
                        pack_data[pack.id].append(move_line.id)

    def generate_move_lines_non_revenue(self):
        for pick in self.filtered(lambda p: p.state not in ('done', 'cancel')):
            selected_move_lines = []

            pack_info_data = {}
            for pack in pick.pack_info_ids:
                move_lines_to_pack = self.env['stock.move.line']
                if pack.item_data.find('{') == -1:
                    pack_data = pack.item_data
                    lot_search = self.env['stock.production.lot'].search([('name', '=', pack_data)], limit=1)

                    if lot_search:
                        non_revenue_lines = pick.non_revenue_id.order_line1.filtered(lambda x: x.lot_id.id == lot_search.id)
                        if not non_revenue_lines:
                            non_revenue_lines = pick.non_revenue_id.order_line1.filtered(lambda x: x.product_id.id == lot_search.product_id.id)

                        pick._3dbn_create_move_lines_non_revenue(non_revenue_lines, 0, pack, pack_info_data, True, lot_search)

                else:
                    pack_data = pack.item_data
                    dict_pack = ast.literal_eval(pack_data)
                    for pack_name in dict_pack:
                        quantity = dict_pack[pack_name]
                        lot_search = self.env['stock.production.lot'].search([('name', '=', pack_name)], limit=1)
                        product_id = self.env['product.product'].search([('name', '=', pack_name)], limit=1)
                        if lot_search:
                            non_revenue_lines = pick.non_revenue_id.order_line1.filtered(lambda x: x.lot_id.id == lot_search.id)
                            if not non_revenue_lines:
                                non_revenue_lines = pick.non_revenue_id.order_line1.filtered(lambda x: x.product_id.id == lot_search.product_id.id)

                            pick._3dbn_create_move_lines_non_revenue(non_revenue_lines, quantity, pack, pack_info_data, False, lot_search)

                        elif product_id:
                            non_revenue_lines = pick.non_revenue_id.order_line1.filtered(lambda x: x.product_id.id == product_id.id)
                            pick._3dbn_create_move_lines_non_revenue(non_revenue_lines, quantity, pack, pack_info_data, False)

            return pack_info_data


    def my_put_in_pack_non_revenue(self):
        if self.non_revenue_id:
            if not self.non_revenue_id.is_pack_calc_needed:
                self.calculate_package_non_revenue()

        for pick in self.filtered(lambda p: p.state not in ('done', 'cancel')):
            selected_move_lines = []
            pack_info_data = {}
            for pack in pick.pack_info_ids:
                if pack.item_data.find('{') == -1:
                    pack_data = pack.item_data
                    lot_search = self.env['stock.production.lot'].search([('name', '=', pack_data)], limit=1)
                    if lot_search:
                        non_revenue_lines = pick.non_revenue_id.order_line1.filtered(lambda x: x.lot_id.id == lot_search.id)
                        if not non_revenue_lines:
                            non_revenue_lines = pick.non_revenue_id.order_line1.filtered(lambda x: x.product_id.id == lot_search.product_id.id)
                        ###################Block Start ############
                        for sale_line in non_revenue_lines:
                            moves = self.env['stock.move'].search([('revenue_line_id', '=', sale_line.id), ('picking_id', '=', self.id)])
                            for move in moves:
                                for sml in move.move_line_ids.filtered(lambda x: x.product_id.id == sale_line.product_id.id and
                                                                                 x.lot_id.id == lot_search.id):
                                    selected_move_lines.append(sml.id)
                                if pack.id not in pack_info_data:
                                    pack_info_data[pack.id] = [sml.id]
                                if sml.id not in pack_info_data[pack.id]:
                                    pack_info_data[pack.id].append(sml.id)
                        ###################Block END ############
                else:
                    pack_data = pack.item_data
                    dict_pack = ast.literal_eval(pack_data)
                    for pack_name in dict_pack:
                        lot_search = self.env['stock.production.lot'].search([('name', '=', pack_name)], limit=1)
                        product_id = self.env['product.product'].search([('name', '=', pack_name)], limit=1)
                        if lot_search:
                            non_revenue_lines = pick.non_revenue_id.order_line1.filtered(lambda x: x.lot_id.id == lot_search.id)
                            if not non_revenue_lines:
                                non_revenue_lines = pick.non_revenue_id.order_line1.filtered(lambda x: x.product_id.id == lot_search.product_id.id)
                            ###################Block Start ############
                            for sale_line in non_revenue_lines:
                                moves = self.env['stock.move'].search([('revenue_line_id', '=', sale_line.id), ('picking_id', '=', self.id)])
                                for move in moves:
                                    for sml in move.move_line_ids.filtered(lambda x: x.product_id.id == sale_line.product_id.id and
                                                                                     x.lot_id.id == lot_search.id):
                                        selected_move_lines.append(sml.id)
                                    if pack.id not in pack_info_data:
                                        pack_info_data[pack.id] = [sml.id]
                                    if sml.id not in pack_info_data[pack.id]:
                                        pack_info_data[pack.id].append(sml.id)
                            ###################Block END ############
                        elif product_id:
                            non_revenue_lines = pick.non_revenue_id.order_line1.filtered(lambda x: x.product_id.id == product_id.id)
                            ###################Block Start ############
                            for sale_line in non_revenue_lines:
                                moves = self.env['stock.move'].search([('revenue_line_id', '=', sale_line.id), ('picking_id', '=', self.id)])
                                for move in moves:
                                    for sml in move.move_line_ids.filtered(lambda x: x.product_id.id == sale_line.product_id.id):
                                        selected_move_lines.append(sml.id)
                                    if pack.id not in pack_info_data:
                                        pack_info_data[pack.id] = [sml.id]
                                    if sml.id not in pack_info_data[pack.id]:
                                        pack_info_data[pack.id].append(sml.id)
                            ###################Block END ############
        self._3dbn_put_in_package_non_revenue(pack_info_data)

    def _3dbn_put_in_pack_non_revenue(self):
        if self.non_revenue_id:
            if not self.non_revenue_id.is_pack_calc_needed:
                self.calculate_package_non_revenue()
        move_lines = self.env['stock.move.line'].search([('picking_id', '=', self.id), ('default_shipping_type', 'in', ('fedex', 'fedex_ground'))])
        if move_lines:
            self.do_unreserve()
            move_lines = self.env['stock.move.line'].search([('picking_id', '=', self.id), ('default_shipping_type', 'in', ('fedex', 'fedex_ground'))])
            move_lines.unlink()
       
        pack_info_data = self.generate_move_lines_non_revenue()
        self._3dbn_put_in_package_non_revenue(pack_info_data)

    def _3dbn_put_in_package_non_revenue(self, pack_info_data={}):
        package_ids = self.env['stock.quant.package']
        cover = 0
        for pick in self.filtered(lambda p: p.state not in ('done', 'cancel')):
            move_line_ids = pick.move_line_ids.filtered(lambda o: o.qty_done > 0 and o.result_package_id)
            move_line_ids.write({'result_package_id': False})
            for pack in pick.pack_info_ids:
                move_lines_to_pack = self.env['stock.move.line']
                if pack.item_data.find('{') == -1:
                    lot_search = self.env['stock.production.lot'].search([('name', '=', pack.item_data)], limit=1)
                    move_line = self.env['stock.move.line'].search([('lot_id', '=', lot_search.id), ('move_id.picking_id', '=', self.id)])

                    if self.carrier_id.fedex_default_product_packaging_id.cover_amount_option == 'fixed':
                        cover = self.carrier_id.fedex_default_product_packaging_id.cover_amount
                    else:
                        cover_amount = sum([po.qty_done * po.product_id.lst_price for po in move_line])
                        cover = cover_amount

                    package = self.env['stock.quant.package'].create({
                        'height': pack.h,
                        'width': pack.w,
                        'length': pack.d,
                        'weight': pack.weight,
                        'shipping_weight': pack.weight,
                        'cover_amount': cover,
                        # 'packaging_id': self.carrier_id.fedex_default_product_packaging_id.id,
                        'non_revenue_id': pick.non_revenue_id.id,
                        'picking_id': pick.id,
                        'override_weight': True
                    })
                    for ml in move_line:
                        # calculating --------->
                        if float_compare(ml.qty_done, ml.product_uom_qty, precision_rounding=ml.product_uom_id.rounding) >= 0:
                            move_lines_to_pack |= ml
                        else:
                            quantity_left_todo = float_round(
                                ml.product_uom_qty - ml.qty_done,
                                precision_rounding=ml.product_uom_id.rounding,
                                rounding_method='UP')
                            done_to_keep = ml.qty_done
                            if done_to_keep > 0:
                                new_move_line = ml.copy(default={'product_uom_qty': 0, 'qty_done': ml.qty_done})
                                vals = {'product_uom_qty': quantity_left_todo, 'qty_done': 0.0}
                                if pick.picking_type_id.code == 'incoming':
                                    if ml.lot_id:
                                        vals['lot_id'] = False
                                    if ml.lot_name:
                                        vals['lot_name'] = False

                                ml.write(vals)
                                new_move_line.write({'product_uom_qty': done_to_keep})
                                move_lines_to_pack |= new_move_line
                            else:
                                move_lines_to_pack |= ml
                else:
                    cover = 0
                    pack_data = pack.item_data
                    # pack_data = pack_data.replace("\'", "\"")
                    # dict_pack = json.loads(pack_data)
                    dict_pack = ast.literal_eval(pack_data)
                    package = self.env['stock.quant.package'].create({
                        'height': pack.h,
                        'width': pack.w,
                        'length': pack.d,
                        'weight': pack.weight,
                        'shipping_weight': pack.weight,
                        # 'packaging_id': self.carrier_id.fedex_default_product_packaging_id.id,
                        'non_revenue_id': pick.non_revenue_id.id,
                        'picking_id': pick.id,
                        'override_weight': True
                    })

                    if pack.id in pack_info_data:
                        move_lines_to_pack_lines = self.env['stock.move.line'].browse(pack_info_data[pack.id])
                        cover_amount = sum([po.qty_done * po.product_id.lst_price for po in move_lines_to_pack_lines])

                        for prod_line in move_lines_to_pack_lines:
                            if prod_line.product_id.fedex_package_id.cover_amount_option == 'fixed':
                                cover_amount = prod_line.product_id.fedex_package_id.cover_amount
                        cover += cover_amount

                        move_lines_to_pack |= move_lines_to_pack_lines

                    package.cover_amount = cover
                package_level = self.env['stock.package_level'].create({
                    'package_id': package.id,
                    'picking_id': pick.id,
                    'location_id': False,
                    'location_dest_id': move_line_ids.mapped('location_dest_id').id,
                    'move_line_ids': [(6, 0, move_lines_to_pack.ids)],
                    'pack_move_line_ids': [(6, 0, move_lines_to_pack.ids)],
                    'company_id': self.env.user.company_id.id,
                })
                move_lines_to_pack.write({'result_package_id': package.id})
                package_ids |= package

            # for return_pack in pick.non_revenue_id.return_packaging_ids:
            #     package = self.env['stock.quant.package'].create({
            #         'height': return_pack.height,
            #         'width': return_pack.width,
            #         'length': return_pack.length,
            #         'weight': return_pack.weight,
            #         'shipping_weight': return_pack.weight,
            #         'cover_amount': return_pack.cover_amount,
            #         'packaging_id': self.carrier_id.fedex_default_product_packaging_id.id,
            #         'order_id': pick.non_revenue_id.id,
            #         'picking_id':pick.id,
            #       })
            #     package_ids |= package
        return package_ids
    
    def _put_in_pack_non_revenue(self):
        package = False
        for pick in self.filtered(lambda p: p.state not in ('done', 'cancel')):
            # if pick.non_revenue_id:
            #     if not pick.non_revenue_id.is_pack_calc_needed:
            #         package = pick._3dbn_put_in_pack()
            # else:
                move_line_ids = pick.move_line_ids.filtered(lambda o: o.qty_done > 0 and not o.result_package_id and not o.product_id.own_packing and o.default_shipping_type in ('fedex', 'fedex_ground'))
                own_packing_move_line_ids = pick.move_line_ids.filtered(lambda o: o.qty_done > 0 and not o.result_package_id and o.product_id.own_packing and o.default_shipping_type in ('fedex', 'fedex_ground'))
                if move_line_ids:
                    if pick.non_revenue_id:
                        if not pick.non_revenue_id.is_pack_calc_needed:
                            package = pick._3dbn_put_in_pack_non_revenue()
                            # package = pick.my_put_in_pack()
                            # pass
                    else:
                        move_lines_to_pack = self.env['stock.move.line']
                        package = self.env['stock.quant.package'].create({})
                        for ml in move_line_ids:
                            if float_compare(ml.qty_done, ml.product_uom_qty,
                                             precision_rounding=ml.product_uom_id.rounding) >= 0:
                                move_lines_to_pack |= ml
                            else:
                                quantity_left_todo = float_round(
                                    ml.product_uom_qty - ml.qty_done,
                                    precision_rounding=ml.product_uom_id.rounding,
                                    rounding_method='UP')
                                done_to_keep = ml.qty_done
                                new_move_line = ml.copy(
                                    default={'product_uom_qty': 0, 'qty_done': ml.qty_done})
                                ml.write({'product_uom_qty': quantity_left_todo, 'qty_done': 0.0})
                                new_move_line.write({'product_uom_qty': done_to_keep})
                                move_lines_to_pack |= new_move_line

                        package_level = self.env['stock.package_level'].create({
                            'package_id': package.id,
                            'picking_id': pick.id,
                            'location_id': False,
                            'location_dest_id': move_line_ids.mapped('location_dest_id').id,
                            'move_line_ids': [(6, 0, move_lines_to_pack.ids)],
                            'pack_move_line_ids': [(6, 0, move_lines_to_pack.ids)],
                            'company_id': self.env.user.company_id.id,
                        })
                        move_lines_to_pack.write({
                            'result_package_id': package.id,
                        })
                elif own_packing_move_line_ids:
                    product_names = [line.product_id.name for line in own_packing_move_line_ids]
                    raise UserError(_('You must first assign own packages for the following products. \n\n%s' % "\n".join(product_names)))
                else:
                    raise UserError(_('You must first set the quantity you will put in the pack.'))
        return package
    
    
    def manage_packages_non_revenue(self):
        package = False
        for pick in self.filtered(lambda p: p.state not in ('done', 'cancel')):
            # if pick.non_revenue_id:
            #     if not pick.non_revenue_id.is_pack_calc_needed:
            #         pick._3dbn_put_in_pack()
            # else:
                assign_move_line_ids = pick.move_line_ids.filtered(lambda o: o.qty_done > 0 and not o.result_package_id and o.default_shipping_type in ('fedex', 'fedex_ground'))
                if assign_move_line_ids:
                    if pick.non_revenue_id:
                        if not pick.non_revenue_id.is_pack_calc_needed:
                            pick._3dbn_put_in_pack_non_revenue()
                            # pick.my_put_in_pack()
                    else:
                        move_line_ids = pick.move_line_ids.filtered(lambda o: o.qty_done > 0 and not o.result_package_id and not o.product_id.own_packing and o.default_shipping_type in ('fedex', 'fedex_ground'))
                        own_packing_move_line_ids = pick.move_line_ids.filtered(lambda o: o.qty_done > 0 and not o.result_package_id and o.product_id.own_packing and o.product_id.fedex_package_id and o.default_shipping_type in ('fedex', 'fedex_ground'))
                        for line in own_packing_move_line_ids:
                            self.env['choose.delivery.package'].put_packages_lines(line, line.product_id.fedex_package_id)

                        if move_line_ids:
                            self.env['choose.delivery.package'].put_packages_lines(move_line_ids, pick.carrier_id.fedex_default_product_packaging_id)
                else:
                    unassign_move_line_ids = pick.move_line_ids.filtered(lambda o: o.qty_done == 0 and not o.result_package_id and o.default_shipping_type in ('fedex', 'fedex_ground'))
                    if unassign_move_line_ids:
                        raise UserError(_('You must first set the quantity you will put in the pack.'))
                
    
#             move_line_ids = pick.move_line_ids.filtered(lambda o: o.qty_done > 0 and not o.product_id.own_packing and o.default_shipping_type == 'fedex')
#             
#             if move_line_ids:
#                 view_id = self.env.ref('delivery.choose_delivery_package_view_form').id
#                 return {
#                     'name': _('Package Details'),
#                     'type': 'ir.actions.act_window',
#                     'view_mode': 'form',
#                     'res_model': 'choose.delivery.package',
#                     'view_id': view_id,
#                     'views': [(view_id, 'form')],
#                     'target': 'new',
#                     'context': {
#                         'default_move_lines': [(6, 0, move_line_ids.ids)],
#                         'default_move_line_ids': [(6, 0, move_line_ids.ids)],
#                         'current_package_carrier_type': pick.carrier_id.delivery_type if pick.carrier_id.delivery_type not in ['base_on_rule', 'fixed'] else 'none',
#                         }
#                     }
#             else:
#                 if not own_packing_move_line_ids:
#                     raise UserError(_('You must first either select line or set the quantity you will put in the pack.'))
                

class FedExPackageDetails(models.Model):
    _inherit = "stock.quant.package"
    
    
    non_revenue_id = fields.Many2one('ship.nonrevenue', 'Non Revenue')
    
    